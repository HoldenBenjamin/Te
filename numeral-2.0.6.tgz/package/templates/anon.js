(function() {
    <%= content %>
})();
